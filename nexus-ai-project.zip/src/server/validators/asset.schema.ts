import { z } from "zod";

export const createAssetSchema = z.object({
  projectId: z.string().uuid("Invalid project ID"),
  type: z.string(),
  name: z.string().min(2, "Asset name must be at least 2 characters").max(100),
});

export const createAssetVersionSchema = z.object({
  assetId: z.string().uuid("Invalid asset ID"),
  content: z.string(),
});
