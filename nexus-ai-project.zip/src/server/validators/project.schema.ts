import { z } from "zod";

export const createProjectSchema = z.object({
  workspaceId: z.string().uuid("Invalid workspace ID"),
  name: z.string().min(2, "Project name must be at least 2 characters").max(100),
  description: z.string().optional(),
});

export const updateProjectSchema = z.object({
  name: z.string().min(2, "Project name must be at least 2 characters").max(100).optional(),
  description: z.string().optional(),
});
