import { z } from "zod";

// Example domain schemas placeholder
export const UserSchema = z.object({
  id: z.string().cuid(),
  email: z.string().email(),
  name: z.string().optional(),
});

export const ProjectSchema = z.object({
  id: z.string().cuid(),
  workspaceId: z.string().cuid(),
  name: z.string().min(1),
  description: z.string().optional(),
});

export const AgentSchema = z.object({
  id: z.string().cuid(),
  projectId: z.string().cuid(),
  name: z.string().min(1),
  role: z.string().min(1),
  model: z.string(),
});
