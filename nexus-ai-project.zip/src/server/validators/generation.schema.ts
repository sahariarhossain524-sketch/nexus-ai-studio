import { z } from "zod";

export const createGenerationJobSchema = z.object({
  projectId: z.string().uuid("Invalid project ID"),
  prompt: z.string().min(5, "Prompt must be at least 5 characters"),
});

export const updateGenerationJobSchema = z.object({
  status: z.enum(["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED"]),
  error: z.string().optional().nullable(),
});
