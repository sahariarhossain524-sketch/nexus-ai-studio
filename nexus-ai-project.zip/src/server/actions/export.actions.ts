"use server";

import { revalidatePath } from "next/cache";
import { ExportService } from "../export/service/export.service";
import { ArtifactStore } from "../ai/orchestrator/artifact.store";
import { ExportFormat } from "../export/types/export.types";

const artifactStore = new ArtifactStore();
const exportService = new ExportService(artifactStore);

export async function requestExportAction(
  workspaceId: string, 
  projectId: string, 
  generationJobId: string, 
  userId: string, 
  format: ExportFormat
) {
  try {
    const job = await exportService.queueExport({
      jobId: crypto.randomUUID(),
      workspaceId,
      projectId,
      generationJobId,
      userId,
      format
    });

    revalidatePath(`/dashboard/projects/${projectId}/documents`);
    return { success: true, job };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export async function getExportsAction(projectId: string, userId: string) {
  try {
    const jobs = await exportService.getExportsForProject(projectId, userId);
    return { success: true, jobs };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export async function getDownloadUrlAction(jobId: string, userId: string) {
  try {
    const url = await exportService.getDownloadUrl(jobId, userId);
    return { success: true, url };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
