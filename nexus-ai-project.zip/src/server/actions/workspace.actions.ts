"use server";

import { revalidatePath } from "next/cache";
import { WorkspaceService } from "../services/workspace.service";
import { createWorkspaceSchema } from "../validators/workspace.schema";

export async function createWorkspaceAction(userId: string, formData: FormData) {
  try {
    const rawData = { name: formData.get("name") as string };
    const validatedData = createWorkspaceSchema.parse(rawData);

    const workspace = await WorkspaceService.createWorkspace(userId, validatedData);
    
    revalidatePath("/dashboard");
    return { success: true, workspace };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
