"use server";

import { revalidatePath } from "next/cache";
import { GenerationService } from "../services/generation.service";
import { createGenerationJobSchema } from "../validators/generation.schema";

export async function triggerGenerationAction(projectId: string, userId: string, formData: FormData) {
  try {
    const rawData = {
      projectId,
      prompt: formData.get("prompt") as string,
    };
    
    const validatedData = createGenerationJobSchema.parse(rawData);

    const job = await GenerationService.triggerGeneration(projectId, userId, validatedData.prompt);
    
    revalidatePath(`/dashboard/projects/${projectId}`);
    return { success: true, job };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
