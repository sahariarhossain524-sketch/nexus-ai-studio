"use server";

import { revalidatePath } from "next/cache";
import { AssetService } from "../services/asset.service";
import { createAssetSchema } from "../validators/asset.schema";

export async function createAssetAction(projectId: string, userId: string, formData: FormData) {
  try {
    const rawData = {
      projectId,
      type: formData.get("type") as string,
      name: formData.get("name") as string,
    };
    
    const validatedData = createAssetSchema.parse(rawData);

    const asset = await AssetService.createAsset(projectId, userId, {
      ...validatedData,
      content: formData.get("content") as string || "",
    });
    
    revalidatePath(`/dashboard/projects/${projectId}`);
    return { success: true, asset };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
