"use server";

import { revalidatePath } from "next/cache";
import { ProjectService } from "../services/project.service";
import { createProjectSchema } from "../validators/project.schema";

export async function createProjectAction(workspaceId: string, userId: string, formData: FormData) {
  try {
    const rawData = {
      workspaceId,
      name: formData.get("name") as string,
      description: formData.get("description") as string | undefined,
    };
    
    const validatedData = createProjectSchema.parse(rawData);

    const project = await ProjectService.createProject(workspaceId, userId, validatedData);
    
    revalidatePath(`/dashboard/${workspaceId}`);
    return { success: true, project };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
