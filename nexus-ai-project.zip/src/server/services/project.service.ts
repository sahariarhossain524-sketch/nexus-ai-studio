import { ProjectRepository } from "../repositories/project.repository";
import { onProjectCreated } from "../events/project-created";

export class ProjectService {
  static async createProject(workspaceId: string, userId: string, data: { name: string; description?: string }) {
    if (!userId || !workspaceId) throw new Error("Unauthorized");
    
    // Authorization check for workspace access would go here

    const project = await ProjectRepository.create(workspaceId, data);
    
    // Fire domain event
    await onProjectCreated(project.id);
    
    return project;
  }

  static async getWorkspaceProjects(workspaceId: string, userId: string) {
    if (!userId) throw new Error("Unauthorized");
    try {
      return await ProjectRepository.listByWorkspace(workspaceId);
    } catch (e) {
      console.error("[ProjectService] Failed to list projects:", e);
      return [];
    }
  }

  static async getProject(id: string, userId: string) {
    if (!userId) throw new Error("Unauthorized");
    return ProjectRepository.findById(id);
  }
}
