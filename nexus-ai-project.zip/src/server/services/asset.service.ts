import { AssetRepository } from "../repositories/asset/asset.repository";
import { AssetVersionRepository } from "../repositories/asset/asset-version.repository";
import { onAssetCreated } from "../events/asset-created";

export class AssetService {
  static async createAsset(projectId: string, userId: string, data: { type: string; name: string; content: string }) {
    if (!userId || !projectId) throw new Error("Unauthorized");
    
    // Auth check

    const asset = await AssetRepository.create(projectId, {
      type: data.type,
      name: data.name,
    });

    await AssetVersionRepository.create(asset.id, {
      content: data.content,
      versionNum: 1,
    });

    await onAssetCreated(asset.id);

    return asset;
  }

  static async getProjectAssets(projectId: string, userId: string) {
    if (!userId) throw new Error("Unauthorized");
    return AssetRepository.listByProject(projectId);
  }
}
