import { WorkspaceRepository } from "../repositories/workspace.repository";

export class WorkspaceService {
  static async createWorkspace(userId: string, data: { name: string }) {
    if (!userId) throw new Error("Unauthorized");
    return WorkspaceRepository.create(userId, data);
  }

  static async getUserWorkspaces(userId: string) {
    if (!userId) throw new Error("Unauthorized");
    return WorkspaceRepository.listByUser(userId);
  }

  static async getWorkspace(id: string, userId: string) {
    if (!userId) throw new Error("Unauthorized");
    const workspace = await WorkspaceRepository.findById(id);
    if (!workspace) throw new Error("Workspace not found");
    
    // Authorization check would go here in a real app (checking memberships)
    
    return workspace;
  }
}
