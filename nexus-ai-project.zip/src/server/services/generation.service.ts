import { GenerationJobRepository } from "../repositories/generation/generation-job.repository";
import { onGenerationStarted } from "../events/generation-started";
import { orchestrator } from "../ai/orchestrator/orchestrator.registry";

export class GenerationService {
  static async triggerGeneration(projectId: string, userId: string, prompt: string) {
    if (!userId || !projectId) throw new Error("Unauthorized");
    
    // Authorization check

    const job = await GenerationJobRepository.create(projectId, { prompt });
    
    // Fire domain event
    await onGenerationStarted(job.id);
    
    // Trigger Orchestrator
    const context = {
      jobId: job.id,
      userId,
      workspaceId: "unknown-workspace-id", // Would fetch from project
      projectId,
      constraints: { idea: prompt },
      memory: {},
      providerConfig: { provider: "Gemini", model: "gemini-2.5-pro", temperature: 0.7 }
    };
    
    // Fire and forget (runs in background)
    orchestrator.startJob(context as any).catch(console.error);

    return job;
  }

  static async getJobStatus(jobId: string, userId: string) {
    if (!userId) throw new Error("Unauthorized");
    return GenerationJobRepository.findById(jobId);
  }
}
