import { db } from "../../db";

export class GenerationJobRepository {
  static async create(projectId: string, data: { prompt: string }) {
    return db.generationJob.create({
      data: {
        projectId,
        prompt: data.prompt,
        status: "pending",
      },
    });
  }

  static async findById(id: string) {
    return db.generationJob.findUnique({
      where: { id },
    });
  }

  static async listByProject(projectId: string) {
    return db.generationJob.findMany({
      where: { projectId },
      orderBy: { createdAt: "desc" },
    });
  }

  static async updateStatus(id: string, status: any, error?: string) {
    return db.generationJob.update({
      where: { id },
      data: { status, error },
    });
  }
}
