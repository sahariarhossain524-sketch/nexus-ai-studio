import { db } from "../db";

export class ProjectRepository {
  static async create(workspaceId: string, data: { name: string; description?: string }) {
    return db.project.create({
      data: {
        workspaceId,
        name: data.name,
        description: data.description,
      },
    });
  }

  static async findById(id: string) {
    return db.project.findUnique({
      where: { id },
    });
  }

  static async listByWorkspace(workspaceId: string) {
    return db.project.findMany({
      where: { workspaceId },
      orderBy: { createdAt: "desc" },
    });
  }

  static async update(id: string, data: { name?: string; description?: string }) {
    return db.project.update({
      where: { id },
      data,
    });
  }

  static async delete(id: string) {
    return db.project.delete({
      where: { id },
    });
  }
}
