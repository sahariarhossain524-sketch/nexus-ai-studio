import { db } from "../../db";

export class AssetRepository {
  static async create(projectId: string, data: { type: string; name: string; metadata?: any }) {
    return db.asset.create({
      data: {
        projectId,
        type: data.type,
        name: data.name,
        metadata: data.metadata,
      },
    });
  }

  static async findById(id: string) {
    return db.asset.findUnique({
      where: { id },
      include: { versions: { orderBy: { versionNum: "desc" }, take: 1 } },
    });
  }

  static async listByProject(projectId: string) {
    return db.asset.findMany({
      where: { projectId },
      include: { versions: { orderBy: { versionNum: "desc" }, take: 1 } },
      orderBy: { createdAt: "desc" },
    });
  }

  static async delete(id: string) {
    return db.asset.delete({
      where: { id },
    });
  }
}
