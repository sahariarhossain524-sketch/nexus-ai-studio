import { db } from "../../db";

export class AssetVersionRepository {
  static async create(assetId: string, data: { content: string; versionNum: number }) {
    return db.assetVersion.create({
      data: {
        assetId,
        content: data.content,
        versionNum: data.versionNum,
      },
    });
  }

  static async findLatestByAssetId(assetId: string) {
    return db.assetVersion.findFirst({
      where: { assetId },
      orderBy: { versionNum: "desc" },
    });
  }

  static async listByAssetId(assetId: string) {
    return db.assetVersion.findMany({
      where: { assetId },
      orderBy: { versionNum: "desc" },
    });
  }
}
