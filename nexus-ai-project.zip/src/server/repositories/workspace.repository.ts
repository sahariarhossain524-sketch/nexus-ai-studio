import { db } from "../db";

export class WorkspaceRepository {
  static async create(userId: string, data: { name: string }) {
    return db.workspace.create({
      data: {
        name: data.name,
        memberships: {
          create: {
            userId: userId,
            role: "OWNER",
          },
        },
      },
    });
  }

  static async findById(id: string) {
    return db.workspace.findUnique({
      where: { id },
    });
  }

  static async listByUser(userId: string) {
    return db.workspace.findMany({
      where: {
        memberships: {
          some: { userId },
        },
      },
      orderBy: { createdAt: "desc" },
    });
  }

  static async update(id: string, data: { name?: string }) {
    return db.workspace.update({
      where: { id },
      data,
    });
  }

  static async delete(id: string) {
    return db.workspace.delete({
      where: { id },
    });
  }
}
