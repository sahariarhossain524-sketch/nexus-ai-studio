import { IExportStorage } from "./export-storage.interface";
import fs from "fs/promises";
import path from "path";

export class LocalExportStorage implements IExportStorage {
  providerName = "local";
  private readonly baseDir: string;

  constructor() {
    // Save to public/exports so it's accessible via URL in development
    this.baseDir = path.join(process.cwd(), "public", "exports");
  }

  async upload(
    workspaceId: string, 
    projectId: string, 
    jobId: string, 
    filename: string, 
    buffer: Buffer, 
    mimeType: string
  ): Promise<string> {
    const dirPath = path.join(this.baseDir, workspaceId, projectId, jobId);
    
    // Ensure directory exists
    await fs.mkdir(dirPath, { recursive: true });
    
    const filePath = path.join(dirPath, filename);
    await fs.writeFile(filePath, buffer);

    // Return the relative URL for the browser
    return `/exports/${workspaceId}/${projectId}/${jobId}/${filename}`;
  }

  async getSignedUrl(fileUrl: string, expiresInSeconds: number = 3600): Promise<string> {
    // For local storage, we just return the public URL directly.
    // A true signed URL implementation would require a custom API route 
    // that validates a JWT or similar token before serving the file.
    return fileUrl;
  }

  async delete(fileUrl: string): Promise<void> {
    try {
      // fileUrl is something like /exports/workspace/project/job/file.pdf
      const relativePath = fileUrl.replace("/exports/", "");
      const fullPath = path.join(this.baseDir, relativePath);
      await fs.unlink(fullPath);
    } catch (error) {
      console.warn(`[LocalExportStorage] Failed to delete ${fileUrl}`, error);
    }
  }
}
