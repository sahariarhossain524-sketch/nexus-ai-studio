import { ExportJob, ExportStatus } from "../types/export.types";

export class ExportJobRepository {
  // In-memory mock for the architecture phase. 
  // In production, this maps to Prisma/Postgres
  private static jobs = new Map<string, ExportJob>();

  static async create(job: ExportJob): Promise<ExportJob> {
    this.jobs.set(job.id, job);
    return job;
  }

  static async updateStatus(id: string, status: ExportStatus, error?: string): Promise<void> {
    const job = this.jobs.get(id);
    if (job) {
      job.status = status;
      if (error) job.error = error;
      if (status === "COMPLETED") job.completedAt = new Date();
      this.jobs.set(id, job);
    }
  }

  static async updateFileUrl(id: string, fileUrl: string): Promise<void> {
    const job = this.jobs.get(id);
    if (job) {
      job.fileUrl = fileUrl;
      this.jobs.set(id, job);
    }
  }

  static async findById(id: string): Promise<ExportJob | null> {
    return this.jobs.get(id) || null;
  }

  static async findByProject(projectId: string): Promise<ExportJob[]> {
    return Array.from(this.jobs.values()).filter(j => j.projectId === projectId);
  }
}
