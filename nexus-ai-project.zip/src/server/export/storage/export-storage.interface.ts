import { ExportFormat } from "../types/export.types";

export interface IExportStorage {
  /**
   * Provider identifier (e.g., 'local', 's3', 'r2')
   */
  readonly providerName: string;

  /**
   * Uploads a rendered document to storage.
   * @returns The secure, signed download URL (or local path for dev).
   */
  upload(
    workspaceId: string, 
    projectId: string, 
    jobId: string, 
    filename: string, 
    buffer: Buffer, 
    mimeType: string
  ): Promise<string>;

  /**
   * Generates a short-lived signed URL for downloading an existing file.
   */
  getSignedUrl(fileUrl: string, expiresInSeconds?: number): Promise<string>;

  /**
   * Deletes a file from storage.
   */
  delete(fileUrl: string): Promise<void>;
}
