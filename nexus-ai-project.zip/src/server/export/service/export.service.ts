import { ExportFormat, ExportJob, ExportRequest } from "../types/export.types";
import { ExportJobRepository } from "../storage/export-job.repository";
import { IExportStorage } from "../storage/export-storage.interface";
import { LocalExportStorage } from "../storage/local.storage";
import { IExportRenderer } from "../renderer/export-renderer.interface";
import { ArtifactStore } from "../../ai/orchestrator/artifact.store";
import { WrappedAgentOutput } from "../../ai/agents/agent.interface";
import { PdfRenderer } from "../renderer/pdf/pdf.renderer";
import { PptxRenderer } from "../renderer/pptx/pptx.renderer";
import { DocxRenderer } from "../renderer/docx/docx.renderer";
import { ZipRenderer } from "../renderer/zip/zip.renderer";

export class ExportService {
  private renderers = new Map<ExportFormat, IExportRenderer>();
  private storage: IExportStorage;

  constructor(
    private artifactStore: ArtifactStore
  ) {
    this.storage = new LocalExportStorage();
    this.renderers.set("pdf", new PdfRenderer());
    this.renderers.set("pptx", new PptxRenderer());
    this.renderers.set("docx", new DocxRenderer());
    this.renderers.set("zip", new ZipRenderer());
  }

  async queueExport(request: ExportRequest): Promise<ExportJob> {
    const job: ExportJob = {
      id: crypto.randomUUID(),
      workspaceId: request.workspaceId,
      projectId: request.projectId,
      generationJobId: request.generationJobId,
      userId: request.userId,
      format: request.format,
      version: request.version || "1.0",
      status: "QUEUED",
      createdAt: new Date(),
      downloadCount: 0,
      storageProvider: this.storage.providerName
    };

    await ExportJobRepository.create(job);

    // Run asynchronously to not block the request
    this.processExport(job.id).catch(console.error);

    return job;
  }

  private async processExport(jobId: string): Promise<void> {
    try {
      const job = await ExportJobRepository.findById(jobId);
      if (!job) throw new Error("Job not found");

      await ExportJobRepository.updateStatus(job.id, "PREPARING");
      
      const artifacts = await this.artifactStore.getAllLatestArtifactsForJob(job.generationJobId);
      
      const wrappedArtifacts = new Map<string, WrappedAgentOutput<any>>();
      for (const artifact of artifacts) {
        if (artifact.payload.type === "json") {
          wrappedArtifacts.set(artifact.agentId, JSON.parse(artifact.payload.content));
        }
      }

      const renderer = this.renderers.get(job.format);
      if (!renderer) throw new Error(`Renderer not found for format ${job.format}`);

      await ExportJobRepository.updateStatus(job.id, "RENDERING");
      const renderResult = await renderer.render(wrappedArtifacts);

      await ExportJobRepository.updateStatus(job.id, "UPLOADING");
      const fileUrl = await this.storage.upload(
        job.workspaceId,
        job.projectId,
        job.id,
        renderResult.filename,
        renderResult.buffer,
        renderResult.mimeType
      );

      await ExportJobRepository.updateFileUrl(job.id, fileUrl);
      await ExportJobRepository.updateStatus(job.id, "COMPLETED");

    } catch (error: any) {
      console.error(`[ExportService] Error processing job ${jobId}:`, error);
      await ExportJobRepository.updateStatus(jobId, "FAILED", error.message);
    }
  }

  async getDownloadUrl(jobId: string, userId: string): Promise<string> {
    const job = await ExportJobRepository.findById(jobId);
    if (!job) throw new Error("Job not found");
    if (job.userId !== userId) throw new Error("Unauthorized");
    if (job.status !== "COMPLETED" || !job.fileUrl) throw new Error("Export not ready");

    job.downloadCount += 1;
    job.downloadedAt = new Date();

    return this.storage.getSignedUrl(job.fileUrl);
  }

  async getExportsForProject(projectId: string, userId: string): Promise<ExportJob[]> {
    // Basic auth check
    const jobs = await ExportJobRepository.findByProject(projectId);
    return jobs.filter(j => j.userId === userId).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}
