export type ExportFormat = "pdf" | "pptx" | "docx" | "zip" | "markdown" | "json";

export type ExportStatus = 
  | "QUEUED" 
  | "PREPARING" 
  | "RENDERING" 
  | "PACKAGING" 
  | "UPLOADING" 
  | "COMPLETED" 
  | "FAILED" 
  | "CANCELLED";

export interface ExportJob {
  id: string;
  workspaceId: string;
  projectId: string;
  generationJobId: string;
  userId: string;
  format: ExportFormat;
  status: ExportStatus;
  version: string;
  createdAt: Date;
  completedAt?: Date;
  downloadedAt?: Date;
  downloadCount: number;
  storageProvider: string;
  fileUrl?: string;
  error?: string;
}

export interface ExportRequest {
  jobId: string;
  workspaceId: string;
  projectId: string;
  generationJobId: string;
  userId: string;
  format: ExportFormat;
  version?: string;
}

export interface ExportRenderResult {
  buffer: Buffer;
  filename: string;
  mimeType: string;
}
