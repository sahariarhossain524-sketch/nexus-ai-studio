import { IExportRenderer } from "../export-renderer.interface";
import { ExportRenderResult } from "../../types/export.types";
import { WrappedAgentOutput } from "../../../ai/agents/agent.interface";
import { TDocumentDefinitions } from "pdfmake/interfaces";
const PdfPrinter = require("pdfmake");

export class PdfRenderer implements IExportRenderer {
  format = "pdf";

  async render(artifacts: Map<string, WrappedAgentOutput<any>>): Promise<ExportRenderResult> {
    const fonts = {
      Roboto: {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        italics: 'Helvetica-Oblique',
        bolditalics: 'Helvetica-BoldOblique'
      }
    };
    
    // In production, we'd load real TTF fonts. For now, fallback to standard fonts
    // pdfmake allows standard fonts (Helvetica, Times, Courier) without external files if configured or if standard 14 are used.
    // However, Node pdfmake requires font files. If not provided, it fails. 
    // To keep it simple and dependency-free for this MVP architecture, we can mock the buffer or use standard fonts.
    // Assuming standard fonts are available via a basic setup.
    
    const printer = new PdfPrinter(fonts);
    
    const content: any[] = [];
    
    // Cover Page
    content.push({ text: "Nexus AI - Auto Generated Report", style: "header", margin: [0, 200, 0, 20], alignment: "center" });
    content.push({ text: `Generated on ${new Date().toLocaleDateString()}`, alignment: "center", pageBreak: "after" });
    
    // Table of Contents placeholder (pdfmake supports this natively with TOC elements)
    content.push({ toc: { title: { text: "Table of Contents", style: "header" } } });
    content.push({ text: "", pageBreak: "after" });

    // Extract business plan data
    if (artifacts.has("agent-business-strategy")) {
      const business = artifacts.get("agent-business-strategy")?.data;
      if (business) {
        content.push({ text: "Business Strategy", style: "header", tocItem: true });
        content.push({ text: "Executive Summary", style: "subheader" });
        content.push({ text: business.executiveSummary || "N/A" });
        content.push({ text: "Monetization Strategy", style: "subheader" });
        content.push({ ul: business.monetizationStrategy || [] });
        content.push({ text: "", pageBreak: "after" });
      }
    }

    // Extract marketing data
    if (artifacts.has("agent-marketing")) {
      const marketing = artifacts.get("agent-marketing")?.data;
      if (marketing) {
        content.push({ text: "Marketing Plan", style: "header", tocItem: true });
        content.push({ text: "Strategy Overview", style: "subheader" });
        content.push({ text: marketing.strategyOverview || "N/A" });
        
        if (marketing.customerJourney) {
          content.push({ text: "Customer Journey", style: "subheader" });
          marketing.customerJourney.forEach((stage: any) => {
            content.push({ text: stage.stage, bold: true });
            content.push({ text: stage.description });
          });
        }
        content.push({ text: "", pageBreak: "after" });
      }
    }

    const docDefinition: TDocumentDefinitions = {
      content,
      styles: {
        header: { fontSize: 24, bold: true, margin: [0, 0, 0, 10] },
        subheader: { fontSize: 16, bold: true, margin: [0, 15, 0, 5] },
        defaultStyle: { fontSize: 12 }
      },
      defaultStyle: {
        font: 'Roboto'
      }
    };

    return new Promise((resolve, reject) => {
      try {
        const pdfDoc = printer.createPdfKitDocument(docDefinition);
        const chunks: Buffer[] = [];
        
        pdfDoc.on("data", (chunk: Buffer) => chunks.push(chunk));
        pdfDoc.on("end", () => {
          const result = Buffer.concat(chunks);
          resolve({
            buffer: result,
            filename: "export.pdf",
            mimeType: "application/pdf"
          });
        });
        pdfDoc.on("error", (err: any) => reject(err));
        
        pdfDoc.end();
      } catch (error) {
        reject(error);
      }
    });
  }
}
