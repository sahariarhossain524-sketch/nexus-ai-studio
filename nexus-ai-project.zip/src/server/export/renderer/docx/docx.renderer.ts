import { IExportRenderer } from "../export-renderer.interface";
import { ExportRenderResult } from "../../types/export.types";
import { WrappedAgentOutput } from "../../../ai/agents/agent.interface";
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from "docx";

export class DocxRenderer implements IExportRenderer {
  format = "docx";

  async render(artifacts: Map<string, WrappedAgentOutput<any>>): Promise<ExportRenderResult> {
    const children: any[] = [];
    
    children.push(
      new Paragraph({
        text: "Nexus AI - Business Plan",
        heading: HeadingLevel.TITLE,
      })
    );

    if (artifacts.has("agent-business-strategy")) {
      const business = artifacts.get("agent-business-strategy")?.data;
      if (business) {
        children.push(
          new Paragraph({
            text: "Business Strategy",
            heading: HeadingLevel.HEADING_1,
          })
        );
        children.push(
          new Paragraph({
            text: "Executive Summary",
            heading: HeadingLevel.HEADING_2,
          })
        );
        children.push(
          new Paragraph({
            children: [
              new TextRun(business.executiveSummary || "N/A"),
            ],
          })
        );
      }
    }

    if (artifacts.has("agent-market-research")) {
      const market = artifacts.get("agent-market-research")?.data;
      if (market) {
        children.push(
          new Paragraph({
            text: "Market Research",
            heading: HeadingLevel.HEADING_1,
          })
        );
        children.push(
          new Paragraph({
            children: [
              new TextRun(market.industrySummary || "N/A"),
            ],
          })
        );
      }
    }

    const doc = new Document({
      sections: [{
        properties: {},
        children,
      }]
    });

    const buffer = await Packer.toBuffer(doc);

    return {
      buffer,
      filename: "export.docx",
      mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    };
  }
}
