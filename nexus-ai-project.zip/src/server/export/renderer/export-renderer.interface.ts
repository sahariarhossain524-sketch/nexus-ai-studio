import { ExportRenderResult } from "../types/export.types";
import { WrappedAgentOutput } from "../../ai/agents/agent.interface";

export interface IExportRenderer {
  /**
   * Identifies the format this renderer produces (e.g., 'pdf', 'pptx')
   */
  readonly format: string;

  /**
   * Renders the given artifacts into a buffer.
   * @param artifacts Map of Agent ID to their structured output
   */
  render(artifacts: Map<string, WrappedAgentOutput<any>>): Promise<ExportRenderResult>;
}
