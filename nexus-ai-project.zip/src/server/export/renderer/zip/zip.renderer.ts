import { IExportRenderer } from "../export-renderer.interface";
import { ExportRenderResult } from "../../types/export.types";
import { WrappedAgentOutput } from "../../../ai/agents/agent.interface";
import * as archiverType from "archiver";
const archiver = require("archiver");

export class ZipRenderer implements IExportRenderer {
  format = "zip";

  async render(artifacts: Map<string, WrappedAgentOutput<any>>): Promise<ExportRenderResult> {
    return new Promise((resolve, reject) => {
      const archive = archiver('zip', {
        zlib: { level: 9 } // Sets the compression level.
      });

      const chunks: Buffer[] = [];
      archive.on('data', (chunk: Buffer) => chunks.push(chunk));
      
      archive.on('end', () => {
        const buffer = Buffer.concat(chunks);
        resolve({
          buffer,
          filename: "export.zip",
          mimeType: "application/zip"
        });
      });

      archive.on('error', (err: any) => {
        reject(err);
      });

      // Add files
      for (const [agentId, wrappedOutput] of artifacts.entries()) {
        const jsonContent = JSON.stringify(wrappedOutput, null, 2);
        archive.append(jsonContent, { name: `${agentId}.json` });
      }

      const manifest = {
        generatedAt: new Date().toISOString(),
        version: "1.0",
        artifactsIncluded: Array.from(artifacts.keys())
      };
      archive.append(JSON.stringify(manifest, null, 2), { name: "manifest.json" });

      archive.finalize();
    });
  }
}
