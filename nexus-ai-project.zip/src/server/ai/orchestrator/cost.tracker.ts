export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface CostRecord {
  agentId: string;
  provider: string;
  model: string;
  usage: TokenUsage;
  estimatedCostUsd: number;
  runtimeMs: number;
}

export class CostTracker {
  private records: CostRecord[] = [];

  recordCost(record: CostRecord): void {
    this.records.push(record);
  }

  getTotalCost(): number {
    return this.records.reduce((acc, curr) => acc + curr.estimatedCostUsd, 0);
  }

  getTotalTokens(): number {
    return this.records.reduce((acc, curr) => acc + curr.usage.totalTokens, 0);
  }

  getRecords(): CostRecord[] {
    return [...this.records];
  }
}
