import { AIAgent, AgentExecutionResult } from "../agents/agent.interface";
import { ExecutionContext } from "./execution.context";
import { CostTracker } from "./cost.tracker";
import { OrchestrationTask } from "./orchestrator.types";
import { ArtifactStore } from "./artifact.store";
import { IEventBus } from "../../events/event-bus.interface";

export class AgentRuntime {
  constructor(
    private readonly artifactStore: ArtifactStore,
    private readonly costTracker: CostTracker,
    private readonly eventBus: IEventBus
  ) {}

  async executeTask(task: OrchestrationTask, agent: AIAgent, context: ExecutionContext): Promise<AgentExecutionResult> {
    console.log(`[AgentRuntime] Initializing ${agent.name} for task ${task.id}...`);
    
    // Convert ExecutionContext to GlobalContextPayload shape if necessary, 
    // or just pass it as any for now since interfaces will merge.
    await agent.initialize(context as any);
    
    console.log(`[AgentRuntime] Planning ${agent.name}...`);
    await agent.plan(task.payload);
    
    console.log(`[AgentRuntime] Executing ${agent.name}...`);
    const startTime = Date.now();
    await agent.execute(task.payload);
    const runtimeMs = Date.now() - startTime;
    
    console.log(`[AgentRuntime] Validating ${agent.name}...`);
    const isValid = await agent.validate();
    
    if (!isValid) {
      throw new Error(`Agent ${agent.name} failed validation.`);
    }

    console.log(`[AgentRuntime] Completing ${agent.name}...`);
    const result = await agent.complete();

    if (result.success) {
      // Save artifacts
      for (const artifact of result.artifacts) {
        await this.artifactStore.saveArtifact(context.jobId, task.agentId, artifact);
        
        this.eventBus.publish({
          eventId: crypto.randomUUID(),
          jobId: context.jobId,
          workspaceId: context.workspaceId,
          projectId: context.projectId,
          agentId: agent.id,
          eventType: "artifact.created",
          timestamp: new Date().toISOString(),
          status: "success",
          payload: { artifact }
        });
      }
      
      // Mock cost tracking
      this.costTracker.recordCost({
        agentId: agent.id,
        provider: context.providerConfig.provider,
        model: context.providerConfig.model,
        usage: { promptTokens: 100, completionTokens: 50, totalTokens: 150 },
        estimatedCostUsd: 0.002,
        runtimeMs
      });
    }

    return result;
  }
}
