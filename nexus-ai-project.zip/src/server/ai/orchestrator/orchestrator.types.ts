export type TaskStatus = 
  | "READY"
  | "BLOCKED"
  | "RUNNING"
  | "COMPLETED"
  | "FAILED"
  | "SKIPPED"
  | "CANCELLED";

export type CriticDecision = 
  | "APPROVED"
  | "REVISION_REQUIRED"
  | "REJECTED";

export interface RetryStrategy {
  maxRetries: number;
  backoffMs: number;
}

export interface OrchestrationTask {
  id: string;
  agentId: string;
  dependencies: string[];
  payload: Record<string, any>;
  status: TaskStatus;
  retryStrategy?: RetryStrategy;
}

export interface OrchestrationPlan {
  jobId: string;
  tasks: OrchestrationTask[];
}

export interface FailureContext {
  taskId: string;
  agentId: string;
  error: Error;
  attemptCount: number;
}
