import { OrchestrationPlan, OrchestrationTask } from "./orchestrator.types";

export class DependencyResolver {
  /**
   * Updates the status of tasks based on completed dependencies.
   * Modifies the plan in place and returns tasks that just became READY.
   */
  resolveReadyTasks(plan: OrchestrationPlan): OrchestrationTask[] {
    const readyTasks: OrchestrationTask[] = [];
    const taskMap = new Map<string, OrchestrationTask>(
      plan.tasks.map(t => [t.id, t])
    );

    for (const task of plan.tasks) {
      if (task.status === "BLOCKED") {
        const canRun = task.dependencies.every(depId => {
          const depTask = taskMap.get(depId);
          return depTask && (depTask.status === "COMPLETED" || depTask.status === "SKIPPED");
        });

        if (canRun) {
          task.status = "READY";
          readyTasks.push(task);
        }
      }
    }

    return readyTasks;
  }

  hasFailedTasks(plan: OrchestrationPlan): boolean {
    return plan.tasks.some(t => t.status === "FAILED");
  }

  isFullyCompleted(plan: OrchestrationPlan): boolean {
    return plan.tasks.every(t => t.status === "COMPLETED" || t.status === "SKIPPED");
  }
}
