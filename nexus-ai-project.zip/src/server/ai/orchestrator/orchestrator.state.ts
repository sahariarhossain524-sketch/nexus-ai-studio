export type OrchestratorJobState = 
  | "INITIALIZING"
  | "PLANNING"
  | "EXECUTING"
  | "PAUSED"
  | "RECOVERING"
  | "COMPLETED"
  | "FAILED"
  | "CANCELLED";

export interface OrchestratorState {
  jobId: string;
  status: OrchestratorJobState;
  completedTasks: string[];
  failedTasks: string[];
  activeTasks: string[];
}
