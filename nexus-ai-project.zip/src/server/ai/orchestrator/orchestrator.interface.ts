import { AIAgent } from "../agents/agent.interface";
import { GlobalContextPayload } from "../context/context.engine";

export interface TaskDefinition {
  id: string;
  agentId: string;
  dependencies: string[]; // Task IDs that must complete first
  payload: Record<string, any>;
}

export interface ExecutionPlan {
  jobId: string;
  tasks: TaskDefinition[];
}

export interface Orchestrator {
  /**
   * Generates a DAG (Directed Acyclic Graph) of tasks based on the global context
   */
  plan(jobId: string, context: GlobalContextPayload): Promise<ExecutionPlan>;
  
  /**
   * Resolves which tasks can run next based on completed dependencies
   */
  resolveDependencies(plan: ExecutionPlan, completedTaskIds: string[]): TaskDefinition[];
  
  /**
   * Dispatches tasks to appropriate agents
   */
  schedule(tasks: TaskDefinition[], availableAgents: AIAgent[]): Promise<void>;
  
  /**
   * Monitors execution progress
   */
  trackProgress(jobId: string): Promise<number>; // Returns 0-100 percentage
  
  /**
   * Handles agent failures and attempts recovery/retries
   */
  recoverFailure(failedTaskId: string, error: Error): Promise<boolean>; // Returns true if recovered
  
  /**
   * Compiles all agent outputs into final assets
   */
  aggregateResults(jobId: string): Promise<void>;
}
