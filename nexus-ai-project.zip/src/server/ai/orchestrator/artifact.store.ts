export interface VersionedArtifact {
  jobId: string;
  agentId: string;
  version: string;
  payload: Record<string, any>;
  createdAt: string;
}

export class ArtifactStore {
  private store = new Map<string, VersionedArtifact[]>();

  async saveArtifact(jobId: string, agentId: string, artifactPayload: any): Promise<void> {
    const key = `${jobId}:${agentId}`;
    const existing = this.store.get(key) || [];
    
    const versionNumber = existing.length + 1;
    const versionStr = `v1.0.${versionNumber}`;
    
    const record: VersionedArtifact = {
      jobId,
      agentId,
      version: versionStr,
      payload: artifactPayload,
      createdAt: new Date().toISOString()
    };
    
    existing.push(record);
    this.store.set(key, existing);
    console.log(`[ArtifactStore] Saved artifact ${versionStr} for ${agentId}`);
  }

  async getLatestArtifact(jobId: string, agentId: string): Promise<VersionedArtifact | null> {
    const key = `${jobId}:${agentId}`;
    const existing = this.store.get(key);
    if (!existing || existing.length === 0) return null;
    
    return existing[existing.length - 1];
  }

  async getAllLatestArtifactsForJob(jobId: string): Promise<VersionedArtifact[]> {
    const results: VersionedArtifact[] = [];
    for (const [key, versions] of this.store.entries()) {
      if (key.startsWith(`${jobId}:`) && versions.length > 0) {
        results.push(versions[versions.length - 1]);
      }
    }
    return results;
  }
}
