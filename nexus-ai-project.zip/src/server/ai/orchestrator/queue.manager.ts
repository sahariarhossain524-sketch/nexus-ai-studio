import { OrchestrationTask } from "./orchestrator.types";

export interface QueueManager {
  addJob(jobId: string, task: OrchestrationTask): Promise<void>;
  processJobs(handler: (jobId: string, task: OrchestrationTask) => Promise<void>): void;
}

export class InMemoryQueue implements QueueManager {
  private queue: { jobId: string; task: OrchestrationTask }[] = [];
  private handler: ((jobId: string, task: OrchestrationTask) => Promise<void>) | null = null;
  private processing = false;

  async addJob(jobId: string, task: OrchestrationTask): Promise<void> {
    this.queue.push({ jobId, task });
    console.log(`[InMemoryQueue] Added task ${task.id} to queue. Length: ${this.queue.length}`);
    this.triggerProcessing();
  }

  processJobs(handler: (jobId: string, task: OrchestrationTask) => Promise<void>): void {
    this.handler = handler;
    this.triggerProcessing();
  }

  private async triggerProcessing() {
    if (this.processing || !this.handler || this.queue.length === 0) return;
    
    this.processing = true;
    while (this.queue.length > 0) {
      const job = this.queue.shift();
      if (job) {
        try {
          await this.handler(job.jobId, job.task);
        } catch (error) {
          console.error(`[InMemoryQueue] Task ${job.task.id} failed in processing loop`, error);
        }
      }
    }
    this.processing = false;
  }
}
