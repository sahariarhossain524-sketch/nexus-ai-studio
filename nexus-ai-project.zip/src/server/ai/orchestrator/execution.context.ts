export interface AIProviderConfig {
  provider: "Gemini" | "OpenAI" | "OpenRouter";
  model: string;
  temperature: number;
}

export interface ExecutionContext {
  jobId: string;
  userId: string;
  workspaceId: string;
  projectId: string;
  
  // High-level constraints from the user
  constraints: Record<string, any>;
  
  // State shared across agents during generation
  memory: Record<string, any>;
  
  // LLM specifics
  providerConfig: AIProviderConfig;
}
