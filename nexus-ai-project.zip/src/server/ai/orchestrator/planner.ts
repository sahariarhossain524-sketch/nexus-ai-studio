import { OrchestrationPlan } from "./orchestrator.types";
import { GlobalContextPayload } from "../context/context.engine";

export interface ExecutionPlanner {
  /**
   * Evaluates the generation job and global context to formulate a directed acyclic graph (DAG)
   * of tasks for the Orchestrator to execute.
   */
  createPlan(jobId: string, context: GlobalContextPayload): Promise<OrchestrationPlan>;
  
  /**
   * Validates if the created plan is cyclic (which would cause a deadlock)
   */
  validatePlan(plan: OrchestrationPlan): boolean;
}
