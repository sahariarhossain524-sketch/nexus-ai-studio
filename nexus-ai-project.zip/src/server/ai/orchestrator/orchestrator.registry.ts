import { OrchestratorService } from "./orchestrator.service";
import { HardcodedPipelinePlanner } from "./execution.planner";
import { DependencyResolver } from "./dependency.resolver";
import { InMemoryQueue } from "./queue.manager";
import { AgentRuntime } from "./agent.runtime";
import { ProgressTracker } from "./progress.tracker";
import { CriticGate } from "./critic.gate";
import { ArtifactStore } from "./artifact.store";
import { InMemoryEventBus } from "../../events/in-memory-event-bus";
import { CostTracker } from "./cost.tracker";
import { MarketResearchAgent } from "../agents/market/market.agent";
import { BusinessStrategyAgent } from "../agents/business/business.agent";
import { BrandingAgent } from "../agents/branding/branding.agent";
import { MarketingAgent } from "../agents/marketing/marketing.agent";
import { PitchDeckAgent } from "../agents/pitchdeck/pitchdeck.agent";
import { CriticAgent } from "../agents/critic/critic.agent";
import { ProviderManager } from "../providers/provider.manager";

// Singletons
const eventBus = InMemoryEventBus.getInstance();
const planner = new HardcodedPipelinePlanner();
const resolver = new DependencyResolver();
const queue = new InMemoryQueue();
const artifactStore = new ArtifactStore();
const costTracker = new CostTracker();
const runtime = new AgentRuntime(artifactStore, costTracker, eventBus);
const progress = new ProgressTracker(eventBus);
const criticGate = new CriticGate();
const providerManager = new ProviderManager();

// Agents
const agentRegistry = new Map();
const marketAgent = new MarketResearchAgent();
const businessAgent = new BusinessStrategyAgent();
const brandingAgent = new BrandingAgent();
const marketingAgent = new MarketingAgent();
const pitchDeckAgent = new PitchDeckAgent();
const criticAgent = new CriticAgent();

agentRegistry.set(marketAgent.id, marketAgent);
agentRegistry.set(businessAgent.id, businessAgent);
agentRegistry.set(brandingAgent.id, brandingAgent);
agentRegistry.set(marketingAgent.id, marketingAgent);
agentRegistry.set(pitchDeckAgent.id, pitchDeckAgent);
agentRegistry.set(criticAgent.id, criticAgent);

export const orchestrator = new OrchestratorService(
  planner,
  resolver,
  queue,
  runtime,
  progress,
  criticGate,
  agentRegistry
);
