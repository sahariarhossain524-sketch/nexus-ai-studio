import { OrchestrationPlan, OrchestrationTask } from "./orchestrator.types";
import { ExecutionContext } from "./execution.context";

export interface ExecutionPlanner {
  createPlan(context: ExecutionContext): Promise<OrchestrationPlan>;
}

export class HardcodedPipelinePlanner implements ExecutionPlanner {
  async createPlan(context: ExecutionContext): Promise<OrchestrationPlan> {
    const tasks: OrchestrationTask[] = [
      {
        id: "task-market",
        agentId: "agent-market-research",
        dependencies: [],
        payload: { idea: context.constraints.idea },
        status: "READY",
        retryStrategy: { maxRetries: 3, backoffMs: 2000 }
      },
      {
        id: "task-business",
        agentId: "agent-business-strategy",
        dependencies: ["task-market"],
        payload: { idea: context.constraints.idea },
        status: "BLOCKED",
        retryStrategy: { maxRetries: 3, backoffMs: 2000 }
      },
      {
        id: "task-branding",
        agentId: "agent-branding",
        dependencies: ["task-business"],
        payload: { idea: context.constraints.idea },
        status: "BLOCKED",
        retryStrategy: { maxRetries: 3, backoffMs: 2000 }
      },
      {
        id: "task-marketing",
        agentId: "agent-marketing",
        dependencies: ["task-business"], // Runs parallel to branding based on DAG, but typically after
        payload: { idea: context.constraints.idea },
        status: "BLOCKED",
        retryStrategy: { maxRetries: 3, backoffMs: 2000 }
      },
      {
        id: "task-pitchdeck",
        agentId: "agent-pitchdeck",
        dependencies: ["task-branding", "task-marketing"],
        payload: { idea: context.constraints.idea },
        status: "BLOCKED",
        retryStrategy: { maxRetries: 3, backoffMs: 2000 }
      },
      {
        id: "task-critic",
        agentId: "agent-critic",
        dependencies: ["task-pitchdeck"],
        payload: { idea: context.constraints.idea },
        status: "BLOCKED",
        retryStrategy: { maxRetries: 3, backoffMs: 2000 }
      }
    ];

    return {
      jobId: context.jobId,
      tasks
    };
  }
}
