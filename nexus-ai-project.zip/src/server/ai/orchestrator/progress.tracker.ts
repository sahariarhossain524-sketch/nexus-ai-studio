import { IEventBus } from "../../events/event-bus.interface";

export interface JobProgress {
  jobId: string;
  workspaceId: string;
  projectId: string;
  currentAgent: string | null;
  completedAgents: string[];
  remainingAgents: string[];
  etaMs: number | null;
  tokensUsed: number;
  costEstimateUsd: number;
  startedAt: string | null;
  finishedAt: string | null;
}

export class ProgressTracker {
  private tracking = new Map<string, JobProgress>();

  constructor(private eventBus: IEventBus) {}

  initJob(jobId: string, workspaceId: string, projectId: string, allAgents: string[]): void {
    this.tracking.set(jobId, {
      jobId,
      workspaceId,
      projectId,
      currentAgent: null,
      completedAgents: [],
      remainingAgents: allAgents,
      etaMs: null,
      tokensUsed: 0,
      costEstimateUsd: 0,
      startedAt: new Date().toISOString(),
      finishedAt: null
    });

    this.eventBus.publish({
      eventId: crypto.randomUUID(),
      jobId,
      workspaceId,
      projectId,
      eventType: "generation.started",
      timestamp: new Date().toISOString(),
      status: "in_progress"
    });
  }

  updateMetrics(
    jobId: string, 
    metrics: { tokensUsed?: number; costEstimateUsd?: number }
  ): void {
    const job = this.tracking.get(jobId);
    if (job) {
      if (metrics.tokensUsed) job.tokensUsed += metrics.tokensUsed;
      if (metrics.costEstimateUsd) job.costEstimateUsd += metrics.costEstimateUsd;
    }
  }

  startAgent(jobId: string, agentId: string): void {
    const job = this.tracking.get(jobId);
    if (job) {
      job.currentAgent = agentId;
      job.remainingAgents = job.remainingAgents.filter(a => a !== agentId);
      
      this.eventBus.publish({
        eventId: crypto.randomUUID(),
        jobId,
        workspaceId: job.workspaceId,
        projectId: job.projectId,
        agentId,
        eventType: "agent.started",
        timestamp: new Date().toISOString(),
        status: "in_progress",
        payload: { completed: job.completedAgents.length, total: job.completedAgents.length + job.remainingAgents.length + 1 }
      });
    }
  }

  finishAgent(jobId: string, agentId: string, failed: boolean = false): void {
    const job = this.tracking.get(jobId);
    if (job) {
      if (!failed) {
        job.completedAgents.push(agentId);
      }
      job.currentAgent = null;

      this.eventBus.publish({
        eventId: crypto.randomUUID(),
        jobId,
        workspaceId: job.workspaceId,
        projectId: job.projectId,
        agentId,
        eventType: failed ? "agent.failed" : "agent.completed",
        timestamp: new Date().toISOString(),
        status: failed ? "error" : "success"
      });
    }
  }

  finishJob(jobId: string, failed: boolean = false): void {
    const job = this.tracking.get(jobId);
    if (job) {
      job.finishedAt = new Date().toISOString();

      this.eventBus.publish({
        eventId: crypto.randomUUID(),
        jobId,
        workspaceId: job.workspaceId,
        projectId: job.projectId,
        eventType: failed ? "generation.failed" : "generation.completed",
        timestamp: new Date().toISOString(),
        status: failed ? "error" : "success"
      });
    }
  }

  getSnapshot(jobId: string): JobProgress | null {
    return this.tracking.get(jobId) || null;
  }
}
