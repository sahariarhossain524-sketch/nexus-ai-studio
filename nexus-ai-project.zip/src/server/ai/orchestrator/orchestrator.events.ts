import { OrchestratorState } from "./orchestrator.state";

export interface OrchestratorEventMap {
  "orchestrator.job.initialized": { jobId: string };
  "orchestrator.job.cancelled": { jobId: string; reason: string };
  "orchestrator.plan.created": { jobId: string; taskCount: number };
  "orchestrator.task.started": { jobId: string; taskId: string; agentId: string };
  "orchestrator.task.completed": { jobId: string; taskId: string };
  "orchestrator.task.failed": { jobId: string; taskId: string; error: Error };
  "orchestrator.task.recovering": { jobId: string; taskId: string; attempt: number };
  "orchestrator.job.completed": { jobId: string; state: OrchestratorState };
  "orchestrator.job.failed": { jobId: string; reason: string; state: OrchestratorState };
}
