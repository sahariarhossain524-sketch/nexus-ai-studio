import { OrchestrationPlan } from "./orchestrator.types";

export interface AggregationResult {
  jobId: string;
  projectId: string;
  totalAssetsGenerated: number;
  finalPayload: Record<string, any>;
}

export interface ResultAggregator {
  /**
   * Collects all intermediate artifacts produced by agents during the execution plan
   */
  collectTaskOutputs(jobId: string, plan: OrchestrationPlan): Promise<Record<string, any>>;
  
  /**
   * Compiles and formats the collected outputs into the final asset structure
   */
  compileFinalResult(jobId: string, projectId: string, rawOutputs: Record<string, any>): Promise<AggregationResult>;
}
