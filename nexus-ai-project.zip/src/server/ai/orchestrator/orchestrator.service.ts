import { ExecutionContext } from "./execution.context";
import { ExecutionPlanner } from "./execution.planner";
import { DependencyResolver } from "./dependency.resolver";
import { QueueManager } from "./queue.manager";
import { AgentRuntime } from "./agent.runtime";
import { ProgressTracker } from "./progress.tracker";
import { CriticGate } from "./critic.gate";
import { OrchestrationPlan, OrchestrationTask } from "./orchestrator.types";
import { AIAgent } from "../agents/agent.interface";

export class OrchestratorService {
  private activePlans = new Map<string, OrchestrationPlan>();

  constructor(
    private planner: ExecutionPlanner,
    private resolver: DependencyResolver,
    private queue: QueueManager,
    private runtime: AgentRuntime,
    private progress: ProgressTracker,
    private criticGate: CriticGate,
    private agentRegistry: Map<string, AIAgent>
  ) {
    // Setup queue handler
    this.queue.processJobs(async (jobId, task) => {
      await this.executeTask(jobId, task);
    });
  }

  async startJob(context: ExecutionContext): Promise<string> {
    const plan = await this.planner.createPlan(context);
    this.activePlans.set(context.jobId, plan);
    
    // Initialize Tracker
    const allAgentIds = plan.tasks.map(t => t.agentId);
    this.progress.initJob(context.jobId, context.workspaceId, context.projectId, allAgentIds);

    // Initial Resolution
    this.scheduleReadyTasks(context.jobId);
    return context.jobId;
  }

  private scheduleReadyTasks(jobId: string) {
    const plan = this.activePlans.get(jobId);
    if (!plan) return;

    const readyTasks = this.resolver.resolveReadyTasks(plan);
    for (const task of readyTasks) {
      task.status = "RUNNING"; // Optimistically set to running before queue
      this.queue.addJob(jobId, task);
    }

    if (this.resolver.isFullyCompleted(plan)) {
      this.progress.finishJob(jobId);
      console.log(`[Orchestrator] Job ${jobId} fully completed!`);
    } else if (this.resolver.hasFailedTasks(plan)) {
      this.progress.finishJob(jobId, true); // We halt on hard failures for now
      console.error(`[Orchestrator] Job ${jobId} failed!`);
    }
  }

  private async executeTask(jobId: string, task: OrchestrationTask) {
    const agent = this.agentRegistry.get(task.agentId);
    if (!agent) {
      console.error(`[Orchestrator] Agent ${task.agentId} not found`);
      task.status = "FAILED";
      this.scheduleReadyTasks(jobId);
      return;
    }

    this.progress.startAgent(jobId, agent.id);

    try {
      // Create a dummy context for the agent runtime
      // In a full implementation, we should pass the original context down.
      // For now, we will extract it from the progress tracker if needed, or mock it.
      const jobSnapshot = this.progress.getSnapshot(jobId);
      const context: ExecutionContext = {
        jobId,
        userId: "system", // Would be pulled from real context
        workspaceId: jobSnapshot?.workspaceId || "system",
        projectId: jobSnapshot?.projectId || "system",
        constraints: {},
        memory: {},
        providerConfig: { provider: "Gemini", model: "gemini-2.5-pro", temperature: 0.7 }
      };

      const result = await this.runtime.executeTask(task, agent, context);

      if (result.success) {
        task.status = "COMPLETED";
        this.progress.finishAgent(jobId, agent.id);
        
        // If this was the critic agent, apply the Critic Gate
        if (task.agentId === "agent-critic") {
          const criticPayload = JSON.parse(result.artifacts[1].content).data;
          const report = this.criticGate.evaluateCriticOutput(criticPayload);
          
          if (report.decision === "REVISION_REQUIRED") {
            console.warn(`[Orchestrator] Critic requested revision for: ${report.failedAgents.join(", ")}`);
            // In a full implementation, we would set those tasks back to "READY" and re-resolve dependencies.
          }
        }
      } else {
        task.status = "FAILED";
        this.progress.finishAgent(jobId, agent.id, true);
      }
    } catch (error) {
      console.error(`[Orchestrator] Error executing ${task.agentId}`, error);
      task.status = "FAILED";
      this.progress.finishAgent(jobId, agent.id, true);
    } finally {
      // Trigger resolution for downstream tasks
      this.scheduleReadyTasks(jobId);
    }
  }
}
