export interface EventBusPayloads {
  "generation.started": { jobId: string; projectId: string };
  "generation.progress": { jobId: string; progress: number; state: string };
  "agent.started": { jobId: string; agentId: string; taskId: string };
  "agent.completed": { jobId: string; agentId: string; taskId: string; result: any };
  "agent.failed": { jobId: string; agentId: string; taskId: string; error: string };
  "generation.completed": { jobId: string; finalAssets: string[] };
  "generation.failed": { jobId: string; error: string };
}

export type EventBusCallback<T extends keyof EventBusPayloads> = (payload: EventBusPayloads[T]) => void;

export interface EventBus {
  /**
   * Publishes an event to the orchestrator ecosystem
   */
  publish<T extends keyof EventBusPayloads>(event: T, payload: EventBusPayloads[T]): Promise<void>;
  
  /**
   * Subscribes to a specific event
   */
  subscribe<T extends keyof EventBusPayloads>(event: T, callback: EventBusCallback<T>): () => void;
}
