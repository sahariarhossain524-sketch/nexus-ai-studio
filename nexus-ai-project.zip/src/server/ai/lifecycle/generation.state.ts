export type GenerationState = 
  | "DRAFT"
  | "QUEUED"
  | "PLANNING"
  | "RUNNING"
  | "WAITING"
  | "REVIEW"
  | "COMPLETED"
  | "FAILED"
  | "CANCELLED";

export interface StateTransitionEvent {
  from: GenerationState;
  to: GenerationState;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface StateMachine {
  currentState: GenerationState;
  history: StateTransitionEvent[];
  
  canTransitionTo(nextState: GenerationState): boolean;
  transitionTo(nextState: GenerationState, metadata?: Record<string, any>): void;
}
