import { AIAgent } from "./agent.interface";

export interface AgentRegistry {
  /**
   * Registers a new agent capability into the orchestrator ecosystem
   */
  registerAgent(agent: AIAgent): void;
  
  /**
   * Removes an agent from the ecosystem
   */
  unregisterAgent(agentId: string): void;
  
  /**
   * Retrieves an agent by its unique identifier
   */
  getAgent(agentId: string): AIAgent | undefined;
  
  /**
   * Lists all available agents registered in the system
   */
  listAgents(): AIAgent[];
}
