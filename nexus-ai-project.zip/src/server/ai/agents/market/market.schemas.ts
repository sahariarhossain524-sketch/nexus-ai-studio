import { z } from "zod";

export const CustomerPersonaSchema = z.object({
  name: z.string().min(1, "Name is required"),
  demographics: z.string().min(1, "Demographics are required"),
  painPoints: z.array(z.string()).min(1, "At least one pain point is required"),
  goals: z.array(z.string()).min(1, "At least one goal is required"),
});

export const CompetitorSchema = z.object({
  name: z.string().min(1, "Name is required"),
  strengths: z.array(z.string()).min(1),
  weaknesses: z.array(z.string()).min(1),
});

export const MarketAgentOutputSchema = z.object({
  industrySummary: z.string().min(10, "Industry summary must be substantial"),
  targetAudience: z.string().min(5, "Target audience must be specified"),
  customerPersonas: z.array(CustomerPersonaSchema).min(1, "At least one persona required"),
  competitorOverview: z.array(CompetitorSchema).min(1, "At least one competitor required"),
  marketOpportunities: z.array(z.string()).min(1, "At least one opportunity required"),
  marketRisks: z.array(z.string()).min(1, "At least one risk required"),
  industryTrends: z.array(z.string()).min(1, "At least one trend required"),
  swotSnapshot: z.object({
    strengths: z.array(z.string()).min(1),
    weaknesses: z.array(z.string()).min(1),
    opportunities: z.array(z.string()).min(1),
    threats: z.array(z.string()).min(1),
  }),
  confidenceScore: z.number().min(0).max(100),
  missingInformation: z.array(z.string()),
});
