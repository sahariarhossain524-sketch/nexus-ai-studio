export interface MarketAgentInput {
  idea: string;
  targetCountry: string;
  industry: string;
  constraints?: string;
}

export interface CustomerPersona {
  name: string;
  demographics: string;
  painPoints: string[];
  goals: string[];
}

export interface Competitor {
  name: string;
  strengths: string[];
  weaknesses: string[];
}

export interface MarketAgentOutput {
  industrySummary: string;
  targetAudience: string;
  customerPersonas: CustomerPersona[];
  competitorOverview: Competitor[];
  marketOpportunities: string[];
  marketRisks: string[];
  industryTrends: string[];
  swotSnapshot: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
  confidenceScore: number; // 0-100
  missingInformation: string[];
}
