import { MarketAgentOutput } from "./market.types";

export class MarketOutputFormatter {
  static formatToMarkdown(data: MarketAgentOutput): string {
    let md = `# Market Research Report\n\n`;
    
    md += `## Industry Summary\n${data.industrySummary}\n\n`;
    
    md += `## Target Audience\n${data.targetAudience}\n\n`;
    
    md += `## Customer Personas\n`;
    data.customerPersonas.forEach(p => {
      md += `### ${p.name}\n`;
      md += `- **Demographics:** ${p.demographics}\n`;
      md += `- **Pain Points:** ${p.painPoints.join(", ")}\n`;
      md += `- **Goals:** ${p.goals.join(", ")}\n\n`;
    });
    
    md += `## Competitor Overview\n`;
    data.competitorOverview.forEach(c => {
      md += `### ${c.name}\n`;
      md += `- **Strengths:** ${c.strengths.join(", ")}\n`;
      md += `- **Weaknesses:** ${c.weaknesses.join(", ")}\n\n`;
    });
    
    md += `## SWOT Snapshot\n`;
    md += `- **Strengths:** ${data.swotSnapshot.strengths.join(", ")}\n`;
    md += `- **Weaknesses:** ${data.swotSnapshot.weaknesses.join(", ")}\n`;
    md += `- **Opportunities:** ${data.swotSnapshot.opportunities.join(", ")}\n`;
    md += `- **Threats:** ${data.swotSnapshot.threats.join(", ")}\n\n`;
    
    md += `## Market Opportunities\n`;
    data.marketOpportunities.forEach(o => md += `- ${o}\n`);
    md += `\n`;
    
    md += `## Market Risks\n`;
    data.marketRisks.forEach(r => md += `- ${r}\n`);
    md += `\n`;
    
    md += `## Industry Trends\n`;
    data.industryTrends.forEach(t => md += `- ${t}\n`);
    md += `\n`;
    
    md += `## Analysis Confidence\n**Score:** ${data.confidenceScore}/100\n\n`;
    
    if (data.missingInformation && data.missingInformation.length > 0) {
      md += `## Missing Information (Needs Human Input)\n`;
      data.missingInformation.forEach(m => md += `- ${m}\n`);
    }
    
    return md;
  }
}
