import { AIAgent, AgentExecutionResult, WrappedAgentOutput } from "../agent.interface";
import { GlobalContextPayload } from "../../context/context.engine";
import { MarketAgentInput, MarketAgentOutput } from "./market.types";
import { MarketAgentOutputSchema } from "./market.schemas";
import { MarketOutputFormatter } from "./market.output";
import { MarketResearchPromptTemplate } from "./market.prompts";

export class MarketResearchAgent implements AIAgent {
  id = "agent-market-research";
  name = "Market Research Agent";
  
  private context: GlobalContextPayload | null = null;
  private inputPayload: MarketAgentInput | null = null;
  private rawOutput: any = null;
  private validatedOutput: MarketAgentOutput | null = null;

  async initialize(context: GlobalContextPayload): Promise<void> {
    this.context = context;
  }

  async plan(taskPayload: Record<string, any>): Promise<string[]> {
    this.inputPayload = taskPayload as MarketAgentInput;
    return [
      "Analyze Idea & Industry",
      "Identify Target Audience & Personas",
      "Analyze Competitors & SWOT",
      "Format JSON Output"
    ];
  }

  async execute(taskPayload: Record<string, any>): Promise<void> {
    if (!this.inputPayload) throw new Error("Agent not planned");

    // In a real implementation, this is where we would call the AI Provider Layer
    // using the PromptRegistry to compile the MarketResearchPromptTemplate
    // Mocking the execution step for the architecture scaffold:
    
    this.rawOutput = {
      industrySummary: "Simulated Industry Summary",
      targetAudience: "Simulated Audience",
      customerPersonas: [
        {
          name: "Simulated Persona",
          demographics: "Age 25-34",
          painPoints: ["Pain 1"],
          goals: ["Goal 1"]
        }
      ],
      competitorOverview: [
        {
          name: "Simulated Competitor",
          strengths: ["Strength 1"],
          weaknesses: ["Weakness 1"]
        }
      ],
      marketOpportunities: ["Opp 1"],
      marketRisks: ["Risk 1"],
      industryTrends: ["Trend 1"],
      swotSnapshot: {
        strengths: ["S1"],
        weaknesses: ["W1"],
        opportunities: ["O1"],
        threats: ["T1"]
      },
      confidenceScore: 80,
      missingInformation: []
    };
  }

  async validate(): Promise<boolean> {
    if (!this.rawOutput) throw new Error("No output generated");
    
    try {
      this.validatedOutput = MarketAgentOutputSchema.parse(this.rawOutput);
      return true;
    } catch (error) {
      console.error("Market Agent Validation Error:", error);
      return false;
    }
  }

  async complete(): Promise<AgentExecutionResult> {
    if (!this.validatedOutput) {
      return {
        success: false,
        artifacts: [],
        error: "Validation failed or execution incomplete"
      };
    }

    const markdownContent = MarketOutputFormatter.formatToMarkdown(this.validatedOutput);

    const wrappedOutput: WrappedAgentOutput<MarketAgentOutput> = {
      metadata: {
        agentId: this.id,
        version: "1.0",
        generatedAt: new Date().toISOString(),
        confidenceScore: this.validatedOutput.confidenceScore,
        dependencies: []
      },
      data: this.validatedOutput
    };

    return {
      success: true,
      artifacts: [
        {
          type: "markdown",
          name: "Market_Research_Report.md",
          content: markdownContent
        },
        {
          type: "json",
          name: "market_data.json",
          content: JSON.stringify(wrappedOutput, null, 2)
        }
      ],
      metadata: wrappedOutput.metadata
    };
  }
}
