import { GlobalContextPayload } from "../context/context.engine";

export interface AgentOutputMetadata {
  agentId: string;
  version: string;
  generatedAt: string;
  confidenceScore: number;
  dependencies: string[];
}

export interface WrappedAgentOutput<T> {
  metadata: AgentOutputMetadata;
  data: T;
}

export interface AgentExecutionResult {
  success: boolean;
  artifacts: Array<{ type: string; name: string; content: string }>;
  error?: string;
  metadata?: Record<string, any>;
}

export interface AIAgent {
  /**
   * Unique identifier for the agent role (e.g. "brand-strategist")
   */
  id: string;
  
  /**
   * Human-readable name (e.g. "Brand Strategy Agent")
   */
  name: string;

  /**
   * Prepares the agent with necessary context before execution
   */
  initialize(context: GlobalContextPayload): Promise<void>;

  /**
   * Determines the internal steps the agent will take to complete its task
   */
  plan(taskPayload: Record<string, any>): Promise<string[]>;

  /**
   * Executes the core logic (calling LLMs, fetching data)
   */
  execute(taskPayload: Record<string, any>): Promise<void>;

  /**
   * Validates the generated output against quality gates and requirements
   */
  validate(): Promise<boolean>;

  /**
   * Finalizes execution and returns the formatted artifacts
   */
  complete(): Promise<AgentExecutionResult>;
}
