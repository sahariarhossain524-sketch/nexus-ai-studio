import { BrandingAgentOutput } from "./branding.types";

export class BrandingOutputFormatter {
  static formatToMarkdown(data: BrandingAgentOutput): string {
    let md = `# Brand Identity Book\n\n`;
    
    md += `## Brand Concept\n`;
    md += `- **Meaning:** ${data.brandMeaning}\n`;
    md += `- **Elevator Pitch:** ${data.elevatorPitch}\n\n`;
    
    md += `## Strategic Foundation\n`;
    md += `- **Mission:** ${data.brandMission}\n`;
    md += `- **Vision:** ${data.brandVision}\n`;
    md += `- **Positioning:** ${data.targetPositioning}\n\n`;
    
    md += `## Core Values\n`;
    data.brandValues.forEach(v => md += `- ${v}\n`);
    md += `\n`;
    
    md += `## Personality & Voice\n`;
    md += `- **Personality Traits:** ${data.brandPersonality.join(", ")}\n`;
    md += `- **Voice & Tone:** ${data.brandVoiceAndTone}\n\n`;
    
    md += `## Brand Assets\n`;
    md += `### Name Suggestions\n`;
    data.brandNameSuggestions.forEach(n => md += `- ${n}\n`);
    md += `\n### Tagline Suggestions\n`;
    data.taglineSuggestions.forEach(t => md += `- ${t}\n`);
    md += `\n### Keywords\n`;
    data.brandKeywords.forEach(k => md += `- ${k}\n`);
    md += `\n### Domains\n`;
    data.domainNameSuggestions.forEach(d => md += `- ${d}\n`);
    md += `\n### Social Handles\n`;
    data.socialHandleSuggestions.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Visual Identity Direction\n`;
    md += `- **Style:** ${data.visualStyleDirection}\n`;
    md += `- **Colors:** ${data.colorPaletteRecommendations.join(", ")}\n`;
    md += `- **Typography:** ${data.typographyRecommendations.join(", ")}\n\n`;
    
    md += `### Logo Concepts\n`;
    data.logoConceptDescriptions.forEach(c => md += `- ${c}\n`);
    md += `\n`;
    
    md += `## Analysis Confidence\n**Score:** ${data.confidenceScore}/100\n\n`;
    
    if (data.missingInformation && data.missingInformation.length > 0) {
      md += `## Missing Information (Needs Human Input)\n`;
      data.missingInformation.forEach(m => md += `- ${m}\n`);
    }
    
    return md;
  }
}
