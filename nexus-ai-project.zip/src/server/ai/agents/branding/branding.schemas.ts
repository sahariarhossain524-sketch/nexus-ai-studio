import { z } from "zod";

export const BrandingAgentOutputSchema = z.object({
  brandNameSuggestions: z.array(z.string()).min(5, "Minimum 5 brand names required").max(10),
  brandMeaning: z.string().min(10, "Brand meaning is required"),
  brandMission: z.string().min(10, "Brand mission is required"),
  brandVision: z.string().min(10, "Brand vision is required"),
  brandValues: z.array(z.string()).min(3, "At least 3 core values required"),
  brandPersonality: z.array(z.string()).min(3, "At least 3 personality traits required"),
  brandVoiceAndTone: z.string().min(10, "Brand voice and tone description required"),
  targetPositioning: z.string().min(10, "Target positioning is required"),
  taglineSuggestions: z.array(z.string()).min(5, "Minimum 5 taglines required").max(10),
  elevatorPitch: z.string().min(20, "Elevator pitch is required"),
  colorPaletteRecommendations: z.array(z.string()).min(2, "At least 2 colors required"),
  typographyRecommendations: z.array(z.string()).min(1, "At least 1 typography recommendation required"),
  brandKeywords: z.array(z.string()).min(5, "At least 5 brand keywords required"),
  visualStyleDirection: z.string().min(10, "Visual style direction is required"),
  logoConceptDescriptions: z.array(z.string()).min(2, "At least 2 logo concepts required"),
  domainNameSuggestions: z.array(z.string()).min(3, "At least 3 domain suggestions required"),
  socialHandleSuggestions: z.array(z.string()).min(3, "At least 3 social handle suggestions required"),
  confidenceScore: z.number().min(0).max(100),
  missingInformation: z.array(z.string())
});
