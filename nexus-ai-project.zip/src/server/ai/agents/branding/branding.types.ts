import { MarketAgentOutput } from "../market/market.types";
import { BusinessAgentOutput } from "../business/business.types";

export interface BrandingAgentInput {
  idea: string;
  constraints?: string;
  marketData: MarketAgentOutput;
  businessData: BusinessAgentOutput;
}

export interface BrandingAgentOutput {
  brandNameSuggestions: string[];
  brandMeaning: string;
  brandMission: string;
  brandVision: string;
  brandValues: string[];
  brandPersonality: string[];
  brandVoiceAndTone: string;
  targetPositioning: string;
  taglineSuggestions: string[];
  elevatorPitch: string;
  colorPaletteRecommendations: string[];
  typographyRecommendations: string[];
  brandKeywords: string[];
  visualStyleDirection: string;
  logoConceptDescriptions: string[];
  domainNameSuggestions: string[];
  socialHandleSuggestions: string[];
  confidenceScore: number;
  missingInformation: string[];
}
