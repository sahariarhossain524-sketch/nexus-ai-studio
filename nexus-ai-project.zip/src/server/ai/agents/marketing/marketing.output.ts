import { MarketingAgentOutput } from "./marketing.types";

export class MarketingOutputFormatter {
  static formatToMarkdown(data: MarketingAgentOutput): string {
    let md = `# Marketing & GTM Strategy\n\n`;
    
    md += `## Overview\n${data.marketingStrategyOverview}\n\n`;
    
    md += `## Customer Foundation\n`;
    md += `### Ideal Customer Profile (ICP)\n${data.idealCustomerProfile}\n\n`;
    md += `### Customer Journey\n${data.customerJourney}\n\n`;
    
    md += `## Go-To-Market Execution\n`;
    md += `${data.goToMarketExecutionPlan}\n\n`;
    md += `### Launch Strategy\n${data.launchStrategy}\n\n`;
    
    md += `## Core Channels\n`;
    
    md += `### Content Strategy\n`;
    data.contentStrategy.forEach(s => md += `- ${s}\n`);
    md += `\n### SEO Strategy\n`;
    data.seoStrategy.forEach(s => md += `- ${s}\n`);
    md += `\n### Social Media Strategy\n`;
    data.socialMediaStrategy.forEach(s => md += `- ${s}\n`);
    md += `\n### Email Marketing\n`;
    data.emailMarketingStrategy.forEach(s => md += `- ${s}\n`);
    md += `\n### Paid Advertising\n`;
    data.paidAdvertisingRecommendations.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Growth & Acquisition\n`;
    md += `### Growth Channels\n`;
    data.growthChannels.forEach(s => md += `- ${s}\n`);
    md += `\n### Viral & Referral Loops\n`;
    data.viralAndReferralIdeas.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Timelines\n`;
    md += `### 30-Day Execution Roadmap\n`;
    data.thirtyDayRoadmap.forEach(s => md += `- ${s}\n`);
    md += `\n### 90-Day Growth Plan\n`;
    data.ninetyDayGrowthPlan.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Execution Priority\n`;
    md += `| Task | Priority | Estimated Time |\n`;
    md += `|------|----------|----------------|\n`;
    data.executionPriority.forEach(task => {
      md += `| ${task.task} | ${task.priority} | ${task.estimatedTime} |\n`;
    });
    md += `\n`;
    
    md += `## Operations & Tracking\n`;
    md += `### Marketing KPIs\n`;
    data.marketingKPIs.forEach(k => md += `- ${k}\n`);
    md += `\n### Budget Recommendation\n${data.budgetRecommendation}\n\n`;
    
    md += `### Risks\n`;
    data.risks.forEach(r => md += `- ${r}\n`);
    md += `\n`;
    
    md += `## Analysis Confidence\n**Score:** ${data.confidenceScore}/100\n\n`;
    
    if (data.missingInformation && data.missingInformation.length > 0) {
      md += `## Missing Information (Needs Human Input)\n`;
      data.missingInformation.forEach(m => md += `- ${m}\n`);
    }
    
    return md;
  }
}
