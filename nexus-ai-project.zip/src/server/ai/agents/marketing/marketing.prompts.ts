import { PromptTemplate } from "../../prompts/prompt.engine";

export const MarketingAgentPromptTemplate: PromptTemplate = {
  id: "marketing-agent-prompt",
  name: "Marketing Strategy Primary Prompt",
  description: "Instructs the LLM to construct a complete marketing strategy based on market research, business strategy, and branding.",
  variables: ["idea", "marketData", "businessData", "brandingData", "constraints"],
  versions: [
    {
      version: 1,
      createdAt: new Date(),
      content: `You are a world-class Chief Marketing Officer (CMO). Your job is to create a highly actionable, data-driven marketing and growth strategy for the following startup.

STARTUP IDEA: {{idea}}
MARKET RESEARCH: {{marketData}}
BUSINESS STRATEGY: {{businessData}}
BRANDING: {{brandingData}}
CONSTRAINTS: {{constraints}}

CRITICAL INSTRUCTIONS:
1. Return ONLY valid JSON matching the exact schema provided below.
2. DO NOT repeat market research, business strategy, or branding data. Rely on the provided data.
3. Formulate a pure GTM and Marketing Execution plan.
4. If you are uncertain about specific budgets or metrics, provide logical estimates but flag them as assumptions, or use "Unknown". Do not blindly hallucinate facts.

EXPECTED JSON SCHEMA:
{
  "marketingStrategyOverview": "High-level summary of the marketing approach",
  "idealCustomerProfile": "Detailed ICP leveraging market research",
  "customerJourney": "Stages from awareness to advocacy",
  "goToMarketExecutionPlan": "Actionable GTM steps based on the business strategy",
  "launchStrategy": "How to execute the initial product launch",
  "contentStrategy": ["Content pillar 1", "Content pillar 2"],
  "seoStrategy": ["SEO tactic 1", "SEO tactic 2"],
  "socialMediaStrategy": ["Social tactic 1", "Social tactic 2"],
  "emailMarketingStrategy": ["Email sequence 1", "Email sequence 2"],
  "paidAdvertisingRecommendations": ["Paid channel 1", "Paid channel 2"],
  "growthChannels": ["Growth channel 1", "Growth channel 2"],
  "viralAndReferralIdeas": ["Viral loop 1", "Referral program 1"],
  "thirtyDayRoadmap": ["Week 1: Do X", "Week 2: Do Y", "Week 3: Do Z", "Week 4: Do W"],
  "ninetyDayGrowthPlan": ["Month 1: Phase 1", "Month 2: Phase 2", "Month 3: Phase 3"],
  "marketingKPIs": ["CAC", "LTV", "Conversion Rate", "Traffic"],
  "budgetRecommendation": "Recommended marketing budget allocation",
  "executionPriority": [
    {
      "task": "Launch Landing Page",
      "priority": "High",
      "estimatedTime": "1 day"
    }
  ],
  "risks": ["Marketing risk 1", "Marketing risk 2"],
  "missingInformation": ["Information needed to execute the marketing plan"],
  "confidenceScore": 88
}

Ensure your response is parseable by JSON.parse(). Do not include markdown code block syntax (like \`\`\`json) in your output, just the raw JSON string.`,
    }
  ]
};
