import { z } from "zod";

export const MarketingAgentOutputSchema = z.object({
  marketingStrategyOverview: z.string().min(10, "Overview is required"),
  idealCustomerProfile: z.string().min(10, "ICP is required"),
  customerJourney: z.string().min(10, "Customer journey is required"),
  goToMarketExecutionPlan: z.string().min(10, "GTM plan is required"),
  launchStrategy: z.string().min(10, "Launch strategy is required"),
  contentStrategy: z.array(z.string()).min(1, "At least 1 content strategy required"),
  seoStrategy: z.array(z.string()).min(1, "At least 1 SEO strategy required"),
  socialMediaStrategy: z.array(z.string()).min(1, "At least 1 social media strategy required"),
  emailMarketingStrategy: z.array(z.string()).min(1, "At least 1 email strategy required"),
  paidAdvertisingRecommendations: z.array(z.string()).min(1, "At least 1 paid advertising recommendation required"),
  growthChannels: z.array(z.string()).min(1, "At least 1 growth channel required"),
  viralAndReferralIdeas: z.array(z.string()).min(1, "At least 1 viral/referral idea required"),
  thirtyDayRoadmap: z.array(z.string()).min(3, "At least 3 steps required for 30-day roadmap"),
  ninetyDayGrowthPlan: z.array(z.string()).min(3, "At least 3 steps required for 90-day plan"),
  marketingKPIs: z.array(z.string()).min(3, "At least 3 KPIs required"),
  budgetRecommendation: z.string().min(10, "Budget recommendation is required"),
  executionPriority: z.array(
    z.object({
      task: z.string().min(5, "Task description required"),
      priority: z.enum(["High", "Medium", "Low"]),
      estimatedTime: z.string().min(2, "Estimated time required")
    })
  ).min(1, "At least 1 execution priority task is required"),
  risks: z.array(z.string()).min(1, "At least 1 risk is required"),
  missingInformation: z.array(z.string()),
  confidenceScore: z.number().min(0).max(100)
});
