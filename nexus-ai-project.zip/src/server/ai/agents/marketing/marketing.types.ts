import { MarketAgentOutput } from "../market/market.types";
import { BusinessAgentOutput } from "../business/business.types";
import { BrandingAgentOutput } from "../branding/branding.types";

export interface ExecutionPriorityTask {
  task: string;
  priority: "High" | "Medium" | "Low";
  estimatedTime: string;
}

export interface MarketingAgentInput {
  idea: string;
  constraints?: string;
  marketData: MarketAgentOutput;
  businessData: BusinessAgentOutput;
  brandingData: BrandingAgentOutput;
}

export interface MarketingAgentOutput {
  marketingStrategyOverview: string;
  idealCustomerProfile: string;
  customerJourney: string;
  goToMarketExecutionPlan: string;
  launchStrategy: string;
  contentStrategy: string[];
  seoStrategy: string[];
  socialMediaStrategy: string[];
  emailMarketingStrategy: string[];
  paidAdvertisingRecommendations: string[];
  growthChannels: string[];
  viralAndReferralIdeas: string[];
  thirtyDayRoadmap: string[];
  ninetyDayGrowthPlan: string[];
  marketingKPIs: string[];
  budgetRecommendation: string;
  executionPriority: ExecutionPriorityTask[];
  risks: string[];
  missingInformation: string[];
  confidenceScore: number;
}
