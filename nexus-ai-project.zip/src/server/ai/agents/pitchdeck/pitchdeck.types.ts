import { MarketAgentOutput } from "../market/market.types";
import { BusinessAgentOutput } from "../business/business.types";
import { BrandingAgentOutput } from "../branding/branding.types";
import { MarketingAgentOutput } from "../marketing/marketing.types";

export interface PitchDeckAgentInput {
  idea: string;
  constraints?: string;
  marketData: MarketAgentOutput;
  businessData: BusinessAgentOutput;
  brandingData: BrandingAgentOutput;
  marketingData: MarketingAgentOutput;
}

export interface PitchDeckSlide {
  title: string;
  objective: string;
  bulletPoints: string[];
  speakerNotes: string;
  visualSuggestion: string;
}

export interface PitchDeckAgentOutput {
  investorStory: string;
  slides: PitchDeckSlide[];
  confidenceScore: number;
}
