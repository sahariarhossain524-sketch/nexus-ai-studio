import { AIAgent, AgentExecutionResult, WrappedAgentOutput } from "../agent.interface";
import { GlobalContextPayload } from "../../context/context.engine";
import { PitchDeckAgentInput, PitchDeckAgentOutput } from "./pitchdeck.types";
import { PitchDeckAgentOutputSchema } from "./pitchdeck.schemas";
import { PitchDeckOutputFormatter } from "./pitchdeck.output";

export class PitchDeckAgent implements AIAgent {
  id = "agent-pitchdeck";
  name = "Pitch Deck Agent";
  
  private context: GlobalContextPayload | null = null;
  private inputPayload: PitchDeckAgentInput | null = null;
  private rawOutput: any = null;
  private validatedOutput: PitchDeckAgentOutput | null = null;

  async initialize(context: GlobalContextPayload): Promise<void> {
    this.context = context;
  }

  async plan(taskPayload: Record<string, any>): Promise<string[]> {
    this.inputPayload = taskPayload as PitchDeckAgentInput;
    return [
      "Analyze Market, Business, Branding & Marketing Data",
      "Formulate Investor Story",
      "Generate 15+ Pitch Deck Slides",
      "Define Speaker Notes & Visuals",
      "Format JSON Output"
    ];
  }

  async execute(taskPayload: Record<string, any>): Promise<void> {
    if (!this.inputPayload) throw new Error("Agent not planned");

    // Mocking the execution step for the architecture scaffold:
    this.rawOutput = {
      investorStory: "Simulated investor narrative that hooks the VC in the first 30 seconds by highlighting a massive market gap and our unique right to win.",
      slides: Array.from({ length: 15 }).map((_, i) => ({
        title: `Slide ${i + 1}`,
        objective: "Simulated slide objective to convey to investors",
        bulletPoints: ["Key point 1", "Key point 2", "Key point 3"],
        speakerNotes: "Simulated script for the founder to read",
        visualSuggestion: "A clean, modern chart or infographic"
      })),
      confidenceScore: 94
    };
  }

  async validate(): Promise<boolean> {
    if (!this.rawOutput) throw new Error("No output generated");
    
    try {
      this.validatedOutput = PitchDeckAgentOutputSchema.parse(this.rawOutput);
      return true;
    } catch (error) {
      console.error("Pitch Deck Agent Validation Error:", error);
      return false;
    }
  }

  async complete(): Promise<AgentExecutionResult> {
    if (!this.validatedOutput) {
      return {
        success: false,
        artifacts: [],
        error: "Validation failed or execution incomplete"
      };
    }

    const markdownContent = PitchDeckOutputFormatter.formatToMarkdown(this.validatedOutput);

    const wrappedOutput: WrappedAgentOutput<PitchDeckAgentOutput> = {
      metadata: {
        agentId: this.id,
        version: "1.0.0",
        generatedAt: new Date().toISOString(),
        confidenceScore: this.validatedOutput.confidenceScore,
        dependencies: [
          "agent-market-research",
          "agent-business-strategy",
          "agent-branding",
          "agent-marketing"
        ]
      },
      data: this.validatedOutput
    };

    return {
      success: true,
      artifacts: [
        {
          type: "markdown",
          name: "Pitch_Deck_Outline.md",
          content: markdownContent
        },
        {
          type: "json",
          name: "pitch_deck.json",
          content: JSON.stringify(wrappedOutput, null, 2)
        }
      ],
      metadata: wrappedOutput.metadata
    };
  }
}
