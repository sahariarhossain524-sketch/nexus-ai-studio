import { z } from "zod";

export const PitchDeckSlideSchema = z.object({
  title: z.string().min(3, "Slide title is required"),
  objective: z.string().min(5, "Slide objective is required"),
  bulletPoints: z.array(z.string()).min(1, "At least 1 bullet point required"),
  speakerNotes: z.string().min(10, "Speaker notes are required"),
  visualSuggestion: z.string().min(5, "Visual suggestion is required"),
});

export const PitchDeckAgentOutputSchema = z.object({
  investorStory: z.string().min(50, "Investor story must be comprehensive"),
  slides: z.array(PitchDeckSlideSchema).min(15, "Minimum 15 slides required"),
  confidenceScore: z.number().min(0).max(100)
});
