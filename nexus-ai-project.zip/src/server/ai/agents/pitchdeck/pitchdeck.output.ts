import { PitchDeckAgentOutput } from "./pitchdeck.types";

export class PitchDeckOutputFormatter {
  static formatToMarkdown(data: PitchDeckAgentOutput): string {
    let md = `# Investor Pitch Deck\n\n`;
    
    md += `## The Investor Story\n> ${data.investorStory}\n\n`;
    
    md += `## Deck Structure\n\n`;
    
    data.slides.forEach((slide, index) => {
      md += `### Slide ${index + 1}: ${slide.title}\n`;
      md += `- **Objective:** ${slide.objective}\n`;
      md += `- **Visual:** *${slide.visualSuggestion}*\n`;
      md += `- **Content:**\n`;
      slide.bulletPoints.forEach(bp => md += `  - ${bp}\n`);
      md += `- **Speaker Notes:** _"${slide.speakerNotes}"_\n\n`;
    });
    
    md += `---\n`;
    md += `## Analysis Confidence\n**Score:** ${data.confidenceScore}/100\n`;
    
    return md;
  }
}
