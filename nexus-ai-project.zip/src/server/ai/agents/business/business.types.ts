import { MarketAgentOutput } from "../market/market.types";

export interface BusinessAgentInput {
  idea: string;
  constraints?: string;
  marketData: MarketAgentOutput;
}

export interface BusinessAgentOutput {
  executiveSummary: string;
  problemStatement: string;
  solution: string;
  uniqueValueProposition: string;
  businessModel: string;
  revenueStreams: string[];
  pricingStrategy: string;
  goToMarketOverview: string;
  customerAcquisitionStrategy: string[];
  keyMetrics: string[];
  growthStrategy: string[];
  risks: string[];
  assumptions: string[];
  missingInformation: string[];
  confidenceScore: number;
}
