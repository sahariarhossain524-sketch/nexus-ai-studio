import { AIAgent, AgentExecutionResult, WrappedAgentOutput } from "../agent.interface";
import { GlobalContextPayload } from "../../context/context.engine";
import { BusinessAgentInput, BusinessAgentOutput } from "./business.types";
import { BusinessAgentOutputSchema } from "./business.schemas";
import { BusinessOutputFormatter } from "./business.output";

export class BusinessStrategyAgent implements AIAgent {
  id = "agent-business-strategy";
  name = "Business Strategy Agent";
  
  private context: GlobalContextPayload | null = null;
  private inputPayload: BusinessAgentInput | null = null;
  private rawOutput: any = null;
  private validatedOutput: BusinessAgentOutput | null = null;

  async initialize(context: GlobalContextPayload): Promise<void> {
    this.context = context;
  }

  async plan(taskPayload: Record<string, any>): Promise<string[]> {
    this.inputPayload = taskPayload as BusinessAgentInput;
    return [
      "Analyze Market Research Data",
      "Formulate Problem & Solution",
      "Develop Business Model & Pricing",
      "Draft Go-To-Market & Acquisition Strategy",
      "Identify Risks & Key Metrics",
      "Format JSON Output"
    ];
  }

  async execute(taskPayload: Record<string, any>): Promise<void> {
    if (!this.inputPayload) throw new Error("Agent not planned");

    // In a real implementation, this is where we would call the AI Provider Layer
    // Mocking the execution step for the architecture scaffold:
    
    this.rawOutput = {
      executiveSummary: "Simulated Executive Summary",
      problemStatement: "Simulated Problem Statement",
      solution: "Simulated Solution",
      uniqueValueProposition: "Simulated UVP",
      businessModel: "Simulated Business Model (e.g. B2B SaaS)",
      revenueStreams: ["Subscription", "One-time Setup Fee"],
      pricingStrategy: "Tiered Pricing",
      goToMarketOverview: "Direct Sales & Content Marketing",
      customerAcquisitionStrategy: ["SEO", "Cold Outreach"],
      keyMetrics: ["CAC", "LTV", "Churn Rate"],
      growthStrategy: ["Partnerships", "Referral Program"],
      risks: ["Market saturation", "Regulatory changes"],
      assumptions: ["Customers will pay $50/mo"],
      missingInformation: [],
      confidenceScore: 85
    };
  }

  async validate(): Promise<boolean> {
    if (!this.rawOutput) throw new Error("No output generated");
    
    try {
      this.validatedOutput = BusinessAgentOutputSchema.parse(this.rawOutput);
      return true;
    } catch (error) {
      console.error("Business Strategy Agent Validation Error:", error);
      return false;
    }
  }

  async complete(): Promise<AgentExecutionResult> {
    if (!this.validatedOutput) {
      return {
        success: false,
        artifacts: [],
        error: "Validation failed or execution incomplete"
      };
    }

    const markdownContent = BusinessOutputFormatter.formatToMarkdown(this.validatedOutput);

    const wrappedOutput: WrappedAgentOutput<BusinessAgentOutput> = {
      metadata: {
        agentId: this.id,
        version: "1.0",
        generatedAt: new Date().toISOString(),
        confidenceScore: this.validatedOutput.confidenceScore,
        dependencies: ["agent-market-research"]
      },
      data: this.validatedOutput
    };

    return {
      success: true,
      artifacts: [
        {
          type: "markdown",
          name: "Business_Strategy_Report.md",
          content: markdownContent
        },
        {
          type: "json",
          name: "business_strategy.json",
          content: JSON.stringify(wrappedOutput, null, 2)
        }
      ],
      metadata: wrappedOutput.metadata
    };
  }
}
