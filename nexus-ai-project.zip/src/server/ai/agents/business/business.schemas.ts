import { z } from "zod";

export const BusinessAgentOutputSchema = z.object({
  executiveSummary: z.string().min(10, "Executive summary must be substantial"),
  problemStatement: z.string().min(10, "Problem statement is required"),
  solution: z.string().min(10, "Solution is required"),
  uniqueValueProposition: z.string().min(5, "UVP is required"),
  businessModel: z.string().min(5, "Business model is required"),
  revenueStreams: z.array(z.string()).min(1, "At least one revenue stream is required"),
  pricingStrategy: z.string().min(5, "Pricing strategy is required"),
  goToMarketOverview: z.string().min(5, "GTM overview is required"),
  customerAcquisitionStrategy: z.array(z.string()).min(1, "At least one acquisition strategy is required"),
  keyMetrics: z.array(z.string()).min(1, "At least one key metric is required"),
  growthStrategy: z.array(z.string()).min(1, "At least one growth strategy is required"),
  risks: z.array(z.string()).min(1, "At least one risk is required"),
  assumptions: z.array(z.string()).min(1, "At least one assumption is required"),
  missingInformation: z.array(z.string()),
  confidenceScore: z.number().min(0).max(100)
});
