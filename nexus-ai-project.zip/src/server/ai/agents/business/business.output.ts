import { BusinessAgentOutput } from "./business.types";

export class BusinessOutputFormatter {
  static formatToMarkdown(data: BusinessAgentOutput): string {
    let md = `# Business Strategy Report\n\n`;
    
    md += `## Executive Summary\n${data.executiveSummary}\n\n`;
    
    md += `## Problem Statement\n${data.problemStatement}\n\n`;
    
    md += `## Solution\n${data.solution}\n\n`;
    
    md += `## Unique Value Proposition\n${data.uniqueValueProposition}\n\n`;
    
    md += `## Business Model\n${data.businessModel}\n\n`;
    
    md += `## Revenue Streams\n`;
    data.revenueStreams.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Pricing Strategy\n${data.pricingStrategy}\n\n`;
    
    md += `## Go-To-Market Overview\n${data.goToMarketOverview}\n\n`;
    
    md += `## Customer Acquisition Strategy\n`;
    data.customerAcquisitionStrategy.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Key Metrics (KPIs)\n`;
    data.keyMetrics.forEach(m => md += `- ${m}\n`);
    md += `\n`;
    
    md += `## Growth Strategy\n`;
    data.growthStrategy.forEach(s => md += `- ${s}\n`);
    md += `\n`;
    
    md += `## Risks\n`;
    data.risks.forEach(r => md += `- ${r}\n`);
    md += `\n`;
    
    md += `## Assumptions\n`;
    data.assumptions.forEach(a => md += `- ${a}\n`);
    md += `\n`;
    
    md += `## Analysis Confidence\n**Score:** ${data.confidenceScore}/100\n\n`;
    
    if (data.missingInformation && data.missingInformation.length > 0) {
      md += `## Missing Information (Needs Human Input)\n`;
      data.missingInformation.forEach(m => md += `- ${m}\n`);
    }
    
    return md;
  }
}
