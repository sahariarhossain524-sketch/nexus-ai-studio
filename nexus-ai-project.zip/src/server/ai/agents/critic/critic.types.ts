import { MarketAgentOutput } from "../market/market.types";
import { BusinessAgentOutput } from "../business/business.types";
import { BrandingAgentOutput } from "../branding/branding.types";
import { MarketingAgentOutput } from "../marketing/marketing.types";
import { PitchDeckAgentOutput } from "../pitchdeck/pitchdeck.types";

export interface CriticAgentInput {
  idea: string;
  marketData: MarketAgentOutput;
  businessData: BusinessAgentOutput;
  brandingData: BrandingAgentOutput;
  marketingData: MarketingAgentOutput;
  pitchDeckData: PitchDeckAgentOutput;
}

export interface AgentScores {
  marketResearch: number;
  businessStrategy: number;
  branding: number;
  marketing: number;
  pitchDeck: number;
}

export interface CriticAgentOutput {
  overallQualityScore: number;
  agentScores: AgentScores;
  consistencyReport: string[];
  missingInformation: string[];
  detectedRisks: string[];
  contradictions: string[];
  hallucinationWarnings: string[];
  improvementSuggestions: string[];
  investorReadinessScore: number;
  exportReadiness: boolean;
  finalApproval: boolean;
  confidenceScore: number;
}
