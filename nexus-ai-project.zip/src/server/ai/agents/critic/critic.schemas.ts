import { z } from "zod";

export const AgentScoresSchema = z.object({
  marketResearch: z.number().min(0).max(100),
  businessStrategy: z.number().min(0).max(100),
  branding: z.number().min(0).max(100),
  marketing: z.number().min(0).max(100),
  pitchDeck: z.number().min(0).max(100)
});

export const CriticAgentOutputSchema = z.object({
  overallQualityScore: z.number().min(0).max(100, "Quality score required"),
  agentScores: AgentScoresSchema,
  consistencyReport: z.array(z.string()).min(1, "Consistency report required"),
  missingInformation: z.array(z.string()),
  detectedRisks: z.array(z.string()),
  contradictions: z.array(z.string()),
  hallucinationWarnings: z.array(z.string()),
  improvementSuggestions: z.array(z.string()).min(1, "Improvement suggestions required"),
  investorReadinessScore: z.number().min(0).max(100),
  exportReadiness: z.boolean(),
  finalApproval: z.boolean(),
  confidenceScore: z.number().min(0).max(100, "Confidence score required")
});
