import { CriticAgentOutput } from "./critic.types";

export class CriticOutputFormatter {
  static formatToMarkdown(data: CriticAgentOutput): string {
    let md = `# Audit & Consistency Report\n\n`;
    
    md += `## Scorecard\n`;
    md += `- **Overall Quality:** ${data.overallQualityScore}/100\n`;
    md += `- **Investor Readiness:** ${data.investorReadinessScore}/100\n`;
    md += `- **Export Readiness:** ${data.exportReadiness ? "✅ Ready" : "❌ Blocked"}\n`;
    md += `- **Final Approval:** ${data.finalApproval ? "✅ Approved" : "❌ Rejected"}\n\n`;
    
    md += `### Agent Scores\n`;
    md += `- Market Research: ${data.agentScores.marketResearch}/100\n`;
    md += `- Business Strategy: ${data.agentScores.businessStrategy}/100\n`;
    md += `- Branding: ${data.agentScores.branding}/100\n`;
    md += `- Marketing: ${data.agentScores.marketing}/100\n`;
    md += `- Pitch Deck: ${data.agentScores.pitchDeck}/100\n\n`;
    
    md += `## Consistency Report\n`;
    data.consistencyReport.forEach(c => md += `- ${c}\n`);
    md += `\n`;
    
    if (data.contradictions.length > 0) {
      md += `## 🚨 Contradictions\n`;
      data.contradictions.forEach(c => md += `- ${c}\n`);
      md += `\n`;
    }
    
    if (data.hallucinationWarnings.length > 0) {
      md += `## ⚠️ Hallucination Warnings\n`;
      data.hallucinationWarnings.forEach(w => md += `- ${w}\n`);
      md += `\n`;
    }
    
    if (data.detectedRisks.length > 0) {
      md += `## ⚠️ Detected Risks\n`;
      data.detectedRisks.forEach(r => md += `- ${r}\n`);
      md += `\n`;
    }
    
    if (data.missingInformation.length > 0) {
      md += `## ℹ️ Missing Information\n`;
      data.missingInformation.forEach(m => md += `- ${m}\n`);
      md += `\n`;
    }
    
    md += `## 💡 Improvement Suggestions\n`;
    data.improvementSuggestions.forEach(i => md += `- ${i}\n`);
    md += `\n`;
    
    return md;
  }
}
