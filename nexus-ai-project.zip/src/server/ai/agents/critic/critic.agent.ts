import { AIAgent, AgentExecutionResult, WrappedAgentOutput } from "../agent.interface";
import { GlobalContextPayload } from "../../context/context.engine";
import { CriticAgentInput, CriticAgentOutput } from "./critic.types";
import { CriticAgentOutputSchema } from "./critic.schemas";
import { CriticOutputFormatter } from "./critic.output";

export class CriticAgent implements AIAgent {
  id = "agent-critic";
  name = "Critic Agent";
  
  private context: GlobalContextPayload | null = null;
  private inputPayload: CriticAgentInput | null = null;
  private rawOutput: any = null;
  private validatedOutput: CriticAgentOutput | null = null;

  async initialize(context: GlobalContextPayload): Promise<void> {
    this.context = context;
  }

  async plan(taskPayload: Record<string, any>): Promise<string[]> {
    this.inputPayload = taskPayload as CriticAgentInput;
    return [
      "Load all generated startup assets (Market, Business, Brand, Marketing, Pitch Deck)",
      "Cross-reference data for contradictions and hallucinations",
      "Audit alignment between Business Strategy and Marketing Strategy",
      "Verify Pitch Deck investor honesty rules (No fake metrics)",
      "Score overall ecosystem readiness",
      "Format JSON Audit Report"
    ];
  }

  async execute(taskPayload: Record<string, any>): Promise<void> {
    if (!this.inputPayload) throw new Error("Agent not planned");

    // Mocking the execution step for the architecture scaffold:
    this.rawOutput = {
      overallQualityScore: 94,
      agentScores: {
        marketResearch: 95,
        businessStrategy: 90,
        branding: 98,
        marketing: 92,
        pitchDeck: 95
      },
      consistencyReport: [
        "Strong alignment between Brand Values and Business Value Proposition.",
        "Pitch Deck accurately reflects 'Pre-launch' status without fabricating traction.",
        "Marketing strategy successfully builds on the target ICP defined in Market Research."
      ],
      missingInformation: [
        "Detailed 3-year financial forecast is missing from the Pitch Deck",
        "Specific unit economics for the freemium tier"
      ],
      detectedRisks: [
        "Heavy reliance on SEO may take too long to validate the business model"
      ],
      contradictions: [
        "Minor: Marketing strategy mentions B2B channels, but Market Research primarily analyzed B2C consumers."
      ],
      hallucinationWarnings: [],
      improvementSuggestions: [
        "Clarify if the GTM is B2B2C or strictly B2B.",
        "Add a slide on unit economics to the Pitch Deck."
      ],
      investorReadinessScore: 88,
      exportReadiness: true,
      finalApproval: true,
      confidenceScore: 95
    };
  }

  async validate(): Promise<boolean> {
    if (!this.rawOutput) throw new Error("No output generated");
    
    try {
      this.validatedOutput = CriticAgentOutputSchema.parse(this.rawOutput);
      return true;
    } catch (error) {
      console.error("Critic Agent Validation Error:", error);
      return false;
    }
  }

  async complete(): Promise<AgentExecutionResult> {
    if (!this.validatedOutput) {
      return {
        success: false,
        artifacts: [],
        error: "Validation failed or execution incomplete"
      };
    }

    const markdownContent = CriticOutputFormatter.formatToMarkdown(this.validatedOutput);

    const wrappedOutput: WrappedAgentOutput<CriticAgentOutput> = {
      metadata: {
        agentId: this.id,
        version: "1.0.0",
        generatedAt: new Date().toISOString(),
        confidenceScore: this.validatedOutput.confidenceScore, 
        dependencies: [
          "agent-market-research",
          "agent-business-strategy",
          "agent-branding",
          "agent-marketing",
          "agent-pitchdeck"
        ]
      },
      data: this.validatedOutput
    };

    return {
      success: true,
      artifacts: [
        {
          type: "markdown",
          name: "Audit_Report.md",
          content: markdownContent
        },
        {
          type: "json",
          name: "critic_audit.json",
          content: JSON.stringify(wrappedOutput, null, 2)
        }
      ],
      metadata: wrappedOutput.metadata
    };
  }
}
