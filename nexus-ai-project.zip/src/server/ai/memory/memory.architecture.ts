export interface MemoryEntry {
  id: string;
  timestamp: Date;
  source: string; // e.g. Agent Name
  content: string;
  metadata?: Record<string, any>;
}

export interface MemoryStore {
  save(entry: Omit<MemoryEntry, "id" | "timestamp">): Promise<MemoryEntry>;
  query(query: string, limit?: number): Promise<MemoryEntry[]>;
  clear(): Promise<void>;
}

export interface ShortTermMemory extends MemoryStore {
  // Ephemeral memory for a single generation job
  jobId: string;
}

export interface ProjectMemory extends MemoryStore {
  // Persistent memory scoped to a project (startup concept)
  projectId: string;
}

export interface WorkspaceMemory extends MemoryStore {
  // Persistent memory shared across all projects in a workspace (e.g. founder's general preferences/style)
  workspaceId: string;
}

export interface GlobalMemory extends MemoryStore {
  // System-wide memory (e.g. general startup knowledge base, disconnected from specific users)
}
