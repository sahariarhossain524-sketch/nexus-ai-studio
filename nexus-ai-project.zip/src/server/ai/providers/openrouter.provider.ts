import OpenAI from "openai";
import { 
  AIProviderAdapter, 
  AIProviderConfig, 
  GenerationRequest, 
  GenerationResponse, 
  StreamEvent 
} from "./provider.interface";
import { InvalidAPIKeyError, NetworkFailureError, RateLimitError } from "./provider.errors";

export class OpenRouterProvider implements AIProviderAdapter {
  id = "openrouter" as const;
  name = "OpenRouter";
  
  private client: OpenAI | null = null;
  private config: AIProviderConfig | null = null;

  initialize(config?: AIProviderConfig): void {
    const apiKey = config?.apiKey || process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      throw new InvalidAPIKeyError(this.name, "OPENROUTER_API_KEY is not set in environment");
    }
    this.config = config || {};
    // OpenRouter uses the OpenAI SDK configured with a different base URL
    this.client = new OpenAI({ 
      apiKey,
      baseURL: "https://openrouter.ai/api/v1",
      defaultHeaders: {
        "HTTP-Referer": "https://nexus-ai.com", // Required by OpenRouter
        "X-Title": "Nexus AI", 
      }
    });
  }

  private handleError(error: any): never {
    if (error instanceof OpenAI.APIError) {
      if (error.status === 429) {
        throw new RateLimitError(this.name);
      }
      if (error.status === 401) {
        throw new InvalidAPIKeyError(this.name);
      }
    }
    throw new NetworkFailureError(this.name, error.message || "Failed to call OpenRouter API");
  }

  async generate(request: GenerationRequest): Promise<GenerationResponse> {
    if (!this.client) this.initialize();
    
    const startTime = Date.now();
    try {
      const response = await this.client!.chat.completions.create({
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
        top_p: request.topP,
        max_tokens: request.maxTokens,
      });

      const runtimeMs = Date.now() - startTime;
      
      const usage = {
        promptTokens: response.usage?.prompt_tokens || 0,
        completionTokens: response.usage?.completion_tokens || 0,
        totalTokens: response.usage?.total_tokens || 0
      };

      const estimatedCostUsd = (usage.promptTokens * 0.000001) + (usage.completionTokens * 0.000002);

      return {
        text: response.choices[0]?.message?.content || "",
        usage,
        model: request.model,
        provider: this.name,
        estimatedCostUsd,
        runtimeMs
      };
    } catch (error) {
      this.handleError(error);
    }
  }

  async *generateStream(request: GenerationRequest): AsyncGenerator<StreamEvent, void, unknown> {
    if (!this.client) this.initialize();

    try {
      const stream = await this.client!.chat.completions.create({
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
        top_p: request.topP,
        max_tokens: request.maxTokens,
        stream: true,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          yield {
            type: "token",
            content
          };
        }
      }
      
      yield { type: "completion" };
    } catch (error) {
      yield {
        type: "error",
        error: error as Error
      };
    }
  }
}
