import { 
  AIProviderAdapter, 
  AIProviderConfig, 
  GenerationRequest, 
  GenerationResponse, 
  StreamEvent 
} from "./provider.interface";
import { ProviderFactory, ProviderType } from "./provider.factory";
import { RateLimitError, NetworkFailureError } from "./provider.errors";

export class ProviderManager {
  private fallbackChain: ProviderType[] = ["gemini", "openai", "openrouter", "anthropic"];

  async generate(
    initialProvider: ProviderType, 
    request: GenerationRequest, 
    config?: AIProviderConfig
  ): Promise<GenerationResponse> {
    
    // Attempt the requested provider first, then follow the fallback chain
    const providersToTry = [initialProvider, ...this.fallbackChain.filter(p => p !== initialProvider)];

    for (const providerType of providersToTry) {
      try {
        console.log(`[ProviderManager] Attempting generation with ${providerType}...`);
        const provider: AIProviderAdapter = ProviderFactory.createProvider(providerType);
        provider.initialize(config);
        
        return await provider.generate(request);
      } catch (error) {
        console.warn(`[ProviderManager] Provider ${providerType} failed:`, error);
        
        // If it's a RateLimit or NetworkFailure, we might want to wait/retry before failing over,
        // but for this MVP architecture, we will simply failover to the next provider.
        if (!(error instanceof RateLimitError || error instanceof NetworkFailureError)) {
          // If it's a ContextLength or InvalidAPIKey error, failover still makes sense
          // as another provider might have a larger context or a valid key.
        }
      }
    }

    throw new Error("[ProviderManager] All AI providers in the fallback chain failed.");
  }

  async *generateStream(
    initialProvider: ProviderType, 
    request: GenerationRequest, 
    config?: AIProviderConfig
  ): AsyncGenerator<StreamEvent, void, unknown> {
    
    const providersToTry = [initialProvider, ...this.fallbackChain.filter(p => p !== initialProvider)];

    for (const providerType of providersToTry) {
      try {
        console.log(`[ProviderManager] Attempting stream generation with ${providerType}...`);
        const provider: AIProviderAdapter = ProviderFactory.createProvider(providerType);
        provider.initialize(config);
        
        const stream = provider.generateStream(request);
        
        // We peek at the first event to see if the connection succeeded.
        // If the first event is an error, we catch it and fail over.
        let isFirstEvent = true;
        for await (const event of stream) {
          if (isFirstEvent && event.type === "error") {
            throw event.error;
          }
          isFirstEvent = false;
          yield event;
        }
        
        return; // Success, exit fallback loop
      } catch (error) {
        console.warn(`[ProviderManager] Provider ${providerType} stream failed:`, error);
      }
    }

    throw new Error("[ProviderManager] All AI providers in the fallback chain failed for streaming.");
  }
}
