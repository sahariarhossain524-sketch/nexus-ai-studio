import { GoogleGenAI } from "@google/genai";
import { 
  AIProviderAdapter, 
  AIProviderConfig, 
  GenerationRequest, 
  GenerationResponse, 
  StreamEvent 
} from "./provider.interface";
import { InvalidAPIKeyError, NetworkFailureError, RateLimitError } from "./provider.errors";

export class GeminiProvider implements AIProviderAdapter {
  id = "gemini" as const;
  name = "Google Gemini";
  
  private client: GoogleGenAI | null = null;
  private config: AIProviderConfig | null = null;

  initialize(config?: AIProviderConfig): void {
    const apiKey = config?.apiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new InvalidAPIKeyError(this.name, "GEMINI_API_KEY is not set in environment");
    }
    this.config = config || {};
    this.client = new GoogleGenAI({ apiKey });
  }

  private mapMessages(messages: GenerationRequest["messages"]) {
    // Basic mapping for gemini: role user -> user, role assistant -> model, role system -> system instruction
    // For @google/genai we usually pass system as a config option and user/model in contents.
    // Simplifying here for the adapter scaffold.
    return messages.map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }]
    }));
  }

  private handleError(error: any): never {
    if (error?.status === 429) {
      throw new RateLimitError(this.name);
    }
    if (error?.status === 401 || error?.status === 403) {
      throw new InvalidAPIKeyError(this.name);
    }
    throw new NetworkFailureError(this.name, error.message || "Failed to call Gemini API");
  }

  async generate(request: GenerationRequest): Promise<GenerationResponse> {
    if (!this.client) this.initialize();
    
    const startTime = Date.now();
    try {
      const systemInstruction = request.messages.find(m => m.role === "system")?.content;
      const contents = this.mapMessages(request.messages.filter(m => m.role !== "system"));

      const response = await this.client!.models.generateContent({
        model: request.model,
        contents,
        config: {
          systemInstruction,
          temperature: request.temperature,
          topP: request.topP,
        }
      });

      const runtimeMs = Date.now() - startTime;
      
      const usageMetadata = response.usageMetadata;
      const usage = {
        promptTokens: usageMetadata?.promptTokenCount || 0,
        completionTokens: usageMetadata?.candidatesTokenCount || 0,
        totalTokens: usageMetadata?.totalTokenCount || 0
      };

      // Mock cost calculation based on Gemini Pro pricing
      const estimatedCostUsd = (usage.promptTokens * 0.00000125) + (usage.completionTokens * 0.00000375);

      return {
        text: response.text || "",
        usage,
        model: request.model,
        provider: this.name,
        estimatedCostUsd,
        runtimeMs
      };
    } catch (error) {
      this.handleError(error);
    }
  }

  async *generateStream(request: GenerationRequest): AsyncGenerator<StreamEvent, void, unknown> {
    if (!this.client) this.initialize();

    try {
      const systemInstruction = request.messages.find(m => m.role === "system")?.content;
      const contents = this.mapMessages(request.messages.filter(m => m.role !== "system"));

      const stream = await this.client!.models.generateContentStream({
        model: request.model,
        contents,
        config: {
          systemInstruction,
          temperature: request.temperature,
          topP: request.topP,
        }
      });

      for await (const chunk of stream) {
        yield {
          type: "token",
          content: chunk.text
        };
      }
      
      yield { type: "completion" };
    } catch (error) {
      yield {
        type: "error",
        error: error as Error
      };
    }
  }
}
