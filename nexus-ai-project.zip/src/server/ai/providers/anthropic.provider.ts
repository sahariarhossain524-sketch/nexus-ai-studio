import Anthropic from "@anthropic-ai/sdk";
import { 
  AIProviderAdapter, 
  AIProviderConfig, 
  GenerationRequest, 
  GenerationResponse, 
  StreamEvent 
} from "./provider.interface";
import { InvalidAPIKeyError, NetworkFailureError, RateLimitError } from "./provider.errors";

export class AnthropicProvider implements AIProviderAdapter {
  id = "anthropic" as const;
  name = "Anthropic";
  
  private client: Anthropic | null = null;
  private config: AIProviderConfig | null = null;

  initialize(config?: AIProviderConfig): void {
    const apiKey = config?.apiKey || process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new InvalidAPIKeyError(this.name, "ANTHROPIC_API_KEY is not set in environment");
    }
    this.config = config || {};
    this.client = new Anthropic({ apiKey });
  }

  private handleError(error: any): never {
    if (error instanceof Anthropic.APIError) {
      if (error.status === 429) {
        throw new RateLimitError(this.name);
      }
      if (error.status === 401) {
        throw new InvalidAPIKeyError(this.name);
      }
    }
    throw new NetworkFailureError(this.name, error.message || "Failed to call Anthropic API");
  }

  async generate(request: GenerationRequest): Promise<GenerationResponse> {
    if (!this.client) this.initialize();
    
    const startTime = Date.now();
    try {
      const systemMessage = request.messages.find(m => m.role === "system")?.content;
      // Anthropic messages API requires messages to strictly be "user" or "assistant".
      const messages = request.messages
        .filter(m => m.role !== "system")
        .map(m => ({
          role: m.role as "user" | "assistant",
          content: m.content
        }));

      const response = await this.client!.messages.create({
        model: request.model,
        messages,
        system: systemMessage,
        temperature: request.temperature,
        top_p: request.topP,
        max_tokens: request.maxTokens || 4096, // Anthropic requires max_tokens
      });

      const runtimeMs = Date.now() - startTime;
      
      const usage = {
        promptTokens: response.usage.input_tokens,
        completionTokens: response.usage.output_tokens,
        totalTokens: response.usage.input_tokens + response.usage.output_tokens
      };

      const estimatedCostUsd = (usage.promptTokens * 0.000003) + (usage.completionTokens * 0.000015);

      return {
        text: response.content[0].type === "text" ? response.content[0].text : "",
        usage,
        model: request.model,
        provider: this.name,
        estimatedCostUsd,
        runtimeMs
      };
    } catch (error) {
      this.handleError(error);
    }
  }

  async *generateStream(request: GenerationRequest): AsyncGenerator<StreamEvent, void, unknown> {
    if (!this.client) this.initialize();

    try {
      const systemMessage = request.messages.find(m => m.role === "system")?.content;
      const messages = request.messages
        .filter(m => m.role !== "system")
        .map(m => ({
          role: m.role as "user" | "assistant",
          content: m.content
        }));

      const stream = await this.client!.messages.create({
        model: request.model,
        messages,
        system: systemMessage,
        temperature: request.temperature,
        top_p: request.topP,
        max_tokens: request.maxTokens || 4096,
        stream: true,
      });

      for await (const chunk of stream) {
        if (chunk.type === "content_block_delta" && chunk.delta.type === "text_delta") {
          yield {
            type: "token",
            content: chunk.delta.text
          };
        }
      }
      
      yield { type: "completion" };
    } catch (error) {
      yield {
        type: "error",
        error: error as Error
      };
    }
  }
}
