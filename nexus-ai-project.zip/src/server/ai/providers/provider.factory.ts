import { AIProviderAdapter } from "./provider.interface";
import { GeminiProvider } from "./gemini.provider";
import { OpenAIProvider } from "./openai.provider";
import { OpenRouterProvider } from "./openrouter.provider";
import { AnthropicProvider } from "./anthropic.provider";

export type ProviderType = "gemini" | "openai" | "openrouter" | "anthropic";

export class ProviderFactory {
  static createProvider(type: ProviderType): AIProviderAdapter {
    switch (type) {
      case "gemini":
        return new GeminiProvider();
      case "openai":
        return new OpenAIProvider();
      case "openrouter":
        return new OpenRouterProvider();
      case "anthropic":
        return new AnthropicProvider();
      default:
        throw new Error(`Unsupported AI Provider: ${type}`);
    }
  }
}
