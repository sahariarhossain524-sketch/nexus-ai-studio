export interface AIProviderConfig {
  apiKey?: string; // Sourced from process.env inside the provider
  maxRetries?: number;
  timeoutMs?: number;
}

export interface GenerationRequest {
  model: string;
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface GenerationResponse {
  text: string;
  usage: TokenUsage;
  model: string;
  provider: string;
  estimatedCostUsd: number;
  runtimeMs: number;
}

export interface StreamEvent {
  type: "token" | "completion" | "error";
  content?: string;
  error?: Error;
  usage?: TokenUsage;
}

export interface AIProviderAdapter {
  id: "openai" | "gemini" | "anthropic" | "openrouter";
  name: string;
  
  initialize(config?: AIProviderConfig): void;
  
  generate(request: GenerationRequest): Promise<GenerationResponse>;
  
  generateStream(request: GenerationRequest): AsyncGenerator<StreamEvent, void, unknown>;
}
