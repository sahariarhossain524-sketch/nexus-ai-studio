export class AIProviderError extends Error {
  constructor(
    public readonly provider: string,
    public readonly code: string,
    public readonly message: string,
    public readonly isRetryable: boolean
  ) {
    super(`[${provider}] ${code}: ${message}`);
    this.name = "AIProviderError";
  }
}

export class RateLimitError extends AIProviderError {
  constructor(provider: string, message = "Rate limit exceeded") {
    super(provider, "RATE_LIMIT", message, true);
    this.name = "RateLimitError";
  }
}

export class ContextLengthError extends AIProviderError {
  constructor(provider: string, message = "Prompt exceeds context length limit") {
    super(provider, "CONTEXT_LENGTH", message, false);
    this.name = "ContextLengthError";
  }
}

export class InvalidAPIKeyError extends AIProviderError {
  constructor(provider: string, message = "Invalid API key") {
    super(provider, "INVALID_API_KEY", message, false);
    this.name = "InvalidAPIKeyError";
  }
}

export class NetworkFailureError extends AIProviderError {
  constructor(provider: string, message = "Network request failed") {
    super(provider, "NETWORK_FAILURE", message, true);
    this.name = "NetworkFailureError";
  }
}
