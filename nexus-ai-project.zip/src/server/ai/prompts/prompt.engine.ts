export type PromptVariables = Record<string, string | number | boolean>;

export interface PromptVersion {
  version: number;
  content: string;
  createdAt: Date;
}

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  variables: string[]; // List of expected variable names
  versions: PromptVersion[];
}

export interface PromptRegistry {
  register(template: PromptTemplate): void;
  getTemplate(id: string): PromptTemplate | undefined;
  getLatestVersion(id: string): PromptVersion | undefined;
}

export interface PromptBuilder {
  template: PromptTemplate;
  
  /**
   * Compiles the prompt template by injecting variables.
   * Throws an error if required variables are missing.
   */
  build(variables: PromptVariables): string;
}
