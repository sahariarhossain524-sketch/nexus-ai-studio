export interface AIConfig {
  temperature: number;
  maxTokens: number;
  timeoutMs: number;
  maxRetries: number;
  fallbackProviderId?: string; // Fallback to a secondary provider if the primary fails
  rateLimit: {
    requestsPerMinute: number;
    tokensPerMinute: number;
  };
}

export const defaultAIConfig: AIConfig = {
  temperature: 0.7,
  maxTokens: 4096,
  timeoutMs: 30000,
  maxRetries: 3,
  rateLimit: {
    requestsPerMinute: 60,
    tokensPerMinute: 150000,
  }
};
