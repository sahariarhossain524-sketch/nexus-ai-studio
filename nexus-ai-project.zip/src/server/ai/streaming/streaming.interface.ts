export type StreamEventType = 
  | "TOKEN" 
  | "AGENT_STATUS" 
  | "PROGRESS" 
  | "ASSET_PREVIEW"
  | "ERROR"
  | "COMPLETE";

export interface StreamEventPayload {
  type: StreamEventType;
  jobId: string;
  timestamp: Date;
}

export interface TokenStreamEvent extends StreamEventPayload {
  type: "TOKEN";
  token: string;
  agentId?: string;
}

export interface AgentStatusStreamEvent extends StreamEventPayload {
  type: "AGENT_STATUS";
  agentId: string;
  status: "STARTING" | "THINKING" | "WRITING" | "VALIDATING" | "DONE" | "FAILED";
  message: string;
}

export interface ProgressStreamEvent extends StreamEventPayload {
  type: "PROGRESS";
  percentage: number;
  message: string;
}

export interface AssetPreviewStreamEvent extends StreamEventPayload {
  type: "ASSET_PREVIEW";
  assetId: string;
  partialContent: string;
}

export interface StreamingEngine {
  /**
   * Pushes an event to the stream associated with a jobId
   */
  emit(jobId: string, event: StreamEventPayload): Promise<void>;
  
  /**
   * Opens an SSE connection for the client
   */
  subscribe(jobId: string, onEvent: (event: StreamEventPayload) => void): () => void;
}
