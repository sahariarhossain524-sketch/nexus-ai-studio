export interface BaseContext {
  id: string;
  lastUpdated: Date;
}

export interface WorkspaceContext extends BaseContext {
  workspaceId: string;
  name: string;
  plan: string;
}

export interface ProjectContext extends BaseContext {
  projectId: string;
  name: string;
  description?: string;
  status: string;
}

export interface UserPreferencesContext {
  userId: string;
  language: string;
  formalityLevel: "casual" | "professional";
}

export interface MarketContext extends BaseContext {
  targetAudience: string[];
  competitors: string[];
  industry: string;
}

export interface BrandContext extends BaseContext {
  brandName: string;
  tagline?: string;
  toneOfVoice: string[];
  colorTokens: Record<string, string>;
}

export interface BusinessContext extends BaseContext {
  valueProposition: string;
  revenueModel: string;
  keyFeatures: string[];
}

export interface GenerationMemoryContext {
  jobId: string;
  previousOutputs: Record<string, any>;
  decisionsMade: string[];
}

export interface GlobalContextPayload {
  workspace: WorkspaceContext;
  project: ProjectContext;
  preferences: UserPreferencesContext;
  market?: MarketContext;
  brand?: BrandContext;
  business?: BusinessContext;
  memory: GenerationMemoryContext;
}

export interface ContextEngine {
  buildGlobalContext(projectId: string): Promise<GlobalContextPayload>;
  updateContext(projectId: string, patch: Partial<GlobalContextPayload>): Promise<void>;
}
