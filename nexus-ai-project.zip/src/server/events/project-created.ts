export const onProjectCreated = async (projectId: string) => {};
