import { EventEmitter } from "events";
import { AIEventPayload, AIEventType, IEventBus } from "./event-bus.interface";

export class InMemoryEventBus implements IEventBus {
  private emitter: EventEmitter;
  private static instance: InMemoryEventBus;

  private constructor() {
    this.emitter = new EventEmitter();
    // Increase max listeners for heavy concurrency
    this.emitter.setMaxListeners(100); 
  }

  public static getInstance(): InMemoryEventBus {
    if (!InMemoryEventBus.instance) {
      InMemoryEventBus.instance = new InMemoryEventBus();
    }
    return InMemoryEventBus.instance;
  }

  async publish(event: AIEventPayload): Promise<void> {
    // Emitter events are routed by jobId for multi-tenant safety
    const eventName = `${event.jobId}:${event.eventType}`;
    const catchAllName = `${event.jobId}:*`;
    
    // Publish to specific event type listener
    this.emitter.emit(eventName, event);
    // Publish to catch-all listener for this job
    this.emitter.emit(catchAllName, event);
  }

  subscribe(jobId: string, eventType: AIEventType | "*", callback: (event: AIEventPayload) => void): void {
    const eventName = `${jobId}:${eventType}`;
    this.emitter.on(eventName, callback);
  }

  unsubscribe(jobId: string, eventType: AIEventType | "*", callback: (event: AIEventPayload) => void): void {
    const eventName = `${jobId}:${eventType}`;
    this.emitter.off(eventName, callback);
  }

  once(jobId: string, eventType: AIEventType, callback: (event: AIEventPayload) => void): void {
    const eventName = `${jobId}:${eventType}`;
    this.emitter.once(eventName, callback);
  }

  destroy(): void {
    this.emitter.removeAllListeners();
  }
}
