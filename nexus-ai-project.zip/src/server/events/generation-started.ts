export const onGenerationStarted = async (jobId: string) => {};
