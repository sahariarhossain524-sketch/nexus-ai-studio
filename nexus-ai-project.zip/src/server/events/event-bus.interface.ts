export type AIEventType = 
  | "generation.started"
  | "generation.progress"
  | "generation.completed"
  | "generation.failed"
  | "agent.started"
  | "agent.completed"
  | "agent.failed"
  | "token"
  | "artifact.created"
  | "critic.started"
  | "critic.completed"
  | "revision.started"
  | "revision.completed"
  | "queue.waiting"
  | "queue.running"
  | "queue.finished"
  | "heartbeat";

export interface AIEventPayload {
  eventId: string;
  jobId: string;
  workspaceId: string;
  projectId: string;
  agentId?: string;
  eventType: AIEventType;
  timestamp: string;
  status: "success" | "error" | "info" | "in_progress";
  progress?: number;
  payload?: Record<string, any>;
}

export interface IEventBus {
  publish(event: AIEventPayload): Promise<void>;
  subscribe(jobId: string, eventType: AIEventType | "*", callback: (event: AIEventPayload) => void): void;
  unsubscribe(jobId: string, eventType: AIEventType | "*", callback: (event: AIEventPayload) => void): void;
  once(jobId: string, eventType: AIEventType, callback: (event: AIEventPayload) => void): void;
  destroy(): void;
}
