export const onGenerationFinished = async (jobId: string) => {};
