export const onAssetCreated = async (assetId: string) => {};
