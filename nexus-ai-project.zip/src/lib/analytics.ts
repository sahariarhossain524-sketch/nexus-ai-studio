/**
 * Placeholder for future Analytics & Event tracking hooks.
 * Used for presentation architecture only.
 */

export type AuthEvent = 
  | "login_started"
  | "login_success"
  | "login_failed"
  | "signup_started"
  | "signup_completed"
  | "signup_failed"
  | "password_reset_requested"
  | "password_reset_completed"
  | "oauth_started"
  | "oauth_completed";

export const trackAuthEvent = (event: AuthEvent, metadata?: Record<string, unknown>) => {
  // TODO: Connect to Segment, PostHog, or Mixpanel
  if (process.env.NODE_ENV !== "production") {
    console.debug(`[Analytics Hook] ${event}`, metadata || "");
  }
};
