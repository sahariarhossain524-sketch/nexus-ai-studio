// Core Domain Type Declarations from MASTER_PRODUCT_SPEC.md

export type ProjectStatus = "Draft" | "Generating" | "Review" | "Ready" | "Exported" | "Archived";

export type AgentRole =
  | "Orchestrator"
  | "MarketResearch"
  | "BusinessStrategy"
  | "Branding"
  | "Marketing"
  | "PitchDeck"
  | "Critic";

export type ModuleCategory =
  | "Business"
  | "Branding"
  | "Product"
  | "Marketing"
  | "Finance"
  | "PitchDeck";

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

export interface Workspace {
  id: string;
  ownerId: string;
  name: string;
  plan: "Free" | "Pro" | "Enterprise";
  createdAt: Date;
}

export interface Project {
  id: string;
  workspaceId: string;
  title: string;
  conceptPrompt: string;
  status: ProjectStatus;
  createdAt: Date;
  updatedAt: Date;
}
