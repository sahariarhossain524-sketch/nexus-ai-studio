"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { PasswordRequirements } from "@/components/auth/PasswordRequirements";
import { authI18n } from "@/lib/i18n-mock";
import { trackAuthEvent } from "@/lib/analytics";

export default function SignUpPage() {
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [password, setPassword] = React.useState("");
  const router = useRouter();
  
  const { common, signup } = authI18n;

  // Analytics on mount
  React.useEffect(() => {
    trackAuthEvent("signup_started");
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setTimeout(() => {
      setIsLoading(false);
      trackAuthEvent("signup_completed");
      router.push("/dashboard");
    }, 500);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2 text-center">
        <h2 className="text-3xl font-bold tracking-tight">{signup.title}</h2>
        <p className="text-text-secondary text-sm">
          {signup.subtitle}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-md bg-error/10 border border-error/20 flex items-start gap-3 text-error" role="alert">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        <div className="space-y-2">
          <label htmlFor="name" className="text-sm font-medium leading-none">
            {signup.nameLabel}
          </label>
          <Input 
            id="name" 
            type="text" 
            placeholder={signup.namePlaceholder} 
            required 
            autoComplete="name"
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium leading-none">
            {common.emailLabel}
          </label>
          <Input 
            id="email" 
            type="email" 
            placeholder={common.emailPlaceholder} 
            required 
            autoComplete="email"
            disabled={isLoading}
            aria-invalid={!!error}
          />
        </div>

        <div className="space-y-2">
          <label htmlFor="password" className="text-sm font-medium leading-none">
            {common.passwordLabel}
          </label>
          <Input 
            id="password" 
            type="password" 
            placeholder={common.createPasswordPlaceholder} 
            required 
            autoComplete="new-password"
            disabled={isLoading}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <PasswordRequirements password={password} />
        </div>

        <div className="space-y-2">
          <label htmlFor="confirmPassword" className="text-sm font-medium leading-none">
            {common.confirmPasswordLabel}
          </label>
          <Input 
            id="confirmPassword" 
            type="password" 
            placeholder={common.confirmPasswordPlaceholder} 
            required 
            autoComplete="new-password"
            disabled={isLoading}
          />
        </div>

        <div className="flex items-center space-x-2 pt-2">
          <input 
            type="checkbox" 
            id="terms" 
            required
            className="h-4 w-4 rounded border-border text-primary focus:ring-primary bg-surface disabled:cursor-not-allowed disabled:opacity-50"
            disabled={isLoading}
          />
          <label
            htmlFor="terms"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-text-secondary"
          >
            {signup.acceptTermsPrefix}
            <Link href="#" className="text-primary hover:underline">{common.termsOfService}</Link> 
            {signup.acceptTermsAnd} 
            <Link href="#" className="text-primary hover:underline">{common.privacyPolicy}</Link>
            {signup.acceptTermsSuffix}
          </label>
        </div>

        <Button type="submit" className="w-full mt-2" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {signup.createAccount}
        </Button>
      </form>

      <p className="text-center text-sm text-text-muted">
        {signup.hasAccount}{" "}
        <Link href="/login" className="font-medium text-primary hover:underline">
          {signup.loginLink}
        </Link>
      </p>
    </div>
  );
}
