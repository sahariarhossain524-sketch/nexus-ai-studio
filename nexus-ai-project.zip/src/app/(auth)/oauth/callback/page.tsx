"use client";

import * as React from "react";
import { Loader2 } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function OAuthCallbackPage() {
  const { oauthCallback } = authI18n;

  return (
    <div className="flex flex-col items-center justify-center space-y-6 text-center animate-in fade-in duration-500 min-h-[50vh]">
      <Loader2 className="h-10 w-10 animate-spin text-primary" />
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">{oauthCallback.title}</h2>
        <p className="text-text-secondary text-sm">
          {oauthCallback.subtitle}
        </p>
      </div>
      <p className="text-xs text-text-muted animate-pulse">
        {oauthCallback.redirecting}
      </p>
    </div>
  );
}
