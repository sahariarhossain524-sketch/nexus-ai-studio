"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Loader2, ArrowLeft } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";
import { trackAuthEvent } from "@/lib/analytics";

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = React.useState(false);
  const [isSuccess, setIsSuccess] = React.useState(false);

  const { common, forgotPassword } = authI18n;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    trackAuthEvent("password_reset_requested");
    
    setTimeout(() => {
      setIsLoading(false);
      setIsSuccess(true);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500 text-center">
        <div className="flex justify-center mb-4">
          <div className="h-16 w-16 bg-success/10 rounded-full flex items-center justify-center">
            <CheckCircle2 className="h-8 w-8 text-success" />
          </div>
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold tracking-tight">{forgotPassword.successTitle}</h2>
          <p className="text-text-secondary text-sm max-w-sm mx-auto">
            {forgotPassword.successSubtitle}
          </p>
        </div>
        <div className="pt-4">
          <Button variant="outline" asChild className="w-full">
            <Link href="/login">{forgotPassword.returnToLogin}</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2">
        <Link href="/login" className="inline-flex items-center text-sm text-text-muted hover:text-foreground transition-colors mb-2">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {common.backToLogin}
        </Link>
        <h2 className="text-3xl font-bold tracking-tight">{forgotPassword.title}</h2>
        <p className="text-text-secondary text-sm">
          {forgotPassword.subtitle}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium leading-none">
            {common.emailLabel}
          </label>
          <Input 
            id="email" 
            type="email" 
            placeholder={common.emailPlaceholder} 
            required 
            autoComplete="email"
            disabled={isLoading}
          />
        </div>

        <Button type="submit" className="w-full mt-2" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {forgotPassword.sendLink}
        </Button>
      </form>
    </div>
  );
}
