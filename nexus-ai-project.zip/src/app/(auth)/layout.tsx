import * as React from "react";
import Link from "next/link";
import { Zap } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { common, layout } = authI18n;

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Left Panel: Branding & Marketing (Hidden on Mobile) */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between bg-surface p-12 border-r border-border relative overflow-hidden">
        {/* Subtle Background Pattern/Illustration */}
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:32px_32px]" />
        <div className="absolute left-0 right-0 top-0 -mt-24 h-96 w-full rounded-full bg-primary/20 blur-3xl opacity-50" />
        
        <div className="relative z-10 flex items-center gap-2">
          <Zap className="h-8 w-8 text-primary" />
          <span className="text-2xl font-bold tracking-tight">{common.appName}</span>
        </div>

        <div className="relative z-10 space-y-6 max-w-lg">
          <h1 className="text-4xl font-bold tracking-tight text-foreground">
            {layout.heroTitle}
          </h1>
          <p className="text-lg text-text-secondary">
            {layout.heroSubtitle}
          </p>
          
          <div className="pt-8 space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">1</div>
              <p className="text-sm font-medium">{layout.step1}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">2</div>
              <p className="text-sm font-medium">{layout.step2}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">3</div>
              <p className="text-sm font-medium">{layout.step3}</p>
            </div>
          </div>
        </div>

        <div className="relative z-10 text-sm text-text-muted">
          {common.copyright}
        </div>
      </div>

      {/* Right Panel: Authentication Form */}
      <div className="flex flex-1 flex-col items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md space-y-8 flex-1 flex flex-col justify-center">
          {/* Mobile Logo */}
          <div className="flex lg:hidden items-center justify-center gap-2 mb-8">
            <Zap className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold tracking-tight">{common.appName}</span>
          </div>
          
          {children}
        </div>
        
        {/* Legal Footer */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-text-muted">
          <Link href="#" className="hover:text-foreground transition-colors">{common.privacyPolicy}</Link>
          <Link href="#" className="hover:text-foreground transition-colors">{common.termsOfService}</Link>
          <Link href="#" className="hover:text-foreground transition-colors">{common.cookiePolicy}</Link>
          <Link href="#" className="hover:text-foreground transition-colors">{common.support}</Link>
        </div>
      </div>
    </div>
  );
}
