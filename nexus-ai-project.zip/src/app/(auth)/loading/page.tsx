import * as React from "react";
import { Loader2 } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function LoadingPage() {
  const { loading } = authI18n;

  return (
    <div className="flex flex-col items-center justify-center space-y-6 text-center animate-in fade-in duration-500 min-h-[50vh]">
      <Loader2 className="h-10 w-10 animate-spin text-primary" />
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">{loading.title}</h2>
        <p className="text-text-secondary text-sm">
          {loading.subtitle}
        </p>
      </div>
      
      {/* Skeleton Placeholders */}
      <div className="w-full max-w-sm space-y-3 pt-8 opacity-50">
        <div className="h-4 w-full bg-surface-hover rounded animate-pulse"></div>
        <div className="h-4 w-3/4 bg-surface-hover rounded animate-pulse"></div>
        <div className="h-4 w-5/6 bg-surface-hover rounded animate-pulse"></div>
      </div>
    </div>
  );
}
