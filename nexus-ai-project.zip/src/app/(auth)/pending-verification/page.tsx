import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Clock, ExternalLink } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function PendingVerificationPage() {
  const { pendingVerification } = authI18n;

  return (
    <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500 text-center py-8">
      <div className="flex justify-center mb-6">
        <div className="h-20 w-20 bg-warning/10 rounded-full flex items-center justify-center">
          <Clock className="h-10 w-10 text-warning" />
        </div>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight text-warning">{pendingVerification.title}</h2>
        <p className="text-text-secondary text-sm max-w-sm mx-auto">
          {pendingVerification.subtitle}
        </p>
      </div>

      <div className="pt-6 space-y-3">
        <Button asChild className="w-full">
          <Link href="/">{pendingVerification.returnHome}</Link>
        </Button>
        <Button variant="outline" type="button" className="w-full">
          {pendingVerification.contactSupport} <ExternalLink className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
