import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { LogOut, ArrowRight } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function SessionExpiredPage() {
  const { common, sessionExpired } = authI18n;

  return (
    <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500 text-center py-8">
      <div className="flex justify-center mb-6">
        <div className="h-20 w-20 bg-surface rounded-full flex items-center justify-center border border-border">
          <LogOut className="h-10 w-10 text-text-secondary" />
        </div>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">{sessionExpired.title}</h2>
        <p className="text-text-secondary text-sm max-w-sm mx-auto">
          {sessionExpired.subtitle}
        </p>
      </div>

      <div className="pt-6 space-y-3">
        {/* Placeholder for a quick re-auth flow if the user is remembered locally */}
        <Button variant="outline" type="button" className="w-full bg-surface">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded-full bg-primary/20 text-primary flex items-center justify-center text-xs font-bold">
                AD
              </div>
              <span className="font-medium">{sessionExpired.continuePlaceholder}</span>
            </div>
            <ArrowRight className="h-4 w-4" />
          </div>
        </Button>
        <Button asChild className="w-full">
          <Link href="/login">{common.backToLogin}</Link>
        </Button>
      </div>
    </div>
  );
}
