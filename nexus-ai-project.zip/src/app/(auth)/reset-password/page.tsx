"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Loader2 } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";
import { trackAuthEvent } from "@/lib/analytics";
import { PasswordRequirements } from "@/components/auth/PasswordRequirements";

export default function ResetPasswordPage() {
  const [isLoading, setIsLoading] = React.useState(false);
  const [isSuccess, setIsSuccess] = React.useState(false);
  const [password, setPassword] = React.useState("");

  const { common, resetPassword } = authI18n;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      setIsSuccess(true);
      trackAuthEvent("password_reset_completed");
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500 text-center">
        <div className="flex justify-center mb-4">
          <div className="h-16 w-16 bg-success/10 rounded-full flex items-center justify-center">
            <CheckCircle2 className="h-8 w-8 text-success" />
          </div>
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold tracking-tight">{resetPassword.successTitle}</h2>
          <p className="text-text-secondary text-sm max-w-sm mx-auto">
            {resetPassword.successSubtitle}
          </p>
        </div>
        <div className="pt-4">
          <Button variant="outline" asChild className="w-full">
            <Link href="/login">{common.backToLogin}</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">{resetPassword.title}</h2>
        <p className="text-text-secondary text-sm">
          {resetPassword.subtitle}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="password" className="text-sm font-medium leading-none">
            {common.passwordLabel}
          </label>
          <Input 
            id="password" 
            type="password" 
            placeholder={common.createPasswordPlaceholder} 
            required 
            autoComplete="new-password"
            disabled={isLoading}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <PasswordRequirements password={password} />
        </div>

        <div className="space-y-2">
          <label htmlFor="confirmPassword" className="text-sm font-medium leading-none">
            {common.confirmPasswordLabel}
          </label>
          <Input 
            id="confirmPassword" 
            type="password" 
            placeholder={common.confirmPasswordPlaceholder} 
            required 
            autoComplete="new-password"
            disabled={isLoading}
          />
        </div>

        <Button type="submit" className="w-full mt-2" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {resetPassword.resetButton}
        </Button>
      </form>
    </div>
  );
}
