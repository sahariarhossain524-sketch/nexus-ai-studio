import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ShieldAlert } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function UnauthorizedPage() {
  const { common, unauthorized } = authI18n;

  return (
    <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500 text-center py-8">
      <div className="flex justify-center mb-6">
        <div className="h-20 w-20 bg-error/10 rounded-full flex items-center justify-center">
          <ShieldAlert className="h-10 w-10 text-error" />
        </div>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight text-error">{unauthorized.title}</h2>
        <p className="text-text-secondary text-sm max-w-sm mx-auto">
          {unauthorized.subtitle}
        </p>
      </div>

      <div className="pt-6">
        <Button asChild className="w-full">
          <Link href="/login">{common.backToLogin}</Link>
        </Button>
      </div>
    </div>
  );
}
