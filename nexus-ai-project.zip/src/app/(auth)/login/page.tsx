"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useRouter } from "next/navigation";
import { AlertCircle, Loader2, Github, ShieldCheck, Lock } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";
import { trackAuthEvent } from "@/lib/analytics";

export default function LoginPage() {
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const router = useRouter();
  
  const { common, login } = authI18n;

  // Analytics on mount
  React.useEffect(() => {
    trackAuthEvent("login_started");
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    
    // Simulate network request then route
    setTimeout(() => {
      setIsLoading(false);
      trackAuthEvent("login_success");
      router.push("/dashboard");
    }, 500);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2 text-center">
        <h2 className="text-3xl font-bold tracking-tight">{login.title}</h2>
        <p className="text-text-secondary text-sm">
          {login.subtitle}
        </p>
      </div>

      <div className="grid gap-4">
        <Button 
          variant="outline" 
          type="button" 
          className="w-full bg-surface" 
          disabled={isLoading}
          onClick={() => {
            trackAuthEvent("oauth_started", { provider: "google" });
            router.push("/dashboard");
          }}
        >
          <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          {common.continueWithGoogle}
        </Button>
        <Button 
          variant="outline" 
          type="button" 
          className="w-full bg-surface" 
          disabled={isLoading}
          onClick={() => {
            trackAuthEvent("oauth_started", { provider: "github" });
            router.push("/dashboard");
          }}
        >
          <Github className="mr-2 h-4 w-4" />
          {common.continueWithGithub}
        </Button>
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-text-muted">{login.orContinueWith}</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-md bg-error/10 border border-error/20 flex items-start gap-3 text-error" role="alert">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
            {common.emailLabel}
          </label>
          <Input 
            id="email" 
            type="email" 
            placeholder={common.emailPlaceholder} 
            required 
            autoComplete="email"
            disabled={isLoading}
            aria-invalid={!!error}
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label htmlFor="password" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              {common.passwordLabel}
            </label>
            <Link href="/forgot-password" className="text-sm font-medium text-primary hover:underline" tabIndex={-1}>
              {login.forgotPassword}
            </Link>
          </div>
          <Input 
            id="password" 
            type="password" 
            placeholder={common.passwordPlaceholder} 
            required 
            autoComplete="current-password"
            disabled={isLoading}
            aria-invalid={!!error}
          />
        </div>

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {login.signIn}
        </Button>
      </form>

      {/* Future Hooks Placeholder */}
      <div className="pt-2 space-y-3 border-t border-border/50">
        <Button variant="outline" type="button" className="w-full bg-surface" disabled={isLoading} onClick={() => router.push("/dashboard")}>
          {common.continueWithPasskey}
        </Button>
        <Button variant="ghost" type="button" className="w-full" disabled={isLoading} onClick={() => router.push("/dashboard")}>
          {common.magicLink}
        </Button>
      </div>

      <div className="flex items-center justify-center gap-4 py-4 text-xs font-medium text-text-muted">
        <div className="flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-success" /> {common.secureAuth}</div>
        <div className="h-3 w-px bg-border"></div>
        <div className="flex items-center gap-1.5"><Lock className="h-4 w-4 text-text-secondary" /> {common.enterpriseEncrypted}</div>
      </div>

      <p className="text-center text-sm text-text-muted">
        {login.noAccount}{" "}
        <Link href="/signup" className="font-medium text-primary hover:underline">
          {login.signUpLink}
        </Link>
      </p>
    </div>
  );
}
