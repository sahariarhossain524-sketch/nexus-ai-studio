"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, ArrowLeft, Mail } from "lucide-react";
import { authI18n } from "@/lib/i18n-mock";

export default function VerifyEmailPage() {
  const [isLoading, setIsLoading] = React.useState(false);

  const { common, verifyEmail } = authI18n;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      // Logic for successful verification would go here
    }, 1500);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 text-center">
      <div className="flex justify-center mb-6">
        <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
          <Mail className="h-8 w-8 text-primary" />
        </div>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">{verifyEmail.title}</h2>
        <p className="text-text-secondary text-sm">
          {verifyEmail.subtitle}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 pt-4">
        <div className="space-y-2 text-left">
          <label htmlFor="code" className="text-sm font-medium leading-none sr-only">
            {verifyEmail.codeLabel}
          </label>
          <Input 
            id="code" 
            type="text" 
            placeholder={verifyEmail.codePlaceholder} 
            className="text-center tracking-widest text-lg h-12"
            maxLength={6}
            required 
            disabled={isLoading}
          />
        </div>

        <Button type="submit" className="w-full mt-2" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {verifyEmail.verifyButton}
        </Button>
      </form>

      <div className="pt-2">
        <Button variant="ghost" type="button" className="text-text-muted" disabled>
          {verifyEmail.resendWait}
        </Button>
      </div>
      
      <div className="pt-4 border-t border-border/50">
        <Link href="/login" className="inline-flex items-center text-sm text-text-muted hover:text-foreground transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {common.backToLogin}
        </Link>
      </div>
    </div>
  );
}
