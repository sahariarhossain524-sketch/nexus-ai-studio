"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { AlertOctagon } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  React.useEffect(() => {
    // Optionally log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <html>
      <body>
        <div className="flex h-screen w-full flex-col items-center justify-center bg-background p-6 text-center">
          <div className="flex justify-center mb-6">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-error/10">
              <AlertOctagon className="h-10 w-10 text-error" />
            </div>
          </div>
          <h2 className="mb-2 text-2xl font-bold tracking-tight">Something went wrong!</h2>
          <p className="mb-6 max-w-md text-sm text-text-secondary">
            An unexpected error occurred while processing your request. Please try again or contact support if the issue persists.
          </p>
          <div className="flex gap-4">
            <Button onClick={() => reset()}>Try again</Button>
            <Button variant="outline" onClick={() => window.location.href = "/"}>Return Home</Button>
          </div>
        </div>
      </body>
    </html>
  );
}
