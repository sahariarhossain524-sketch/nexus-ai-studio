import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { SectionHeader } from "@/components/common/SectionHeader";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AgentStatusBadge } from "@/components/common/AgentStatusBadge";
import { ActivityCard } from "@/components/common/ActivityCard";
import { Bot, Cpu, CheckCircle2, AlertCircle, Settings2, Sparkles, TrendingUp, Palette, Briefcase, FileText } from "lucide-react";

export default function AgentsPage() {
  const agents = [
    { name: "Orchestrator", icon: Bot, status: "running", desc: "Oversees multi-agent pipeline and maintains global context.", tasks: 124 },
    { name: "Market Research", icon: TrendingUp, status: "idle", desc: "Defines target ICP, demographics, and competitors.", tasks: 45 },
    { name: "Brand Strategy", icon: Palette, status: "completed", desc: "Establishes brand name, taglines, and visual style guide.", tasks: 89 },
    { name: "Business Strategy", icon: Briefcase, status: "error", desc: "Constructs Lean Canvas and feature roadmaps.", tasks: 62 },
    { name: "Pitch Deck", icon: FileText, status: "running", desc: "Drafts 8-slide investor pitch outline and speaker notes.", tasks: 31 },
  ] as const;

  return (
    <PageContainer>
      <SectionHeader 
        title="AI Agent Fleet" 
        description="Monitor and manage your specialized AI workers across all active projects."
        action={
          <Button>
            <Sparkles className="mr-2 h-4 w-4" />
            Train Custom Agent
          </Button>
        }
      />

      <div className="grid gap-6 xl:grid-cols-3">
        {/* Left Column: Agent Cards Grid */}
        <div className="xl:col-span-2 space-y-6">
          <div className="flex items-center gap-4 border-b border-border pb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Cpu className="h-5 w-5 text-primary" />
              Active Roster
            </h2>
            <Badge variant="outline" className="bg-surface">5 Agents Available</Badge>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {agents.map((agent, i) => (
              <Card key={i} className="flex flex-col shadow-none hover:shadow-floating transition-shadow border-border/50">
                <CardHeader className="pb-3 flex flex-row justify-between items-start space-y-0">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
                      <agent.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{agent.name}</CardTitle>
                      <p className="text-xs text-text-muted mt-0.5">v2.4.1 (GPT-4o core)</p>
                    </div>
                  </div>
                  <AgentStatusBadge name="" status={agent.status} className="px-2" />
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-text-secondary">{agent.desc}</p>
                </CardContent>
                <CardFooter className="pt-3 border-t border-border/50 flex justify-between items-center text-xs text-text-muted bg-surface-hover/30">
                  <span>{agent.tasks} tasks completed</span>
                  <Button variant="ghost" size="sm" className="h-7 px-2">
                    <Settings2 className="h-3 w-3 mr-1" /> Configure
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>

        {/* Right Column: Global Queue & Activity */}
        <div className="space-y-6">
          <Card className="shadow-none border-border/50 flex flex-col h-[400px]">
            <CardHeader className="py-4 border-b border-border/50 shrink-0">
              <CardTitle className="text-sm font-semibold flex items-center justify-between">
                <span>Global Execution Queue</span>
                <Badge variant="secondary" className="font-mono">3 jobs</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-0">
              <div className="divide-y divide-border">
                <div className="p-4 bg-primary/5 hover:bg-primary/10 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm font-medium">Generate Pitch Deck Slides</span>
                    <span className="text-xs text-primary animate-pulse flex items-center gap-1">
                      <Cpu className="h-3 w-3"/> Processing
                    </span>
                  </div>
                  <p className="text-xs text-text-secondary mb-2">Project: Fintech Mobile App</p>
                  <div className="flex items-center gap-2">
                    <AgentStatusBadge name="Pitch Deck" status="running" />
                  </div>
                </div>

                <div className="p-4 hover:bg-surface-hover transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm font-medium">Competitor Matrix Analysis</span>
                    <span className="text-xs text-text-muted flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3 text-success"/> Ready
                    </span>
                  </div>
                  <p className="text-xs text-text-secondary mb-2">Project: SaaS Developer Tool</p>
                  <div className="flex items-center gap-2">
                    <AgentStatusBadge name="Orchestrator" status="idle" />
                  </div>
                </div>

                <div className="p-4 bg-error/5 hover:bg-error/10 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm font-medium">Financial Model Output</span>
                    <span className="text-xs text-error flex items-center gap-1">
                      <AlertCircle className="h-3 w-3"/> Failed
                    </span>
                  </div>
                  <p className="text-xs text-text-secondary mb-2">Project: Eco-Friendly E-commerce</p>
                  <div className="flex items-center gap-2">
                    <AgentStatusBadge name="Business Strategy" status="error" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-none border-border/50">
            <CardHeader className="py-4 border-b border-border/50">
              <CardTitle className="text-sm font-semibold">Recent System Activity</CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-2">
              <ActivityCard 
                user={{ name: "Orchestrator" }}
                action="allocated resources to"
                target="Pitch Deck Agent"
                timestamp="2 mins ago"
              />
              <ActivityCard 
                user={{ name: "System" }}
                action="reported token limit warning for"
                target="Business Strategy Agent"
                timestamp="15 mins ago"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
