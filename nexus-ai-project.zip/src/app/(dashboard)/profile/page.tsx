import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ActivityCard } from "@/components/common/ActivityCard";
import { Mail, Briefcase, MapPin, Edit2, ShieldCheck } from "lucide-react";

export default function ProfilePage() {
  return (
    <PageContainer>
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column: Profile Card & Status */}
        <div className="space-y-6">
          <Card className="shadow-none border-border/50 text-center overflow-hidden">
            <div className="h-32 bg-gradient-to-r from-primary/20 to-primary/5"></div>
            <CardContent className="pt-0 relative">
              <div className="flex justify-center -mt-12 mb-4">
                <div className="relative">
                  <Avatar className="h-24 w-24 border-4 border-background">
                    <AvatarImage src="" />
                    <AvatarFallback className="text-2xl bg-primary/10 text-primary">AD</AvatarFallback>
                  </Avatar>
                  <button className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-surface border border-border flex items-center justify-center text-text-muted hover:text-foreground transition-colors">
                    <Edit2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <h2 className="text-xl font-bold">Alex Developer</h2>
              <p className="text-sm text-text-muted mb-4">Solo Founder</p>
              
              <div className="flex flex-col gap-2 text-sm text-text-secondary text-left mb-6">
                <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-text-muted" /> alex@example.com</div>
                <div className="flex items-center gap-2"><Briefcase className="h-4 w-4 text-text-muted" /> Indie Hacker</div>
                <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-text-muted" /> San Francisco, CA</div>
              </div>

              <div className="flex items-center justify-center gap-2 p-3 rounded-md bg-success/10 text-success text-sm font-medium">
                <ShieldCheck className="h-5 w-5" /> Account Verified
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-none border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Usage Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-text-secondary">Projects</span>
                  <span className="font-medium">4 / 10</span>
                </div>
                <div className="h-2 w-full bg-surface-hover rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-[40%] rounded-full"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-text-secondary">Compute Hours</span>
                  <span className="font-medium">34.5 / 100</span>
                </div>
                <div className="h-2 w-full bg-surface-hover rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-[34.5%] rounded-full"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Forms & Activity */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Update your personal details.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">First Name</label>
                  <Input defaultValue="Alex" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Last Name</label>
                  <Input defaultValue="Developer" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Title / Role</label>
                <Input defaultValue="Solo Founder" />
              </div>
              <Button>Update Profile</Button>
            </CardContent>
          </Card>

          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>Details for invoices and global workspace settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Company Name</label>
                <Input placeholder="e.g. Acme Corp" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Tax ID / VAT</label>
                <Input placeholder="Optional" />
              </div>
              <Button variant="secondary">Save Company</Button>
            </CardContent>
          </Card>

          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Recent Account Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <ActivityCard 
                user={{ name: "Alex Developer" }}
                action="logged in from"
                target="Mac OS (Chrome)"
                timestamp="2 hours ago"
              />
              <ActivityCard 
                user={{ name: "System" }}
                action="renewed"
                target="Pro Subscription"
                timestamp="5 days ago"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
