import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";

export default function DashboardLoading() {
  return (
    <PageContainer>
      <div className="space-y-8 animate-pulse opacity-50 pt-2">
        {/* Header Skeleton */}
        <div className="space-y-3">
          <div className="h-8 w-1/4 rounded-md bg-surface-hover"></div>
          <div className="h-4 w-1/3 rounded-md bg-surface-hover"></div>
        </div>
        
        {/* Grid Skeleton */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 w-full rounded-xl bg-surface-hover border border-border/50"></div>
          ))}
        </div>
      </div>
    </PageContainer>
  );
}
