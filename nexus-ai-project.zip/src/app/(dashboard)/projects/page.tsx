import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { SectionHeader } from "@/components/common/SectionHeader";
import { ProjectCard } from "@/components/common/ProjectCard";
import { CreateProjectDialog } from "@/components/common/CreateProjectDialog";
import { ProjectService } from "@/server/services/project.service";

export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
  const projects = await ProjectService.getWorkspaceProjects("ws_123", "user_123");
  return (
    <PageContainer>
      <SectionHeader 
        title="Your Projects" 
        description="Manage your AI-generated startup concepts and launch assets."
        action={
          <CreateProjectDialog />
        }
      />

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {projects.length === 0 ? (
          <div className="col-span-full py-12 text-center text-text-muted bg-surface/30 rounded-xl border border-dashed border-border/50">
            No projects yet. Click &quot;New Startup&quot; to get started.
          </div>
        ) : (
          projects.map((project) => (
            <ProjectCard
              key={project.id}
              title={project.name}
              description={project.description || "No description provided."}
              status="active"
              updatedAt={project.updatedAt}
              href={`/projects/${project.id}/workspace`}
            />
          ))
        )}
      </div>
    </PageContainer>
  );
}
