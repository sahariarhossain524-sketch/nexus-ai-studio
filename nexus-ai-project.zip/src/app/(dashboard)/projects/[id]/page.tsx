import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TimelineItem } from "@/components/common/TimelineItem";
import { ActivityCard } from "@/components/common/ActivityCard";
import { StatCard } from "@/components/common/StatCard";
import { Target, Users, Calendar, Briefcase } from "lucide-react";

export default function ProjectDetailsPage() {
  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {/* Main Content Column */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Summary Stats */}
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard title="Generated Assets" value="12" className="shadow-none border-border/50" />
          <StatCard title="Agents Used" value="5" className="shadow-none border-border/50" />
          <StatCard title="Readiness Score" value="84%" trend={5} className="shadow-none border-border/50" />
        </div>

        {/* Progress Timeline */}
        <Card className="shadow-none border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Generation Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 pt-2">
            <TimelineItem 
              title="Initialization & Research" 
              description="Market research and competitor analysis completed by Market Research Agent."
              status="completed" 
            />
            <TimelineItem 
              title="Brand Strategy & Core Identity" 
              description="Logo concepts, tone of voice, and taglines generated."
              status="completed" 
            />
            <TimelineItem 
              title="Go-to-Market & Financials" 
              description="Currently calculating Unit Economics and 30-day launch plan."
              status="running" 
            />
            <TimelineItem 
              title="Pitch Deck Generation" 
              description="Waiting for financial model data to synthesize slides."
              status="pending" 
              isLast
            />
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="shadow-none border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <ActivityCard 
              user={{ name: "Branding Agent" }}
              action="finalized"
              target="Brand Color Palette"
              timestamp="10 mins ago"
            />
            <ActivityCard 
              user={{ name: "Market Research Agent" }}
              action="added"
              target="Competitor Matrix"
              timestamp="45 mins ago"
            />
            <ActivityCard 
              user={{ name: "Orchestrator" }}
              action="started phase 2 generation"
              timestamp="1 hour ago"
            />
          </CardContent>
        </Card>
      </div>

      {/* Sidebar Column */}
      <div className="space-y-6">
        <Card className="shadow-none border-border/50 bg-surface/50">
          <CardHeader>
            <CardTitle className="text-sm font-semibold text-text-secondary uppercase tracking-wider">
              Project Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <span className="flex items-center text-sm text-text-muted"><Target className="mr-2 h-4 w-4"/> Target Market</span>
              <p className="text-sm font-medium">Gen-Z & Millennials</p>
            </div>
            <div className="space-y-1">
              <span className="flex items-center text-sm text-text-muted"><Users className="mr-2 h-4 w-4"/> Core Persona</span>
              <p className="text-sm font-medium">Urban Freelancers</p>
            </div>
            <div className="space-y-1">
              <span className="flex items-center text-sm text-text-muted"><Briefcase className="mr-2 h-4 w-4"/> Industry</span>
              <p className="text-sm font-medium">Fintech / Consumer SaaS</p>
            </div>
            <div className="space-y-1">
              <span className="flex items-center text-sm text-text-muted"><Calendar className="mr-2 h-4 w-4"/> Created On</span>
              <p className="text-sm font-medium">August 3, 2026</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
