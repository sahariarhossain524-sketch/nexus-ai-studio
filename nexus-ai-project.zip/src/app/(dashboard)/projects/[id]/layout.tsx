"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { PageContainer } from "@/components/common/PageContainer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, Download } from "lucide-react";

export default function ProjectLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ id: string }>;
}) {
  const pathname = usePathname();
  const { id } = React.use(params);
  
  const basePath = `/projects/${id}`;
  
  const tabs = [
    { label: "Overview", href: basePath, exact: true },
    { label: "AI Workspace", href: `${basePath}/workspace` },
    { label: "Documents", href: `${basePath}/documents` },
  ];

  return (
    <PageContainer className="p-0">
      <div className="flex flex-col border-b border-border bg-background px-6 pt-6">
        {/* Breadcrumb / Back */}
        <div className="mb-4">
          <Link href="/projects" className="inline-flex items-center text-sm text-text-muted hover:text-foreground transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Projects
          </Link>
        </div>

        {/* Project Header */}
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-2xl font-bold tracking-tight text-foreground">Fintech Mobile App</h1>
              <Badge variant="outline" className="bg-success/10 text-success border-success/20">Active</Badge>
            </div>
            <p className="text-text-secondary max-w-2xl">
              AI-generated branding, GTM strategy, and financial model for a GenZ finance app.
            </p>
          </div>
          
          <div className="flex items-center gap-3 shrink-0">
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export Assets
            </Button>
            <Button size="sm">
              <Play className="mr-2 h-4 w-4" />
              Resume Session
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-1">
          {tabs.map((tab) => {
            const isActive = tab.exact ? pathname === tab.href : pathname.startsWith(tab.href);
            return (
              <Link
                key={tab.label}
                href={tab.href}
                className={cn(
                  "px-4 py-2 text-sm font-medium border-b-2 transition-colors",
                  isActive
                    ? "border-primary text-primary"
                    : "border-transparent text-text-secondary hover:text-foreground hover:border-border"
                )}
              >
                {tab.label}
              </Link>
            );
          })}
        </div>
      </div>
      
      {/* Page Content */}
      <div className="p-6">
        {children}
      </div>
    </PageContainer>
  );
}
