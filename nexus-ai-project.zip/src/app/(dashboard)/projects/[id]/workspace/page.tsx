"use client";

import * as React from "react";
import { use, useEffect, useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { AgentStatusBadge } from "@/components/common/AgentStatusBadge";
import { ActivityCard } from "@/components/common/ActivityCard";
import { Send, Terminal, Code, Layout, MessageSquare, Loader2, StopCircle } from "lucide-react";
import { triggerGenerationAction } from "@/server/actions/generation.actions";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

interface WorkspacePageProps {
  params: Promise<{ id: string }>;
}

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: "info" | "success" | "warning" | "error";
}

interface Artifact {
  version: string;
  content: string;
  agentId: string;
  createdAt: string;
}

export default function WorkspacePage({ params }: WorkspacePageProps) {
  const { id: projectId } = use(params);
  const [activeTab, setActiveTab] = useState("preview");
  const [prompt, setPrompt] = useState("");
  const [jobId, setJobId] = useState<string | null>(null);
  
  // SSE State
  const [isGenerating, setIsGenerating] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [activeAgents, setActiveAgents] = useState<Set<string>>(new Set());
  const [progress, setProgress] = useState(0);

  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs]);

  useEffect(() => {
    let eventSource: EventSource | null = null;

    if (jobId) {
      eventSource = new EventSource(`/api/generation/${jobId}/stream`);

      eventSource.onmessage = (event) => {
        const data = JSON.parse(event.data);

        // Filter out heartbeats
        if (data.eventType === "heartbeat") return;

        addLog({
          id: data.eventId,
          timestamp: new Date(data.timestamp).toLocaleTimeString(),
          message: `[${data.agentId || "System"}] ${data.eventType}`,
          type: data.status === "error" ? "error" : "info"
        });

        if (data.eventType === "agent.started" && data.agentId) {
          setActiveAgents(prev => new Set(prev).add(data.agentId));
          if (data.payload?.completed !== undefined && data.payload?.total) {
            setProgress((data.payload.completed / data.payload.total) * 100);
          }
        }

        if (data.eventType === "agent.completed" && data.agentId) {
          setActiveAgents(prev => {
            const next = new Set(prev);
            next.delete(data.agentId);
            return next;
          });
        }

        if (data.eventType === "artifact.created" && data.payload?.artifact) {
          setArtifacts(prev => [...prev, {
            version: data.payload.artifact.version,
            content: data.payload.artifact.payload,
            agentId: data.agentId,
            createdAt: data.timestamp
          }]);
        }

        if (data.eventType === "generation.completed" || data.eventType === "generation.failed") {
          setIsGenerating(false);
          setProgress(100);
          if (eventSource) {
            eventSource.close();
          }
        }
      };

      eventSource.onerror = (error) => {
        console.error("SSE Error:", error);
        addLog({
          id: crypto.randomUUID(),
          timestamp: new Date().toLocaleTimeString(),
          message: "Connection to stream lost. Attempting to reconnect...",
          type: "warning"
        });
        if (eventSource?.readyState === EventSource.CLOSED) {
          setIsGenerating(false);
        }
      };
    }

    return () => {
      if (eventSource) {
        eventSource.close();
      }
    };
  }, [jobId]);

  const addLog = (log: LogEntry) => {
    setLogs(prev => [...prev, log]);
  };

  const handleStartGeneration = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setLogs([]);
    setArtifacts([]);
    setProgress(0);
    setActiveAgents(new Set());
    
    addLog({
      id: crypto.randomUUID(),
      timestamp: new Date().toLocaleTimeString(),
      message: "Initializing Orchestrator...",
      type: "info"
    });

    const formData = new FormData();
    formData.append("prompt", prompt);
    
    // Basic hardcoded user for now, in a real app this is derived from session
    const response = await triggerGenerationAction(projectId, "user_123", formData);
    
    if (response.success && response.job) {
      setJobId(response.job.id);
      setPrompt("");
    } else {
      setIsGenerating(false);
      addLog({
        id: crypto.randomUUID(),
        timestamp: new Date().toLocaleTimeString(),
        message: `Failed to start: ${response.error}`,
        type: "error"
      });
    }
  };

  const latestArtifact = artifacts[artifacts.length - 1];

  return (
    <div className="grid gap-6 h-[calc(100vh-14rem)] lg:grid-cols-4">
      {/* Left Column: Agents & Input */}
      <div className="flex flex-col gap-6 lg:col-span-1">
        {/* Prompt Input */}
        <Card className="shadow-none border-border/50 shrink-0">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Orchestrator Prompt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input 
                placeholder="Direct the agents..." 
                className="h-9" 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !isGenerating && handleStartGeneration()}
                disabled={isGenerating}
              />
              <Button 
                size="icon" 
                className="h-9 w-9 shrink-0"
                onClick={handleStartGeneration}
                disabled={isGenerating || !prompt.trim()}
              >
                {isGenerating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Live Task / Agent Status */}
        <Card className="shadow-none border-border/50 flex-1 overflow-hidden flex flex-col">
          <CardHeader className="pb-3 shrink-0 flex flex-row items-center justify-between">
            <CardTitle className="text-sm">Active Agents</CardTitle>
            {isGenerating && (
              <span className="text-xs text-text-muted">{Math.round(progress)}%</span>
            )}
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto space-y-4">
            <div className="flex flex-wrap gap-2">
              {activeAgents.size === 0 && !isGenerating && (
                <span className="text-xs text-text-muted italic">No agents active</span>
              )}
              {Array.from(activeAgents).map(agent => (
                <AgentStatusBadge key={agent} name={agent} status="running" />
              ))}
            </div>
            
            <div className="space-y-3 pt-4 border-t border-border/50">
              <h4 className="text-xs font-semibold text-text-muted uppercase">Live Activity Stream</h4>
              {logs.slice(-5).reverse().map(log => (
                <ActivityCard 
                  key={log.id}
                  user={{ name: "System" }}
                  action="emitted"
                  target={log.message}
                  timestamp={log.timestamp}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Right Column: Preview & Output */}
      <Card className="lg:col-span-3 shadow-none border-border/50 flex flex-col overflow-hidden">
        <div className="flex items-center justify-between border-b border-border bg-surface-hover/30 px-4 py-2 shrink-0">
          <div className="flex gap-2">
            <Button 
              variant={activeTab === "preview" ? "secondary" : "ghost"} 
              size="sm" 
              onClick={() => setActiveTab("preview")}
            >
              <Layout className="mr-2 h-4 w-4" /> Preview
            </Button>
            <Button 
              variant={activeTab === "code" ? "secondary" : "ghost"} 
              size="sm"
              onClick={() => setActiveTab("code")}
            >
              <Code className="mr-2 h-4 w-4" /> Raw Output
            </Button>
            <Button 
              variant={activeTab === "logs" ? "secondary" : "ghost"} 
              size="sm"
              onClick={() => setActiveTab("logs")}
            >
              <Terminal className="mr-2 h-4 w-4" /> Execution Logs
            </Button>
          </div>
          {isGenerating ? (
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 animate-pulse">
              Live Sync
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-surface-hover text-text-muted">
              Disconnected
            </Badge>
          )}
        </div>

        <div className="flex-1 overflow-y-auto bg-surface/30 p-6 relative">
          {activeTab === "preview" && (
            <div className="space-y-6 animate-in fade-in">
              {!latestArtifact && isGenerating && (
                <div className="space-y-6 animate-in fade-in">
                  <div className="h-8 w-1/3 bg-surface-hover rounded-md animate-pulse"></div>
                  <div className="space-y-2">
                    <div className="h-4 w-full bg-surface-hover rounded-md animate-pulse"></div>
                    <div className="h-4 w-full bg-surface-hover rounded-md animate-pulse"></div>
                    <div className="h-4 w-3/4 bg-surface-hover rounded-md animate-pulse"></div>
                  </div>
                  <div className="h-48 w-full bg-surface-hover rounded-xl animate-pulse flex items-center justify-center border border-dashed border-border">
                    <span className="text-text-muted flex items-center gap-2">
                      <MessageSquare className="h-4 w-4 animate-bounce" /> 
                      Agents are drafting output...
                    </span>
                  </div>
                </div>
              )}
              {latestArtifact && (
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <div className="flex items-center gap-2 mb-4">
                    <Badge variant="secondary">{latestArtifact.agentId}</Badge>
                    <span className="text-xs text-text-muted">{latestArtifact.version}</span>
                  </div>
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {typeof latestArtifact.content === 'string' 
                      ? latestArtifact.content 
                      : JSON.stringify(latestArtifact.content, null, 2)}
                  </ReactMarkdown>
                </div>
              )}
            </div>
          )}

          {activeTab === "code" && (
            <pre className="p-4 rounded-lg bg-black text-green-400 font-mono text-sm overflow-x-auto whitespace-pre-wrap">
              <code>
                {latestArtifact 
                  ? JSON.stringify(latestArtifact.content, null, 2)
                  : "// Waiting for output..."}
              </code>
            </pre>
          )}

          {activeTab === "logs" && (
            <div className="font-mono text-xs space-y-2 text-text-muted pb-8">
              {logs.map(log => (
                <p key={log.id} className={
                  log.type === "error" ? "text-error" : 
                  log.type === "warning" ? "text-warning" : 
                  log.type === "success" ? "text-success" : ""
                }>
                  [{log.timestamp}] {log.message}
                </p>
              ))}
              <div ref={logsEndRef} />
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
