"use client";

import * as React from "react";
import { use, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Loader2, PlayCircle, FileDown, Presentation, FileJson, Archive } from "lucide-react";
import { requestExportAction, getExportsAction, getDownloadUrlAction } from "@/server/actions/export.actions";
import { ExportJob, ExportFormat } from "@/server/export/types/export.types";
import { toast } from "sonner";

interface DocumentsPageProps {
  params: Promise<{ id: string }>;
}

const formatIcons: Record<ExportFormat, React.ReactNode> = {
  pdf: <FileText className="h-5 w-5 text-red-500" />,
  pptx: <Presentation className="h-5 w-5 text-orange-500" />,
  docx: <FileText className="h-5 w-5 text-blue-500" />,
  zip: <Archive className="h-5 w-5 text-yellow-500" />,
  markdown: <FileDown className="h-5 w-5 text-slate-500" />,
  json: <FileJson className="h-5 w-5 text-green-500" />
};

export default function DocumentsPage({ params }: DocumentsPageProps) {
  const { id: projectId } = use(params);
  const [jobs, setJobs] = useState<ExportJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchJobs = React.useCallback(async () => {
    // Basic mock user ID for architecture
    const res = await getExportsAction(projectId, "user_123");
    if (res.success && res.jobs) {
      setJobs(res.jobs as ExportJob[]);
    }
    setIsLoading(false);
  }, [projectId]);

  // Poll for job updates
  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 3000);
    return () => clearInterval(interval);
  }, [fetchJobs]);

  const handleExport = async (format: ExportFormat) => {
    const res = await requestExportAction(
      "workspace_123", 
      projectId, 
      "mock_generation_job_id", // In real flow, fetch latest generation job id
      "user_123", 
      format
    );
    if (res.success) {
      toast.success(`Export requested for ${format.toUpperCase()}`);
      fetchJobs();
    } else {
      toast.error(res.error || "Failed to request export");
    }
  };

  const handleDownload = async (jobId: string) => {
    const res = await getDownloadUrlAction(jobId, "user_123");
    if (res.success && res.url) {
      window.open(res.url, "_blank");
    } else {
      toast.error(res.error || "Failed to generate download link");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-text">Export Center</h2>
          <p className="text-text-muted text-sm mt-1">Generate and download your AI artifacts in professional formats.</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-none border-border/50 hover:bg-surface-hover/50 transition-colors cursor-pointer" onClick={() => handleExport("pdf")}>
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="p-3 bg-red-500/10 rounded-full">{formatIcons.pdf}</div>
            <div>
              <h3 className="font-semibold text-text">Business Plan</h3>
              <p className="text-xs text-text-muted">PDF Document</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-none border-border/50 hover:bg-surface-hover/50 transition-colors cursor-pointer" onClick={() => handleExport("pptx")}>
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="p-3 bg-orange-500/10 rounded-full">{formatIcons.pptx}</div>
            <div>
              <h3 className="font-semibold text-text">Pitch Deck</h3>
              <p className="text-xs text-text-muted">PowerPoint PPTX</p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-none border-border/50 hover:bg-surface-hover/50 transition-colors cursor-pointer" onClick={() => handleExport("docx")}>
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="p-3 bg-blue-500/10 rounded-full">{formatIcons.docx}</div>
            <div>
              <h3 className="font-semibold text-text">Full Report</h3>
              <p className="text-xs text-text-muted">Microsoft Word</p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-none border-border/50 hover:bg-surface-hover/50 transition-colors cursor-pointer" onClick={() => handleExport("zip")}>
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="p-3 bg-yellow-500/10 rounded-full">{formatIcons.zip}</div>
            <div>
              <h3 className="font-semibold text-text">Full Bundle</h3>
              <p className="text-xs text-text-muted">All files in ZIP</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-none border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Export History</CardTitle>
          <CardDescription>Recent files generated by the Export Engine.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading ? (
              <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-text-muted" /></div>
            ) : jobs.length === 0 ? (
              <div className="text-center py-8 text-text-muted text-sm border border-dashed border-border rounded-lg">
                No exports found. Generate a file above.
              </div>
            ) : (
              jobs.map(job => (
                <div key={job.id} className="flex items-center justify-between p-4 border border-border/50 rounded-lg bg-surface/30">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-surface-hover rounded-md">
                      {formatIcons[job.format as ExportFormat] || formatIcons.pdf}
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-text uppercase">{job.format} Bundle</h4>
                      <p className="text-xs text-text-muted">Version {job.version} • {new Date(job.createdAt).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant="outline" className={
                      job.status === "COMPLETED" ? "border-green-500/20 text-green-500 bg-green-500/10" :
                      job.status === "FAILED" ? "border-red-500/20 text-red-500 bg-red-500/10" :
                      "border-primary/20 text-primary bg-primary/10 animate-pulse"
                    }>
                      {job.status}
                    </Badge>
                    {job.status === "COMPLETED" && (
                      <Button variant="secondary" size="sm" onClick={() => handleDownload(job.id)}>
                        <Download className="h-4 w-4 mr-2" /> Download
                      </Button>
                    )}
                    {job.status === "FAILED" && (
                      <Button variant="outline" size="sm" onClick={() => handleExport(job.format)}>
                        <PlayCircle className="h-4 w-4 mr-2" /> Retry
                      </Button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
