import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { SectionHeader } from "@/components/common/SectionHeader";
import { StatCard } from "@/components/common/StatCard";
import { AgentStatusBadge } from "@/components/common/AgentStatusBadge";
import { ActivityCard } from "@/components/common/ActivityCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, Folder, Zap, Clock } from "lucide-react";

export default function DashboardOverviewPage() {
  return (
    <PageContainer>
      <SectionHeader 
        title="Workspace Overview" 
        description="Monitor your active projects, agents, and overall system health."
      />

      {/* Metrics Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <StatCard
          title="Total Projects"
          value="4"
          icon={Folder}
          trend={12}
          description="vs last month"
        />
        <StatCard
          title="Active Agents"
          value="12"
          icon={Bot}
          trend={0}
          description="all systems operational"
        />
        <StatCard
          title="Tasks Completed"
          value="1,432"
          icon={Zap}
          trend={8.2}
          description="efficiency increased"
        />
        <StatCard
          title="Compute Hours"
          value="34.5h"
          icon={Clock}
          trend={-2.1}
          description="this billing cycle"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        {/* Active Agents Column */}
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle className="text-lg">Fleet Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-3">
              <AgentStatusBadge name="Orchestrator" status="running" />
              <AgentStatusBadge name="Market Research" status="idle" />
              <AgentStatusBadge name="Brand Strategy" status="running" />
              <AgentStatusBadge name="Tech Architect" status="completed" />
              <AgentStatusBadge name="GTM Planner" status="idle" />
              <AgentStatusBadge name="Financial Model" status="idle" />
              <AgentStatusBadge name="Pitch Deck" status="running" />
            </div>
            
            <div className="mt-8 rounded-lg border border-border bg-surface-hover/30 p-8 text-center text-sm text-text-secondary">
              No critical errors reported in the last 24 hours.
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity Column */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <ActivityCard 
              user={{ name: "Nexus Orchestrator" }}
              action="deployed new agent"
              target="Brand Strategy"
              timestamp="5 mins ago"
            />
            <ActivityCard 
              user={{ name: "Alex (You)" }}
              action="updated project settings in"
              target="Fintech Startup"
              timestamp="2 hours ago"
            />
            <ActivityCard 
              user={{ name: "Market Research Agent" }}
              action="completed competitor analysis for"
              target="E-commerce Platform"
              timestamp="Yesterday"
            />
            <ActivityCard 
              user={{ name: "Pitch Deck Agent" }}
              action="exported final deck for"
              target="HealthTech AI"
              timestamp="2 days ago"
            />
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
