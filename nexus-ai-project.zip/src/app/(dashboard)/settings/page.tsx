"use client";

import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { SectionHeader } from "@/components/common/SectionHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Settings, Shield, Keyboard, Zap, Palette, Bell, Blocks, LayoutDashboard } from "lucide-react";

export default function SettingsPage() {
  return (
    <PageContainer>
      <SectionHeader 
        title="Settings" 
        description="Manage your workspace preferences, integrations, and global account settings."
      />

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="mb-6 grid w-full max-w-3xl grid-cols-4 lg:grid-cols-8 bg-transparent p-0 gap-2 overflow-x-auto h-auto">
          <TabsTrigger value="general" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Settings className="h-4 w-4 mr-2 hidden md:inline-block" />General</TabsTrigger>
          <TabsTrigger value="appearance" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Palette className="h-4 w-4 mr-2 hidden md:inline-block" />Appearance</TabsTrigger>
          <TabsTrigger value="workspace" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><LayoutDashboard className="h-4 w-4 mr-2 hidden md:inline-block" />Workspace</TabsTrigger>
          <TabsTrigger value="ai" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Zap className="h-4 w-4 mr-2 hidden md:inline-block" />AI Prefs</TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Bell className="h-4 w-4 mr-2 hidden md:inline-block" />Alerts</TabsTrigger>
          <TabsTrigger value="keyboard" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Keyboard className="h-4 w-4 mr-2 hidden md:inline-block" />Shortcuts</TabsTrigger>
          <TabsTrigger value="integrations" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Blocks className="h-4 w-4 mr-2 hidden md:inline-block" />Integrations</TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-surface-hover border border-transparent data-[state=active]:border-border/50"><Shield className="h-4 w-4 mr-2 hidden md:inline-block" />Security</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6 max-w-4xl">
          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Account Overview</CardTitle>
              <CardDescription>Update your personal account information.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Display Name</label>
                <Input defaultValue="Alex Developer" />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Email Address</label>
                <Input defaultValue="alex@example.com" disabled />
                <p className="text-xs text-text-muted">To change your email, please contact support.</p>
              </div>
            </CardContent>
            <CardFooter className="border-t border-border/50 pt-4 flex justify-end">
              <Button>Save Changes</Button>
            </CardFooter>
          </Card>

          <Card className="shadow-none border-error/20 bg-error/5">
            <CardHeader>
              <CardTitle className="text-error">Danger Zone</CardTitle>
              <CardDescription className="text-text-secondary">Permanently delete your account and all projects.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="destructive">Delete Account</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-6 max-w-4xl">
          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Theme Settings</CardTitle>
              <CardDescription>Customize the visual appearance of Nexus AI.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="border-2 border-primary rounded-lg p-4 bg-background cursor-pointer text-center space-y-2">
                  <div className="h-20 w-full rounded bg-surface border border-border/50"></div>
                  <span className="text-sm font-medium text-primary">Dark Mode (Active)</span>
                </div>
                <div className="border border-border/50 rounded-lg p-4 bg-white text-zinc-900 cursor-pointer text-center space-y-2 opacity-50">
                  <div className="h-20 w-full rounded bg-zinc-100 border border-zinc-200"></div>
                  <span className="text-sm font-medium">Light Mode</span>
                </div>
                <div className="border border-border/50 rounded-lg p-4 bg-background cursor-pointer text-center space-y-2 opacity-50">
                  <div className="h-20 w-full rounded bg-gradient-to-br from-background to-white border border-border/50"></div>
                  <span className="text-sm font-medium">System Default</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6 max-w-4xl">
          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>AI Preferences</CardTitle>
              <CardDescription>Configure how your AI agent fleet behaves.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Auto-Execute Downstream Agents</h4>
                  <p className="text-sm text-text-muted">Automatically start the next phase of generation.</p>
                </div>
                <Badge className="bg-success text-white">Enabled</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Verbose Reasoning Logs</h4>
                  <p className="text-sm text-text-muted">Show detailed inner monologue for all agents.</p>
                </div>
                <Badge variant="outline">Disabled</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Placeholders for remaining tabs to keep it concise but structurally complete */}
        <TabsContent value="workspace" className="max-w-4xl">
          <Card className="shadow-none border-border/50"><CardHeader><CardTitle>Workspace Settings</CardTitle></CardHeader></Card>
        </TabsContent>
        <TabsContent value="notifications" className="max-w-4xl">
          <Card className="shadow-none border-border/50"><CardHeader><CardTitle>Notification Preferences</CardTitle></CardHeader></Card>
        </TabsContent>
        <TabsContent value="keyboard" className="max-w-4xl">
          <Card className="shadow-none border-border/50"><CardHeader><CardTitle>Keyboard Shortcuts</CardTitle></CardHeader></Card>
        </TabsContent>
        <TabsContent value="integrations" className="max-w-4xl">
          <Card className="shadow-none border-border/50"><CardHeader><CardTitle>Connected Apps</CardTitle></CardHeader></Card>
        </TabsContent>
        <TabsContent value="security" className="max-w-4xl">
          <Card className="shadow-none border-border/50"><CardHeader><CardTitle>Security & Access</CardTitle></CardHeader></Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
