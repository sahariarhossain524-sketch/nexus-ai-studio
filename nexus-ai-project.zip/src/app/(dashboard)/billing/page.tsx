import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { SectionHeader } from "@/components/common/SectionHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, CreditCard, Download, Receipt } from "lucide-react";

export default function BillingPage() {
  return (
    <PageContainer>
      <SectionHeader 
        title="Billing & Subscription" 
        description="Manage your plan, billing cycle, and download past invoices."
      />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column: Current Plan & Usage */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="shadow-none border-border/50 bg-gradient-to-br from-background to-primary/5">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl flex items-center gap-2">
                    Pro Plan <Badge className="bg-primary/20 text-primary border-primary/30 hover:bg-primary/30">Active</Badge>
                  </CardTitle>
                  <CardDescription className="mt-1">Billed annually at $240/yr.</CardDescription>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold">$20</span>
                  <span className="text-text-muted">/mo</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-text-secondary">AI Compute Credits</span>
                    <span className="font-medium text-primary">34.5 / 100 hrs</span>
                  </div>
                  <div className="h-2 w-full bg-surface-hover rounded-full overflow-hidden">
                    <div className="h-full bg-primary w-[34.5%] rounded-full"></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-text-secondary">Cloud Storage</span>
                    <span className="font-medium">2.1 / 10 GB</span>
                  </div>
                  <div className="h-2 w-full bg-surface-hover rounded-full overflow-hidden">
                    <div className="h-full bg-zinc-400 w-[21%] rounded-full"></div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-border/50 pt-4 flex gap-2">
              <Button>Upgrade to Team</Button>
              <Button variant="outline">Cancel Subscription</Button>
            </CardFooter>
          </Card>

          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Invoice History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="divide-y divide-border">
                {[
                  { date: "Aug 1, 2026", amount: "$240.00", status: "Paid", id: "INV-2026-08" },
                  { date: "Jul 1, 2026", amount: "$20.00", status: "Paid", id: "INV-2026-07" },
                  { date: "Jun 1, 2026", amount: "$20.00", status: "Paid", id: "INV-2026-06" },
                ].map((invoice, i) => (
                  <div key={i} className="py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded bg-surface flex items-center justify-center">
                        <Receipt className="h-4 w-4 text-text-muted" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{invoice.date}</p>
                        <p className="text-xs text-text-muted">{invoice.id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-medium">{invoice.amount}</span>
                      <Badge variant="outline" className="text-success border-success/30">{invoice.status}</Badge>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-text-muted">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Payment & Timeline */}
        <div className="space-y-6">
          <Card className="shadow-none border-border/50">
            <CardHeader>
              <CardTitle>Payment Method</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 border border-border rounded-lg flex items-center justify-between bg-surface-hover/30">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-12 rounded bg-white flex items-center justify-center border border-zinc-200">
                    {/* Placeholder for Visa/Mastercard Logo */}
                    <span className="text-xs font-bold text-blue-800">VISA</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium">•••• 4242</p>
                    <p className="text-xs text-text-muted">Expires 12/28</p>
                  </div>
                </div>
                <Badge variant="outline" className="bg-background">Default</Badge>
              </div>
              <Button variant="secondary" className="w-full">
                <CreditCard className="mr-2 h-4 w-4" /> Add Payment Method
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-none border-border/50 bg-surface/50">
            <CardHeader>
              <CardTitle>Subscription Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex justify-between border-b border-border/50 pb-2">
                <span className="text-text-secondary">Current cycle ends</span>
                <span className="font-medium">Aug 1, 2027</span>
              </div>
              <div className="flex justify-between border-b border-border/50 pb-2">
                <span className="text-text-secondary">Next payment</span>
                <span className="font-medium">$240.00</span>
              </div>
              <p className="text-xs text-text-muted pt-2 text-center">
                Need more compute credits? You can buy one-time credit packs in the Settings.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
