import { NextRequest, NextResponse } from "next/server";
import { InMemoryEventBus } from "@/server/events/in-memory-event-bus";
import { AIEventPayload } from "@/server/events/event-bus.interface";
// import auth if needed later

export const runtime = "nodejs"; // Needed for EventEmitter (can't be Edge currently)

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ jobId: string }> }
) {
  // Authentication check (basic scaffold)
  // const session = await getServerSession();
  // if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const { jobId } = await params;
  if (!jobId) {
    return new NextResponse("Job ID is required", { status: 400 });
  }

  const eventBus = InMemoryEventBus.getInstance();
  const encoder = new TextEncoder();

  // Establish SSE stream
  const customReadable = new ReadableStream({
    start(controller) {
      // Create listener
      const listener = (event: AIEventPayload) => {
        try {
          const data = `data: ${JSON.stringify(event)}\n\n`;
          controller.enqueue(encoder.encode(data));
          
          if (event.eventType === "generation.completed" || event.eventType === "generation.failed") {
            cleanup();
            controller.close();
          }
        } catch (error) {
          console.error("Error enqueueing SSE event:", error);
          cleanup();
          controller.close();
        }
      };

      // Subscribe to all events for this jobId
      eventBus.subscribe(jobId, "*", listener);

      // Heartbeat interval to keep connection alive
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`data: {"eventType": "heartbeat", "jobId": "${jobId}"}\n\n`));
        } catch {
          cleanup();
        }
      }, 20000);

      // Cleanup logic
      const cleanup = () => {
        clearInterval(heartbeat);
        eventBus.unsubscribe(jobId, "*", listener);
      };

      // Cleanup if client closes connection
      request.signal.addEventListener("abort", cleanup);
    }
  });

  return new NextResponse(customReadable, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
    },
  });
}
