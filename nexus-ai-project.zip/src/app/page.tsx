import * as React from "react";
import Link from "next/link";
import { MarketingLayout } from "@/components/layout/MarketingLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AgentStatusBadge } from "@/components/common/AgentStatusBadge";
import { ActivityCard } from "@/components/common/ActivityCard";
import { Command } from "lucide-react";
import { Bot, Briefcase, FileText, Palette, PenTool, TrendingUp, Sparkles, Zap, Shield, Globe } from "lucide-react";

export default function LandingPage() {
  return (
    <MarketingLayout>
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-24 pb-32 md:pt-32 md:pb-40">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background"></div>
        <div className="w-full mx-auto max-w-7xl px-4 md:px-6">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
              <Badge variant="outline" className="rounded-full px-4 py-1.5 border-primary/30 bg-primary/10 text-primary">
                <Sparkles className="mr-2 h-3.5 w-3.5" />
                Nexus AI Platform MVP is Live
              </Badge>
              <div className="space-y-4">
                <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                  The AI Brain for <br className="hidden sm:block" />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Your Next Startup.</span>
                </h1>
                <p className="max-w-[600px] text-lg text-text-secondary sm:text-xl leading-relaxed">
                  Deploy a swarm of specialized AI agents to handle strategy, market research, branding, and pitch decks. Go from idea to execution in minutes.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="h-12 px-8 text-base" asChild>
                  <Link href="/signup">
                    Start Generating
                    <kbd className="ml-3 hidden sm:inline-flex items-center gap-1 rounded border border-white/20 bg-white/10 px-1.5 font-mono text-[10px] font-medium text-white">
                      <Command className="h-3 w-3" />K
                    </kbd>
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="h-12 px-8 text-base" asChild>
                  <Link href="#features">View Demo</Link>
                </Button>
              </div>
            </div>

            {/* Hero Visual: Simulated AI Session */}
            <div className="relative mx-auto w-full max-w-[500px] lg:max-w-none animate-in fade-in zoom-in-95 duration-1000 delay-200 fill-mode-both">
              <div className="relative rounded-2xl border border-border bg-surface/50 p-2 shadow-2xl backdrop-blur-xl">
                <div className="flex items-center gap-2 border-b border-border/50 pb-2 mb-4 px-2">
                  <div className="h-3 w-3 rounded-full bg-error/80"></div>
                  <div className="h-3 w-3 rounded-full bg-warning/80"></div>
                  <div className="h-3 w-3 rounded-full bg-success/80"></div>
                  <div className="ml-4 text-xs font-mono text-text-muted flex-1 text-center pr-10">nexus-orchestrator-session</div>
                </div>
                
                <div className="space-y-4 p-4">
                  <div className="flex flex-wrap gap-2 mb-6">
                    <AgentStatusBadge name="Orchestrator" status="running" />
                    <AgentStatusBadge name="Market Research" status="completed" />
                    <AgentStatusBadge name="Pitch Deck" status="running" />
                  </div>

                  <div className="space-y-3 rounded-xl border border-border/50 bg-background/50 p-4">
                    <ActivityCard 
                      user={{ name: "Market Research Agent" }}
                      action="completed competitor analysis for"
                      target="Fintech Sector"
                      timestamp="Just now"
                      className="bg-surface/50"
                    />
                    <ActivityCard 
                      user={{ name: "Pitch Deck Agent" }}
                      action="is generating slide 4:"
                      target="Market Size (TAM/SAM/SOM)"
                      timestamp="In progress..."
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SOCIAL PROOF */}
      <section className="border-y border-border/40 bg-surface-hover/30 py-10">
        <div className="w-full mx-auto max-w-7xl px-4 md:px-6">
          <p className="text-center text-sm font-medium text-text-muted mb-6 uppercase tracking-widest">
            Trusted by forward-thinking teams
          </p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16 opacity-50 grayscale">
            {/* Simulated Logos using text */}
            <span className="text-xl font-bold flex items-center gap-2"><Globe className="h-6 w-6"/> Acme Corp</span>
            <span className="text-xl font-bold flex items-center gap-2"><Zap className="h-6 w-6"/> Stellar</span>
            <span className="text-xl font-bold flex items-center gap-2"><Shield className="h-6 w-6"/> Verity</span>
            <span className="text-xl font-bold flex items-center gap-2"><TrendingUp className="h-6 w-6"/> Nexus Partners</span>
          </div>
        </div>
      </section>

      {/* 3. HOW IT WORKS */}
      <section id="how-it-works" className="py-20 md:py-32">
        <div className="w-full mx-auto max-w-7xl px-4 md:px-6 text-center">
          <div className="mx-auto max-w-2xl mb-16 space-y-4">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">From prompt to startup.</h2>
            <p className="text-text-secondary text-lg">
              Nexus AI operates as a unified swarm. Just describe your idea, and the Orchestrator delegates tasks to specialized agents.
            </p>
          </div>
          
          <div className="grid gap-8 md:grid-cols-3">
            {[
              { step: "01", title: "Describe your vision", desc: "Enter a simple prompt describing your startup idea and target audience." },
              { step: "02", title: "Agents collaborate", desc: "The Orchestrator splits the work between branding, strategy, and research agents." },
              { step: "03", title: "Export assets", desc: "Review the generated pitch decks, logos, and market reports. Export with one click." }
            ].map((item, i) => (
              <div key={i} className="relative flex flex-col items-center p-6 text-center group">
                <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-xl font-bold text-primary transition-transform group-hover:scale-110">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-text-secondary leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. FEATURES (Bento Grid) */}
      <section id="features" className="py-20 md:py-32 bg-surface">
        <div className="w-full mx-auto max-w-7xl px-4 md:px-6">
          <div className="mb-16 space-y-4">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Meet your new executive team.</h2>
            <p className="text-text-secondary text-lg max-w-2xl">
              Six specialized AI agents working in perfect sync to build your foundation.
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="bg-background border-border/50 shadow-none hover:shadow-floating transition-all lg:col-span-2">
              <CardHeader>
                <Bot className="h-8 w-8 text-primary mb-2" />
                <CardTitle className="text-2xl">Orchestrator Agent</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-text-secondary">
                  The brain of the operation. It breaks down your initial prompt, routes tasks to the appropriate specialized agents, and ensures all outputs are cohesive and aligned with your core vision.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-background border-border/50 shadow-none hover:shadow-floating transition-all">
              <CardHeader>
                <TrendingUp className="h-8 w-8 text-accent mb-2" />
                <CardTitle className="text-xl">Market Research</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-text-secondary">
                  Analyzes competitors, calculates TAM/SAM/SOM, and identifies key market trends to position your product perfectly.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-background border-border/50 shadow-none hover:shadow-floating transition-all">
              <CardHeader>
                <Palette className="h-8 w-8 text-warning mb-2" />
                <CardTitle className="text-xl">Branding Agent</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-text-secondary">
                  Generates cohesive brand identities, color palettes, typography rules, and tone-of-voice guidelines.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-background border-border/50 shadow-none hover:shadow-floating transition-all">
              <CardHeader>
                <Briefcase className="h-8 w-8 text-success mb-2" />
                <CardTitle className="text-xl">Strategy Agent</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-text-secondary">
                  Formulates go-to-market strategies, pricing models, and identifies your ideal customer profiles (ICPs).
                </p>
              </CardContent>
            </Card>

            <Card className="bg-background border-border/50 shadow-none hover:shadow-floating transition-all">
              <CardHeader>
                <FileText className="h-8 w-8 text-error mb-2" />
                <CardTitle className="text-xl">Pitch Deck Agent</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-text-secondary">
                  Synthesizes all research and strategy into a compelling 10-slide investor pitch deck structure.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* 5. FINAL CTA */}
      <section className="py-24 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="w-full mx-auto max-w-4xl px-4 md:px-6 text-center space-y-8">
          <h2 className="text-3xl font-bold tracking-tight sm:text-5xl">Ready to build your empire?</h2>
          <p className="text-xl text-text-secondary max-w-2xl mx-auto">
            Stop staring at a blank page. Let Nexus AI generate your entire startup foundation in minutes.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
            <Button size="lg" className="h-12 px-8 text-base shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-shadow" asChild>
              <Link href="/signup">Create Your First Project</Link>
            </Button>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
