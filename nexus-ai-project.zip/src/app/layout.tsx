import type { Metadata } from "next";
import { Inter, Roboto_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";

const fontSans = Inter({
  variable: "--font-sans",
  subsets: ["latin"],
});

const fontMono = Roboto_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Nexus AI — Build a Startup from One Idea",
  description:
    "An AI-native platform where specialized AI agents collaborate to turn an idea into a launch-ready startup ecosystem.",
  keywords: [
    "AI Startup Generator",
    "Multi-Agent AI",
    "AI Product Engineer",
    "Lablab.ai Hackathon",
    "Nexus AI",
  ],
  authors: [{ name: "Sahariar Hossain" }],
  openGraph: {
    title: "Nexus AI — Collaborative Multi-Agent Startup Platform",
    description:
      "Transform a single concept into a complete launch kit using specialized AI agents.",
    url: "https://nexus-ai.vercel.app",
    siteName: "Nexus AI",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Nexus AI",
    description: "Build a startup from one idea using collaborative AI agents.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${fontSans.variable} ${fontMono.variable} font-sans min-h-screen bg-background text-foreground antialiased`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
