import NextAuth from "next-auth";
import { authConfig } from "@/server/auth/config";

const { auth } = NextAuth(authConfig);
import { NextResponse } from "next/server";

export default auth((req) => {
  const isLoggedIn = !!req.auth;
  const { pathname } = req.nextUrl;

  const isAuthRoute = pathname.startsWith("/login") || 
                      pathname.startsWith("/signup") || 
                      pathname.startsWith("/forgot-password") || 
                      pathname.startsWith("/reset-password");

  const isProtectedRoute = pathname.startsWith("/dashboard") || 
                           pathname.startsWith("/projects") || 
                           pathname.startsWith("/agents") || 
                           pathname.startsWith("/settings") || 
                           pathname.startsWith("/profile") || 
                           pathname.startsWith("/billing");

  // Redirect logged-in users away from auth pages
  if (isAuthRoute && isLoggedIn) {
    return NextResponse.redirect(new URL("/dashboard", req.nextUrl));
  }

  // Redirect logged-out users away from protected pages
  if (isProtectedRoute && !isLoggedIn) {
    return NextResponse.redirect(new URL("/login", req.nextUrl));
  }

  return NextResponse.next();
});

// Optionally, don't invoke Middleware on some paths
export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};
