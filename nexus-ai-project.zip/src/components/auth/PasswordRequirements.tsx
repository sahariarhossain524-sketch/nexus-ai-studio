import * as React from "react";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface PasswordRequirementsProps {
  password?: string;
}

export function PasswordRequirements({ password = "" }: PasswordRequirementsProps) {
  const reqs = [
    { label: "Minimum 8 characters", met: password.length >= 8 },
    { label: "Uppercase letter", met: /[A-Z]/.test(password) },
    { label: "Lowercase letter", met: /[a-z]/.test(password) },
    { label: "Number", met: /[0-9]/.test(password) },
    { label: "Special character", met: /[^A-Za-z0-9]/.test(password) },
  ];

  return (
    <div className="space-y-2 mt-2 p-3 bg-surface/50 border border-border/50 rounded-md">
      <p className="text-xs font-medium text-text-secondary">Password Requirements:</p>
      <ul className="space-y-1.5">
        {reqs.map((req, i) => (
          <li key={i} className="flex items-center gap-2 text-xs">
            {req.met ? (
              <Check className="h-3.5 w-3.5 text-success" />
            ) : (
              <X className="h-3.5 w-3.5 text-text-muted" />
            )}
            <span className={cn("transition-colors", req.met ? "text-success" : "text-text-muted")}>
              {req.label}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
