"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { Spinner } from "@/components/common/Spinner";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";

export function Batch3Examples() {
  return (
    <div className="p-8 space-y-12">
      <section>
        <h2 className="text-xl font-bold mb-4">1. Toast (Sonner)</h2>
        <Button
          variant="outline"
          onClick={() =>
            toast("Agent Execution Started", {
              description: "Market Research Agent is now active.",
              action: {
                label: "Undo",
                onClick: () => console.log("Undo"),
              },
            })
          }
        >
          Show Toast
        </Button>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4">2. Tooltip</h2>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline">Hover me</Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Add to library</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4">3. Command Palette Shell</h2>
        <div className="border border-border rounded-lg shadow-sm max-w-[450px]">
          <Command>
            <CommandInput placeholder="Type a command or search..." />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Suggestions">
                <CommandItem>Launch New Project</CommandItem>
                <CommandItem>Review Financials</CommandItem>
                <CommandItem>Export Pitch Deck</CommandItem>
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup heading="Settings">
                <CommandItem>Profile</CommandItem>
                <CommandItem>Billing</CommandItem>
                <CommandItem>Settings</CommandItem>
              </CommandGroup>
            </CommandList>
          </Command>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4">4. Loading Skeleton</h2>
        <div className="flex items-center space-x-4">
          <Skeleton className="h-12 w-12 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-[250px]" />
            <Skeleton className="h-4 w-[200px]" />
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4">5. Spinner</h2>
        <div className="flex items-center gap-4">
          <Spinner size="sm" />
          <Spinner size="default" className="text-primary" />
          <Spinner size="lg" className="text-accent" />
          <Spinner size="xl" />
        </div>
      </section>
    </div>
  );
}
