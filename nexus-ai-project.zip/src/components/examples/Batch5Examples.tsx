"use client";

import * as React from "react";
import { PageContainer } from "@/components/common/PageContainer";
import { AgentStatusBadge } from "@/components/common/AgentStatusBadge";
import { SidebarItem, NavbarItem } from "@/components/common/NavigationItems";
import { Modal } from "@/components/common/Modal";
import { TimelineItem } from "@/components/common/TimelineItem";
import { ActivityCard } from "@/components/common/ActivityCard";
import { ProjectCard } from "@/components/common/ProjectCard";
import { Button } from "@/components/ui/button";
import { FileText, Settings, LayoutDashboard } from "lucide-react";

export function Batch5Examples() {
  const [modalOpen, setModalOpen] = React.useState(false);

  return (
    <PageContainer className="space-y-12">
      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">1. Agent Status Badge</h2>
        <div className="flex gap-4">
          <AgentStatusBadge name="Market Agent" status="idle" />
          <AgentStatusBadge name="Pitch Deck" status="running" />
          <AgentStatusBadge name="Strategy" status="completed" />
          <AgentStatusBadge name="Branding" status="error" />
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">2. Navigation Items</h2>
        <div className="flex flex-col gap-6 max-w-sm">
          <div className="space-y-2 border border-border rounded-lg p-2 bg-surface">
            <h3 className="text-xs font-semibold text-text-muted px-2 uppercase tracking-wider mb-2">Sidebar</h3>
            <SidebarItem icon={LayoutDashboard} label="Dashboard" isActive />
            <SidebarItem icon={FileText} label="Projects" />
            <SidebarItem icon={Settings} label="Settings" />
          </div>
          
          <div className="flex gap-2 border border-border rounded-lg p-2 bg-surface w-fit">
            <NavbarItem label="Overview" isActive />
            <NavbarItem label="Integrations" />
            <NavbarItem label="Billing" />
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">3. Modal Wrapper</h2>
        <Modal
          open={modalOpen}
          onOpenChange={setModalOpen}
          trigger={<Button>Open Pre-styled Modal</Button>}
          title="Create New Agent"
          description="Deploy a new AI agent to your workspace. It will begin initializing immediately."
        >
          <div className="space-y-4">
            <p className="text-sm text-text-secondary">
              (Form fields would go here. The modal strictly enforces max-width and internal padding).
            </p>
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
              <Button onClick={() => setModalOpen(false)}>Deploy Agent</Button>
            </div>
          </div>
        </Modal>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">4. Timeline / Execution Logs</h2>
        <div className="max-w-md border border-border rounded-lg p-6 bg-surface">
          <TimelineItem 
            title="Analyzing Market Trends" 
            description="Scraped 2,400 data points from tech sector."
            status="completed" 
          />
          <TimelineItem 
            title="Generating Competitor Matrix" 
            description="Comparing 5 key competitors..."
            status="running" 
          />
          <TimelineItem 
            title="Drafting Strategy Document" 
            status="pending" 
            isLast
          />
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">5. Activity Feed Card</h2>
        <div className="max-w-md border border-border rounded-lg p-2 bg-surface divide-y divide-border">
          <ActivityCard 
            user={{ name: "Nexus Orchestrator" }}
            action="deployed new agent"
            target="Brand Designer"
            timestamp={new Date(Date.now() - 1000 * 60 * 5)} // 5 mins ago
          />
          <ActivityCard 
            user={{ name: "Alex (You)" }}
            action="updated project settings in"
            target="Fintech Startup"
            timestamp={new Date(Date.now() - 1000 * 60 * 60 * 2)} // 2 hours ago
          />
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">6. Project Presentation Card</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <ProjectCard
            title="SaaS Pitch Deck"
            description="AI-generated pitch deck for a new developer tool platform."
            status="active"
            updatedAt={new Date()}
          />
          <ProjectCard
            title="E-commerce Branding"
            description="Logo, color palette, and voice guidelines."
            status="archived"
            updatedAt={new Date(Date.now() - 1000 * 60 * 60 * 24 * 7)} // 7 days ago
          />
        </div>
      </section>
    </PageContainer>
  );
}
