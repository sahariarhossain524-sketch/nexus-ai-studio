"use client";

import * as React from "react";
import { FolderOpen, Plus, Bot } from "lucide-react";
import { SectionHeader } from "@/components/common/SectionHeader";
import { PageContainer } from "@/components/common/PageContainer";
import { EmptyState } from "@/components/common/EmptyState";
import { StatCard } from "@/components/common/StatCard";
import { Button } from "@/components/ui/button";

export function Batch4Examples() {
  return (
    <PageContainer className="space-y-12 bg-surface-hover/20 rounded-lg">
      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">1. Section Header</h2>
        <SectionHeader
          title="Agents Overview"
          description="Manage and monitor all active AI agents within your workspace."
          action={<Button size="sm"><Plus className="mr-2 h-4 w-4" />New Agent</Button>}
        />
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">2. Stat Cards</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <StatCard
            title="Active Agents"
            value="12"
            icon={Bot}
            trend={14.5}
            description="vs last month"
          />
          <StatCard
            title="Compute Hours"
            value="342.5h"
            trend={-4.2}
            description="efficiency improved"
          />
          <StatCard
            title="Failed Tasks"
            value="3"
            trend={0}
            description="requires attention"
            className="border-error/50"
          />
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4 text-primary">3. Empty State</h2>
        <EmptyState
          icon={FolderOpen}
          title="No projects found"
          description="You haven't created any AI projects yet. Start by creating a new project to deploy your first agent cluster."
          action={<Button><Plus className="mr-2 h-4 w-4" /> Create Project</Button>}
        />
      </section>
    </PageContainer>
  );
}
