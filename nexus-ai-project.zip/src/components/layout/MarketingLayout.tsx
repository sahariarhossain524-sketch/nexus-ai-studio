"use client";

import * as React from "react";
import Link from "next/link";
import { Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";

export function MarketingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      {/* Top Navigation */}
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="w-full mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2 transition-opacity hover:opacity-80">
            <Zap className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold tracking-tight">Nexus AI</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <Link href="#features" className="text-text-secondary transition-colors hover:text-foreground">Features</Link>
            <Link href="#how-it-works" className="text-text-secondary transition-colors hover:text-foreground">How it Works</Link>
            <Link href="#pricing" className="text-text-secondary transition-colors hover:text-foreground">Pricing</Link>
          </nav>
          
          <div className="flex items-center gap-4">
            <div className="hidden sm:block">
              <ThemeToggle />
            </div>
            <Button variant="ghost" className="hidden sm:inline-flex" asChild><Link href="/login">Log In</Link></Button>
            <Button asChild><Link href="/signup">Get Started</Link></Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 bg-surface py-12 md:py-16 mt-20">
        <div className="w-full mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 md:grid-cols-4 md:px-6">
          <div className="col-span-2 space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <Zap className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold tracking-tight">Nexus AI</span>
            </Link>
            <p className="max-w-xs text-sm text-text-secondary">
              The AI brain for your next startup. Deploy a swarm of specialized agents to accelerate your growth.
            </p>
            <p className="text-xs text-text-muted">
              &copy; {new Date().getFullYear()} Nexus AI Inc. All rights reserved.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-semibold">Product</h4>
            <ul className="space-y-3 text-sm text-text-secondary">
              <li><Link href="#" className="hover:text-foreground">Agents</Link></li>
              <li><Link href="#" className="hover:text-foreground">Pricing</Link></li>
              <li><Link href="#" className="hover:text-foreground">Changelog</Link></li>
              <li><Link href="#" className="hover:text-foreground">Documentation</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-semibold">Legal</h4>
            <ul className="space-y-3 text-sm text-text-secondary">
              <li><Link href="#" className="hover:text-foreground">Privacy Policy</Link></li>
              <li><Link href="#" className="hover:text-foreground">Terms of Service</Link></li>
              <li><Link href="#" className="hover:text-foreground">Cookie Policy</Link></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}
