import * as React from "react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export interface AgentStatusBadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  name: string;
  avatarSrc?: string;
  status: "idle" | "running" | "error" | "completed";
}

export function AgentStatusBadge({
  name,
  avatarSrc,
  status,
  className,
  ...props
}: AgentStatusBadgeProps) {
  const statusConfig = {
    idle: { color: "bg-muted-foreground", ping: false },
    running: { color: "bg-primary", ping: true },
    error: { color: "bg-error", ping: true },
    completed: { color: "bg-success", ping: false },
  };

  const config = statusConfig[status];

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-border bg-surface pl-1 pr-3 py-1 shadow-sm transition-colors",
        className
      )}
      {...props}
    >
      <div className="relative flex items-center justify-center">
        <Avatar className="h-6 w-6 border border-border">
          <AvatarImage src={avatarSrc} alt={name} />
          <AvatarFallback className="text-[10px]">{name.substring(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
          {config.ping && (
            <span
              className={cn(
                "absolute inline-flex h-full w-full animate-ping rounded-full opacity-75",
                config.color
              )}
            />
          )}
          <span
            className={cn(
              "relative inline-flex h-2.5 w-2.5 rounded-full border border-surface",
              config.color
            )}
          />
        </span>
      </div>
      <span className="text-xs font-medium text-foreground">{name}</span>
    </div>
  );
}
