import * as React from "react";
import { cn } from "@/lib/utils";
import { Check, Circle, Loader2 } from "lucide-react";

export interface TimelineItemProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description?: string;
  status: "pending" | "running" | "completed" | "error";
  isLast?: boolean;
}

export function TimelineItem({
  title,
  description,
  status,
  isLast = false,
  className,
  ...props
}: TimelineItemProps) {
  return (
    <div className={cn("relative flex gap-4", className)} {...props}>
      {/* Line connecting items */}
      {!isLast && (
        <div className="absolute left-[11px] top-6 bottom-0 w-px bg-border -bottom-4" />
      )}

      {/* Status Icon */}
      <div className="relative mt-1 flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-background ring-4 ring-background">
        {status === "completed" ? (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-success text-success-foreground">
            <Check className="h-3 w-3" />
          </div>
        ) : status === "running" ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : status === "error" ? (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-error text-error-foreground">
            <Circle className="h-3 w-3 fill-current" />
          </div>
        ) : (
          <div className="h-3 w-3 rounded-full border-2 border-muted-foreground bg-background" />
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col pb-6">
        <h4
          className={cn(
            "text-sm font-medium",
            status === "pending" ? "text-text-secondary" : "text-foreground"
          )}
        >
          {title}
        </h4>
        {description && (
          <p className="mt-1 text-sm text-text-muted">{description}</p>
        )}
      </div>
    </div>
  );
}
