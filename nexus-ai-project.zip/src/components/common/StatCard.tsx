import * as React from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react";

export interface StatCardProps extends React.ComponentProps<typeof Card> {
  title: string;
  value: string | number;
  icon?: LucideIcon;
  trend?: number; // percentage, positive or negative
  description?: string;
}

export function StatCard({
  title,
  value,
  icon: Icon,
  trend,
  description,
  className,
  ...props
}: StatCardProps) {
  return (
    <Card className={cn("overflow-hidden transition-all hover:shadow-floating hover:-translate-y-1", className)} {...props}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-text-secondary">
          {title}
        </CardTitle>
        {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {(trend !== undefined || description) && (
          <div className="mt-1 flex items-center text-xs">
            {trend !== undefined && (
              <span
                className={cn(
                  "flex items-center font-medium mr-2",
                  trend > 0 ? "text-success" : trend < 0 ? "text-error" : "text-text-muted"
                )}
              >
                {trend > 0 ? (
                  <TrendingUp className="mr-1 h-3 w-3" />
                ) : trend < 0 ? (
                  <TrendingDown className="mr-1 h-3 w-3" />
                ) : null}
                {Math.abs(trend)}%
              </span>
            )}
            {description && <span className="text-text-muted">{description}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
