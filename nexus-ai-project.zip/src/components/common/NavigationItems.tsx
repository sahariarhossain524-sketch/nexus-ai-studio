import * as React from "react";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

export interface SidebarItemProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: LucideIcon;
  label: string;
  isActive?: boolean;
  isCollapsed?: boolean;
}

export const SidebarItem = React.forwardRef<HTMLButtonElement, SidebarItemProps>(
  ({ icon: Icon, label, isActive, isCollapsed, className, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1 focus:ring-offset-background",
          isActive
            ? "bg-primary/10 text-primary"
            : "text-text-secondary hover:bg-surface-hover hover:text-foreground",
          isCollapsed && "justify-center px-0",
          className
        )}
        title={isCollapsed ? label : undefined}
        aria-current={isActive ? "page" : undefined}
        {...props}
      >
        <Icon className="h-5 w-5 shrink-0" />
        {!isCollapsed && <span>{label}</span>}
      </button>
    );
  }
);
SidebarItem.displayName = "SidebarItem";

export interface NavbarItemProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  isActive?: boolean;
}

export const NavbarItem = React.forwardRef<HTMLButtonElement, NavbarItemProps>(
  ({ label, isActive, className, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex h-9 items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1 focus:ring-offset-background",
          isActive
            ? "bg-surface-active text-foreground"
            : "text-text-secondary hover:bg-surface-hover hover:text-foreground",
          className
        )}
        aria-current={isActive ? "page" : undefined}
        {...props}
      >
        {label}
      </button>
    );
  }
);
NavbarItem.displayName = "NavbarItem";
