import * as React from "react";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Folder, Calendar } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export interface ProjectCardProps extends React.ComponentProps<typeof Card> {
  title: string;
  description?: string;
  status: "active" | "archived" | "draft";
  updatedAt: Date | string;
  href?: string;
  onActionClick?: (e: React.MouseEvent) => void;
}

export function ProjectCard({
  title,
  description,
  status,
  updatedAt,
  href,
  onActionClick,
  className,
  ...props
}: ProjectCardProps) {
  const timeAgo = typeof updatedAt === "string" 
    ? updatedAt 
    : formatDistanceToNow(updatedAt, { addSuffix: true });

  const cardContent = (
    <Card className={cn("flex flex-col overflow-hidden transition-all hover:shadow-floating hover:border-border-focus", className, href && "cursor-pointer")} {...props}>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <CardTitle className="flex items-center gap-2 text-base font-semibold">
            <Folder className="h-4 w-4 text-primary" />
            {title}
          </CardTitle>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 -mr-2 -mt-2" onClick={(e) => { e.preventDefault(); onActionClick?.(e); }}>
          <MoreHorizontal className="h-4 w-4" />
          <span className="sr-only">Open menu</span>
        </Button>
      </CardHeader>
      
      <CardContent className="flex-1">
        {description ? (
          <p className="text-sm text-text-secondary line-clamp-2">{description}</p>
        ) : (
          <p className="text-sm text-text-muted italic">No description provided.</p>
        )}
      </CardContent>
      
      <CardFooter className="flex items-center justify-between border-t border-border bg-surface-hover/50 px-6 py-3">
        <Badge 
          variant={status === "active" ? "default" : status === "archived" ? "secondary" : "outline"}
          className={cn(
            "capitalize font-medium",
            status === "active" && "bg-success/15 text-success hover:bg-success/25",
          )}
        >
          {status}
        </Badge>
        
        <div className="flex items-center text-xs text-text-muted">
          <Calendar className="mr-1 h-3 w-3" />
          Updated {timeAgo}
        </div>
      </CardFooter>
    </Card>
  );

  if (href) {
    return <Link href={href} className="block">{cardContent}</Link>;
  }

  return cardContent;
}
