import * as React from "react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";

export interface ActivityCardProps extends React.HTMLAttributes<HTMLDivElement> {
  user: {
    name: string;
    avatarUrl?: string;
  };
  action: string;
  target?: string;
  timestamp: Date | string;
}

export function ActivityCard({
  user,
  action,
  target,
  timestamp,
  className,
  ...props
}: ActivityCardProps) {
  const timeAgo = typeof timestamp === "string" 
    ? timestamp 
    : formatDistanceToNow(timestamp, { addSuffix: true });

  return (
    <div
      className={cn(
        "flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-surface-hover",
        className
      )}
      {...props}
    >
      <Avatar className="h-8 w-8 mt-0.5 border border-border">
        <AvatarImage src={user.avatarUrl} alt={user.name} />
        <AvatarFallback className="text-[10px]">{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
      </Avatar>
      
      <div className="flex flex-col gap-1">
        <p className="text-sm text-foreground">
          <span className="font-semibold">{user.name}</span>{" "}
          <span className="text-text-secondary">{action}</span>
          {target && (
            <>
              {" "}
              <span className="font-medium text-foreground">{target}</span>
            </>
          )}
        </p>
        <p className="text-xs text-text-muted">{timeAgo}</p>
      </div>
    </div>
  );
}
