import * as React from "react";
import { cn } from "@/lib/utils";

export interface PageContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export function PageContainer({
  children,
  className,
  ...props
}: PageContainerProps) {
  return (
    <div
      className={cn(
        "container mx-auto px-4 py-8 md:px-6 lg:py-10 max-w-7xl animate-in fade-in slide-in-from-bottom-4 duration-500",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
